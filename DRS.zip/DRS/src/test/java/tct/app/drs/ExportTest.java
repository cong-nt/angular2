package tct.app.drs;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import vn.drs.config.Config;
import vn.drs.constant.Constant;
import vn.drs.core.dao.BaseDao;
import vn.drs.entity.AbstractEntity;
import vn.drs.entity.BAssignment;
import vn.drs.entity.BResource;
import vn.drs.entity.BTask;
import vn.drs.entity.BWork;
import vn.drs.entity.MProject;
import vn.drs.entity.MRole;
import vn.drs.entity.MUsers;
import vn.drs.hibernate.dao.AssignmentDao;
import vn.drs.hibernate.dao.MUserDao;
import vn.drs.hibernate.dao.ProjectDao;
import vn.drs.hibernate.dao.ResourceDao;
import vn.drs.hibernate.dao.RoleDao;
import vn.drs.hibernate.dao.TaskDao;
import vn.drs.hibernate.dao.UserDao;
import vn.drs.hibernate.dao.WorkDao;
import vn.drs.util.DateUtils;
import vn.drs.util.ImportMpp;
import vn.drs.util.MppUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = Config.class)

public class ExportTest {

    private static final Integer BWORK_APPROVE = 2;

    @Autowired
    UserDao userDao;

    @Autowired
    MUserDao mUserDao;

    @Autowired
    AssignmentDao assignmentDao;

    @Autowired
    TaskDao taskDao;

    @Autowired
    ResourceDao resourceDao;

    @Autowired
    WorkDao workDao;

    @Autowired
    ProjectDao projectDao;
    @Autowired
    RoleDao mRoleDao;

    @Autowired
    SessionFactory sessionFactory;

    @Test
    @Ignore
    public void testFunction() {
        System.out.println("test");
    }

    @Test
    @Ignore
    @Transactional
    @Commit
    public void exportMPP() throws Exception {
        MProject project = new MProject();
        project.setPrjName("template project");
        MRole role = new MRole();
        role.setRolName("TA LA");
        projectDao.save(project);
        mRoleDao.save(role);
        Map<String, Collection<? extends AbstractEntity>> map = ImportMpp
                .importAssignmentData(
                        "src\\test\\resource\\mpptemplate\\DRS-Detail Schedule_20170315.mpp",
                        project, role);
        saveAbstractCollection(map.get(ImportMpp.M_USERS), userDao);
        saveAbstractCollection(map.get(ImportMpp.B_RESOURCE), resourceDao);
        saveAbstractCollection(map.get(ImportMpp.B_TASK), taskDao);
        saveAbstractCollection(map.get(ImportMpp.B_ASSIGNMENT), assignmentDao);
        saveAbstractCollection(map.get(ImportMpp.B_WORK), workDao);

    }

    @Test
    @Ignore
    @Transactional
    @Commit
    public void deleteAll() throws Exception {
        Session session = sessionFactory.getCurrentSession();
        deleteTable(session, BWork.class.getName());
        deleteTable(session, BAssignment.class.getName());
        deleteTable(session, BTask.class.getName());
        deleteTable(session, BResource.class.getName());
        deleteTable(session, MUsers.class.getName());
        deleteTable(session, MRole.class.getName());
        deleteTable(session, MProject.class.getName());
    }

    @Test
    @Ignore
    @Transactional
    @Commit
    public void changeMpp() throws Exception {
        List<BWork> bworks = workDao.findByWorkDate(new Date());
        System.out.println(bworks.size());
        for (BWork bwork : bworks) {
            bwork.setWorStatus(BWORK_APPROVE);
            System.out.println("bwork plan hours:" + bwork.getWorPlanHours());
            System.out.println("bwork work hours:" + bwork.getWorWorkHours());
            bwork.setWorWorkHours(8.0);
            workDao.save(bwork);
        }
    }

    @Test
    @Ignore
    @Transactional
    public void loadMPPFile() throws Exception {
        MppUtil.instance();
        MppUtil.instance().openFileMPP(
                "src\\test\\resource\\mpptemplate\\DRS-Detail Schedule_20170315.mpp");
        List<BWork> bworks = workDao.findByWorkDateAttachAssignment(new Date());
        bworks.size();
        for (BWork bwork : bworks) {
            BAssignment assignment = bwork.getBAssignment();
            MppUtil.instance().write(assignment.getBResource().getResUid(),
                    assignment.getBTask().getTasUniqueId(),
                    bwork.getWorWorkHours(), DateUtils.dateToString(
                            bwork.getWorWorkDate(), Constant.FORMAT_MMDDYY));
        }
        MppUtil.instance().saveNewFileMPP(
                "src\\test\\resource\\mpptemplate\\DRS-DetailSchedule_20170315_tmp.mpp");
        MppUtil.instance().closeCurrentFileMPP(false);
    }

    private void deleteTable(Session session, String className) {
        StringBuilder builder = new StringBuilder();
        builder.append("delete ");
        builder.append(className);
        Query query = session.createQuery(builder.toString());
        query.executeUpdate();
    }

    private void saveAbstractCollection(
            Collection<? extends AbstractEntity> collection, BaseDao baseDao) {
        int size = collection.size();
        for (AbstractEntity entity : collection) {
            baseDao.save(entity);
        }
    }
}
