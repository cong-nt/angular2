package vn.drs.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ImportResource({ "classpath:spring-config.xml", "classpath:hibernate.xml" })
@ComponentScan(basePackages = { "vn.drs.entity",
        "vn.drs.hibernate" }, excludeFilters = { @Filter(Configuration.class) })

@EnableTransactionManagement(proxyTargetClass = true)
public class Config {

}
