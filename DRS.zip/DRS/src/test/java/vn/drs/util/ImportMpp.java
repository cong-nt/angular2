package vn.drs.util;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import net.sf.mpxj.Duration;
import net.sf.mpxj.ProjectFile;
import net.sf.mpxj.Resource;
import net.sf.mpxj.ResourceAssignment;
import net.sf.mpxj.ResourceAssignmentContainer;
import net.sf.mpxj.Task;
import net.sf.mpxj.TimephasedWork;
import net.sf.mpxj.mpp.MPPReader;
import net.sf.mpxj.reader.ProjectReader;
import vn.drs.entity.AbstractEntity;
import vn.drs.entity.BAssignment;
import vn.drs.entity.BResource;
import vn.drs.entity.BTask;
import vn.drs.entity.BWork;
import vn.drs.entity.MProject;
import vn.drs.entity.MRole;
import vn.drs.entity.MUsers;

public class ImportMpp {

    public static final String B_WORK = "BWork";
    public static final String B_TASK = "BTask";
    public static final String B_RESOURCE = "BResource";
    public static final String B_ASSIGNMENT = "BAssignment";
    public static final String M_USERS = "MUsers";
    private DateFormat dateFormat = new SimpleDateFormat(
            "yyyy-MM-dd'T'HH:mm:ss");

    public ImportMpp() {
    }

    public static Map<String, Collection<? extends AbstractEntity>> importAssignmentData(
            String fileName, MProject project, MRole role) throws Exception {
        ProjectReader reader = new MPPReader();
        File file = new File(fileName);
        System.out.println(file.getAbsolutePath());
        ProjectFile projectFile = reader.read(file);

        ResourceAssignmentContainer rAssContainer = projectFile
                .getAllResourceAssignments();

        ListIterator<ResourceAssignment> iter = rAssContainer.listIterator();
        List<MUsers> mUsers = new ArrayList<>();
        List<BAssignment> bAssignments = new ArrayList<>();
        Map<Integer, BResource> bResources = new HashMap<>();
        Map<Integer, BTask> bTasks = new HashMap<>();
        List<BWork> bWorks = new ArrayList<>();
        Map<String, Collection<? extends AbstractEntity>> mapCollect = new HashMap<>();

        ResourceAssignment rAss;
        BAssignment bAssignment = null;
        BResource bResource = null;
        BTask bTask = null;
        while (iter.hasNext()) {
            rAss = iter.next();
            bResource = bResources.get(rAss.getResourceUniqueID());
            if (bResource == null) {
                bResource = createBResource(rAss.getResource(), mUsers,
                        bResources, project, role);
            }
            if (bResource == null)
                continue;
            bTask = bTasks.get(rAss.getTaskUniqueID());
            if (bTask == null) {
                bTask = createBTask(rAss.getTask(), bTasks, project);
            }
            bAssignment = new BAssignment();
            bAssignment.setAssUid(rAss.getUniqueID());
            bAssignment.setBResource(bResource);
            bAssignment.setAssPlanHours(0.0);
            bAssignment.setAssWorkHours(0.0);

            bAssignment.setBTask(bTask);

            bAssignments.add(bAssignment);

            List<BWork> bWorksAssignment = createBWorks(
                    rAss.getTimephasedActualWork(), rAss.getTimephasedWork(),
                    bAssignment, bResource);
            bWorks.addAll(bWorksAssignment);
        }

        mapCollect.put(M_USERS, mUsers);
        mapCollect.put(B_ASSIGNMENT, bAssignments);
        mapCollect.put(B_RESOURCE, bResources.values());
        mapCollect.put(B_TASK, bTasks.values());
        mapCollect.put(B_WORK, bWorks);

        return mapCollect;
    }

    private static BResource createBResource(Resource resource,
            List<MUsers> mUsers, Map<Integer, BResource> bResources,
            MProject project, MRole role) {
        if (resource == null)
            return null;
        String name = resource.getName();

        MUsers user = new MUsers();
        user.setUsrShortName(name);
        user.setUsrFullName("");
        user.setUsrUserName("");
        mUsers.add(user);

        BResource bResource = new BResource();
        bResource.setMProject(project);
        bResource.setMUsers(user);
        bResource.setResShortName(name);
        bResource.setMRole(role);
        bResource.setResUid(resource.getUniqueID());

        bResources.put(bResource.getResUid(), bResource);

        return bResource;
    }

    private static BTask createBTask(Task task, Map<Integer, BTask> bTasks,
            MProject project) {
        BTask bTask = new BTask();
        bTask.setMProject(project);
        bTask.setTasName(task.getName());
        bTask.setTasDescription(getDecriptionTask(task));
        bTask.setTasUniqueId(task.getUniqueID());
        bTask.setTasActualStartTime(new Date());
        bTask.setTasActualEndTime(new Date());
        bTask.setTasPlanStartTime(new Date());
        bTask.setTasPlanEndTime(new Date());
        bTasks.put(task.getUniqueID(), bTask);
        return bTask;
    }

    private static String getDecriptionTask(Task task) {
        if (task.getParentTask() != null) {
            return "";
        } else {
            return task.getParentTask().getName();
        }
    }

    private static List<BWork> createBWorks(
            List<TimephasedWork> timephasedActualWork,
            List<TimephasedWork> timephasedWork, BAssignment bAssignment,
            BResource bResource) {
        Map<Integer, BWork> mapBWork = new HashMap<>();
        List<BWork> lWorks = new ArrayList<>();
        loadTimeWork(timephasedWork, bAssignment, bResource, mapBWork, false);
        loadTimeWork(timephasedActualWork, bAssignment, bResource, mapBWork,
                true);
        lWorks.addAll(mapBWork.values());
        return lWorks;
    }

    private static void loadTimeWork(List<TimephasedWork> timephasedWork,
            BAssignment bAssignment, BResource bResource,
            Map<Integer, BWork> lstBWork, boolean isWork) {
        for (TimephasedWork timeWork : timephasedWork) {
            Date startDate = timeWork.getStart();
            Date endDate = timeWork.getFinish();
            Duration duration = timeWork.getAmountPerDay();
            Calendar calendarEndDate = Calendar.getInstance();
            calendarEndDate.setTime(endDate);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startDate);
            calendar.set(Calendar.HOUR_OF_DAY, 00);
            calendar.set(Calendar.MINUTE, 00);
            calendar.set(Calendar.SECOND, 00);
            calendar.set(Calendar.MILLISECOND, 00);

            int dayOfYear = calendar.get(Calendar.DAY_OF_YEAR);

            while (calendar.before(calendarEndDate)) {
                BWork bWork = lstBWork.get(dayOfYear);
                if (bWork == null) {
                    bWork = createBWork(bAssignment, bResource, calendar,
                            lstBWork, duration, isWork);
                } else {
                    if (isWork) {
                        bWork.setWorWorkHours(duration.getDuration());
                    } else {
                        bWork.setWorPlanHours(duration.getDuration());
                    }
                }

                dayOfYear++;
                calendar.set(Calendar.DAY_OF_YEAR, dayOfYear);
            }
        }
    }

    private static BWork createBWork(BAssignment bAssignment,
            BResource bResource, Calendar dateWork,
            Map<Integer, BWork> lstBWork, Duration duration, boolean isWork) {
        BWork bWork = new BWork();
        bWork.setBAssignment(bAssignment);
        bWork.setBResource(bResource);
        bWork.setWorPlanDate(dateWork.getTime());
        bWork.setWorWorkDate(dateWork.getTime());
        if (isWork) {
            bWork.setWorWorkHours(duration.getDuration());
        } else {
            bWork.setWorPlanHours(duration.getDuration());
        }
        lstBWork.put(dateWork.get(Calendar.DAY_OF_YEAR), bWork);
        return bWork;
    }

}
