// validate ngay thang trong pop-up Uy quyen
function change(){
    var autEffectiveDate = $('.input-daterange#datepickerAuthorize #start').val();
    var autExpirationDate = $('.input-daterange#datepickerAuthorize #end').val();
    if(autEffectiveDate == ''){
        $('#authorizationModal .errorMessage .autEffectiveDate').remove();
        $('#authorizationModal .errorMessage').append('<span class="autEffectiveDate text-danger" ><i class="glyphicon glyphicon-exclamation-sign text-success"></i> Effective date is required.<br/></span>');
    } else {
        $('#authorizationModal .errorMessage .autEffectiveDate').remove();
    }
    if(autExpirationDate == ''){
        $('#authorizationModal .errorMessage .autExpirationDate').remove();
        $('#authorizationModal .errorMessage').append('<span class="autExpirationDate text-danger" ><i class="glyphicon glyphicon-exclamation-sign text-success"></i> Expiration date is required.<br/></span>');
    } else {
        $('#authorizationModal .errorMessage .autExpirationDate').remove();
    } 
}

app.controller("authorizationCtrl", function($scope, $location,
        authorizationTaskFac) {
    $scope.authorizationTaskFac = authorizationTaskFac;
    $scope.userId = 4; // set userID tam thoi
    $scope.authorizationForm = {};

    angular.element(document).ready(function() {

        // Load data khi click vao link the hien popup uy quyen
        angular.element(document.querySelector('#onClickAuthor')).bind('click', function(){
            onGetProjectList($scope);
            onGetAuthorizedList($scope);
        });

        // Load lai danh sach user co the uy quyen khi chon lai project
        $scope.loadUserAuthorization = function(){
            onGetRoleUserInPj($scope);
        };

        // luu uy quyen
        $scope.saveAuthorization = function() {
            $scope.authorizationForm.autEffectiveDate = $('.input-daterange#datepickerAuthorize #start').val();
            $scope.authorizationForm.autExpirationDate = $('.input-daterange#datepickerAuthorize #end').val();
            if($scope.authorizationForm.autEffectiveDate == '' || $scope.authorizationForm.autExpirationDate == ''){
                return;
            }
            $scope.authorizationTaskFac.saveAuthorization($scope.authorizationForm).then(
                function(data) {
                    console.log('saveAuthorization success: ' + data);
                    if (data.status == 200) {
                        console.log('200 save ok');
                        onGetAuthorizedList($scope);
                    } else {
                        console.log(data.status);
                    }
                }, function(data) {
                    console.log('saveAuthorization fail: ' + data);
                }
            )
        };
        
        // huy uy quyen
        $scope.deleteAuthorization = function(e){
            if (confirm("Are you sure want to delete this item?")){
                var authorizationId = e.target.id;
                
                $scope.authorizationTaskFac.deleteAuthorization(authorizationId).then(
                        function (data){
                            console.log('Authorization deleted successfully: ' + data);
                            if (data.status == 200) {
                                console.log('200 save ok');
                                onGetAuthorizedList($scope);
                                } else {
                                    console.log(data.status);
                                    }
                            }, function(data) {
                                console.log('Unable to delete authorization: ' + data);
                                }
                    )
            }
        };
    })
})

// Lay danh sach project cua user co the phan quyen (vai tro PM, PL, TL)
function onGetProjectList($scope) {
    $scope.authorizationTaskFac.getProjectListByUserPMTL($scope.userId).then(
        function(data) {
            console.log('getProjectListByUserPMTL success: ' + data);
            if (data.status == 200) {
                $scope.projectList = data.data;
                $scope.authorizationForm['MProject.id'] = $scope.projectList[0].id;
                onGetRoleUserInPj($scope);
            } else {
                console.log(data.status);
            }
        }, function(data) {
            console.log('getProjectListByUserPMTL fail: ' + data);
        });
}

// Lay danh sach cac chung thuc cua user da thuc hien
function onGetAuthorizedList($scope) {
    $scope.authorizationTaskFac.getAuthorizedList($scope.userId).then(
        function(data) {
            console.log('getAuthorizedList success: ' + data);
            if (data.status == 200) {
                $scope.authorizedList = data.data;
                addTrueValid($scope);
            } else {
                console.log(data.status);
            }
        }, function(data) {
            console.log('getAuthorizedList fail: ' + data);
        });
}

// Them field de biet nhung uy quyen nao la con valid( valid=1 va ngay cuoi cung < ngay hien tai)
function addTrueValid($scope){
    var currentDate = (new Date()).setHours(0,0,0,0);
    for( var i= 0; $scope.authorizedList.length-1; i++){
        if($scope.authorizedList[i].valid == 1){
            var expirationDate = new Date($scope.authorizedList[i].autExpirationDate);
            if( expirationDate < currentDate ){
                $scope.authorizedList[i].trueValid = 0;
            }else {
                $scope.authorizedList[i].trueValid = 1
            }
        } else {
            $scope.authorizedList[i].trueValid = 0
        }
    }
}

// Lay role cua user trong 1 project cu the
function onGetRoleUserInPj($scope) {
    $scope.authorizationTaskFac.getRoleUserInPj($scope.userId ,$scope.authorizationForm['MProject.id']).then(
        function(data) {
            console.log('getRoleUserInPj success: ' + data);
            if (data.status == 200) {
                $scope.currentResourceInPj = data.data[0];
                $scope.roleResource = $scope.currentResourceInPj['MRole.rolName']
                $scope.authorizationForm['BResourceByAutCreatorId.id'] = $scope.currentResourceInPj.id;
                onGetToResourceList($scope);
            } else {
                console.log(data.status);
            }
        }, function(data) {
            console.log('getRoleUserInPj fail: ' + data);
        });
}

// Lay danh sach user co the duoc phan quyen toi
function onGetToResourceList($scope) {
    $scope.authorizationTaskFac.getToResourceList($scope.authorizationForm['MProject.id'], $scope.roleResource).then(
        function(data) {
            console.log('getToResourceList success: ' + data);
            if (data.status == 200) {
                $scope.toResourceList = data.data;
                // Lay fromResource dua vao ROLE
                onGetFromResourceList($scope)
            } else {
                console.log(data.status);
            }
        }, function(data) {
            console.log('getToResourceList fail: ' + data);
        });
}

//Lay danh sach user co the phan quyen
function onGetFromResourceList($scope) {
    console.log('onGetFromResourceList run: ');
    $scope.fromResourceList = [];
    if($scope.roleResource == 'PM'){
        $scope.fromResourceList = $scope.toResourceList;
        $scope.fromResourceList.push($scope.currentResourceInPj);
    } else if($scope.roleResource == 'PL'){
        $scope.fromResourceList.push($scope.currentResourceInPj);
        for (var resourceNo in $scope.toResourceList) {
            var resource = $scope.toResourceList[resourceNo]
            if(resource['MRole.rolName'] == 'TL')
            $scope.fromResourceList.push(resource);
        }
    } else if($scope.roleResource == 'TL'){
        $scope.fromResourceList.push($scope.currentResourceInPj);
    }
}
