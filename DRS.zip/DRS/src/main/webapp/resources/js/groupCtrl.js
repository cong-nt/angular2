app.directive("repeatEnd", function(){
            return {
                restrict: "A",
                link: function (scope, element, attrs) {
                    if (scope.$last) {
                        scope.$eval(attrs.repeatEnd);
                    }
                }
            };
        });

app.controller("groupCtrl",
		function($scope, $location, groupFac) {
	$scope.groupFac = groupFac;
	$scope.listGroup;
	$scope.listGroupCopy;
	$scope.listDev;
	$scope.listTeamLead;
	$scope.listGroupMember;
	angular.element(document).ready(function() {   
		onGetProjectDevs($scope);
		onGetGroupsMembers($scope) ;
		onGetListGroup($scope);
		ongetTeamLeads($scope);    
		$scope.groupMemberDone = function(){ return initView($scope)};
		$scope.teamLeadDone = function(){return initButtonAdd();};
		$scope.projectDevDone = function(){console.log($scope.listDev); onCheckAll();};
		
		// Tim kiem
		$('[name="SearchDualList"]').keyup(function (e) {
			var code = e.keyCode || e.which;
			if (code == '9') return;
			if (code == '27') $(this).val(null);
			var $rows = $(this).closest('table').find('tbody tr');
			var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();
			$rows.show().filter(function () {
				var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
				return !~text.indexOf(val);
			}).hide();
		});
		
		// nut add
		$('#add_gorup').click(function(){
			$('#team-lead-select').show();
			$(this).closest('tr').hide();
		})
    });	
	
	$scope.selectGroup = function(index, event){
		var selectedRow = $(event.target);
		$('.groups tbody tr').removeClass('active');
		$(selectedRow).parent('tr').addClass('active');

		for(i = 0; i <  $scope.listGroup.length; i++)
		{
			if($scope.listGroup[index]['BResource.id'] == $scope.listGroupCopy[i]['BResource.id'])
			{
				var temp = $scope.listGroupCopy[0];
		        $scope.listGroupCopy[0] = $scope.listGroupCopy[i];
		        $scope.listGroupCopy[i] = temp;
	        }
		}
		onGetGroupsMembers($scope);
		ongetTeamLeads($scope);    
		onGetProjectDevs($scope); 
        initView();
    	initButtonAdd();

        var selectedId =$scope.listGroup[index]['BResource.id'] ;
        $(".group-members" ).sortable( "disable" );
	  	$( "#"+selectedId+".group-members").sortable("enable" );

    	$(".group-members:visible#"+selectedId+" .first-show").show();
    	$(".group-members:visible:not(.group-members:visible#"+selectedId+") .first-show").hide();
        
		$('.template').hide();
	}
	
	$scope.save =  function(e){
		var memberIds = $('.list-group .group-members:visible:first table:first tbody tr:visible')
							.map(function() { return this.id; }).toArray().toString();
		var groupId = $('.list-group .group-members:visible:first').attr('id');
		
		 $scope.groupFac.saveGroup(groupId, memberIds).then(function(data) {
		        if (data.status == 200) {    
		        	$('tbody .item:visible').remove();
		        	onGetGroupsMembers($scope);
		        	onGetListGroup($scope);
		    		ongetTeamLeads($scope);    
		    		onGetProjectDevs($scope); 
		    		initView();

		    		$('.template').hide();
		    		$('.template .panel-body table:first tbody tr:not(tr:first)').remove();
		    		$('#team-lead-select').hide();
		    		$('.groups table tbody tr:last').show();
		        } else {
		        	console.log(data.status);
		        }
		    }, function(data) {
		        console.log('on save group fail: ' + data);
		    });
	};
	
	$scope.delete =  function(e){
		if(confirm("Are you sure you want to delete this item?")){
			var thisTag = $(e.target).closest('tr');
			var groupId = $(thisTag).attr('id');	

			 $scope.groupFac.deleteGroup(groupId).then(function(data) {
			        if (data.status == 200) {  
			        	$('tbody .item:visible').remove();
			    		onGetGroupsMembers($scope);
			        	onGetListGroup($scope);
			    		ongetTeamLeads($scope);    
			    		onGetProjectDevs($scope); 
			    		initView();
			    		initButtonAdd();
			    		$('.template').hide();
			        } else {
			        	console.log(data.status);
			        }
			    }, function(data) {
			        console.log('on save group fail: ' + data);
			    });
		}
	};
});

function onGetListGroup($scope){
	 $scope.groupFac.getListGroup(1).then(function(data) {
	        if (data.status == 200) {        	
	        	$scope.listGroup = data.data;  
	        	$scope.listGroupCopy = angular.copy($scope.listGroup);
	        } else {
	        	console.log(data.status);
	        }
	    }, function(data) {
	        console.log('getListGroup fail: ' + data);
	    });
}

function onGetProjectDevs($scope){
	 $scope.groupFac.getProjectDevs(1).then(function(data) {
	        if (data.status == 200) {        	
	        	$scope.listDev = data.data;
	        } else {
	        	console.log(data.status);
	        }
	    }, function(data) {
	        console.log('getProjectMembers fail: ' + data);
	    });
}


function onGetGroupsMembers($scope){
	 $scope.groupFac.getGroupsMembers(1).then(function(data) {
	        if (data.status == 200) {        	
	        	$scope.listGroupMember = data.data;  
	        } else {
	        	console.log(data.status);
	        }
	    }, function(data) {
	        console.log('onGetGroupsMembers fail: ' + data);
	    });
}


function ongetTeamLeads($scope){
	 $scope.groupFac.getTeamLeads(1).then(function(data) {
	        if (data.status == 200) {        	
	        	$scope.listTeamLead = data.data;  
	        } else {
	        	console.log(data.status);
	        }
	    }, function(data) {
	        console.log('ongetTeamLeads fail: ' + data);
	    });
}

function teamLeadSelect(){
	if($('#team-lead-select select option:selected').val() >0){
		$('.groups tbody>tr').removeClass('active');
		$('.groups tbody>tr#team-lead-select').addClass('active');
		
		var tag = $('.group-members.template');
		var id = $('#team-lead-select select').val();
		var groupName =  $('#team-lead-select select option:selected').text();
		$(tag).attr('id', id);
		$(tag).prependTo(".list-group");
		$(".group-members:first .group-name").text(groupName);
		if($( ".group-members:not(.group-members:visible:first)" ).lenght > 0){
			$( ".group-members:not(.group-members:visible:first)" ).sortable( "destroy" );
		}
		$(tag).show();
		initView();
		
	}
}

function initView($scope){
	initDropDrag();
	onCheckAll();	
	$(".group-members:visible:first .first-show").show();
	$(".group-members:visible:not(.group-members:visible:first) .first-show").hide();
	
	 
}

function initButtonAdd(){
	$('#team-lead-select select').val(0);
	if($('#team-lead-select select option').length==1){
		$('#team-lead-select').hide();
		$('.groups table tr:last').hide();
	}
	else{
		$('#team-lead-select').hide();
		$('.groups table tr:last').show();
	}
	
	if($('.groups tbody tr').length == 2){
		$('#team-lead-select').show();
		$('.groups table tr:last').hide();
	}
}

function initDropDrag(){
		
	$( ".group-members, .project-members" ).multisortable({
		  connectWith: ".connect-list",
		  items: ".item",
		  selectedClass: "active",
		  click: function(e){
			// $(e.currentTarget).find('.item-check').prop('checked',
			// $('this').hasClass('active')).change();
			  
		  },
	}).disableSelection();
	
	$( ".group-members" ).sortable( "enable" );
	$( ".group-members:visible:not(.group-members:visible:first)" ).sortable( "disable" );
	
	$('.arrow-button').click(function () {
		var $button = $(this), actives = '';
		if ($button.hasClass('arrow-left')) {
			actives = $('.project-members .panel-body table tbody tr.active');
			actives.appendTo('.group-members:visible:first .panel-body table:first tbody');
		} else if ($button.hasClass('arrow-right')) {
			actives = $('.group-members:visible:first .panel-body table:first tbody tr.active');
			actives.appendTo('.project-members .panel-body table tbody');
		}
	});
}


function onCheckAll(){
	$('.item-check').change(function(e){
		if( $(this).is(":checked") ) {
			$(this).closest('tr').addClass('active');
			$(this).closest('tr').addClass('active-by-checkbox');
			if( $(this).closest('tbody').find('input.item-check:checked').length 
					== $(this).closest('tbody').find('input.item-check').length){

				$(this).closest('table').find('.check-all').prop('checked',true);
			}
	    }
		else{
			$(this).closest('tr').removeClass('active');
			$(this).closest('tr').removeClass('active-by-checkbox');
			$(this).closest('table').find('.check-all').prop('checked',false);
		}
	})
	 $('.check-all').change(function () {
		 var checkVal = $(this).prop('checked');
		 var row = $(this).closest('table').children('tbody')
        					.children('tr').children('td:last-child')
    							.children('input:checkbox').prop('checked',checkVal).change();
      });
}

