app.controller("mainCtrl", function($scope, $location) {
    angular.element(document).ready(function() {
        $scope.isActive = function(viewLocation) {
            var active = (viewLocation === $location.path());
            return active;
        };
    });
});
