app.controller("importCtrl",['$scope', 'savedFile', 'jsonService', function($scope, savedFile, jsonService) {
	
	$scope.progress = 0;
	
	$scope.saveFile = function() {
		var file = $scope.file;
		var fileUrl = "http://localhost:8085/drs/api/upload";
		savedFile.savedFileUrl(file, fileUrl, $scope);
	};
}]);

app.directive('fileModel', ['$parse', function($parse){
	return {
		restrict: 'A',
		link: function(scope, element, attrs) {
			var model = $parse(attrs.fileModel);
			var modelSetter = model.assign;
			
			element.bind('change', function() {
				scope.filename = element[0].files[0].name;
				scope.$apply(function() {
					modelSetter(scope, element[0].files[0]);
				});
			});
		}
	};
}]);

app.service('savedFile', ['$http', function ($http){
	this.savedFileUrl = function(file, savedUrl, scope) {
		if (file == null || file == undefined) {
			scope.err = "Please enter file";
			return;
		}
		scope.err = "MSG001 - you have not fill in actual effort";
		var fd = new FormData();
		fd.append('file', file);
		$http.post(savedUrl, fd, {
			transformRequest: angular.identify,
			headers: {'Content-Type': undefined},
			params:{fd},
			responseType: "text",
			uploadEventHandlers: {
				progress: function(event) {
					scope.progress = Math.round((event.loaded/event.total) * 100);
				}
			}
		}).then (
				function(response) {
					scope.name = response.data;
					scope.tasks = response.data;
				}, function(err) {
				}
		);
	}
}]);

app.decorator("$xhrFactory", [
	"$delegate", "$injector",
	function($delegate, $injector) {
		return function(method, url) {
			var xhr = $delegate(method, url);
			var $http = $injector.get("$http");
			var callConfig = $http.pendingRequests[$http.pendingRequests.length - 1];
			if (angular.isFunction(callConfig.onProgress))
				xhr.addEventListener("progress", callConfig.onProgress);
			return xhr;
		};
	}
])

function onGetTaskList($scope){
	$scope.importTaskFac.getTaskList().then(function(data){  // get list payment success
	        console.log('getListUser success: ' + data);
    if (data.status == 200) {        	
    	$scope.taskList = data.data;  
    } else {
    	console.log(data.status);
    }
}, function(data) {
    console.log('getListTassk fail: ' + data);
});
	
}