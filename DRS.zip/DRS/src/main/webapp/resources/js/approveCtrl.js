app.controller("approveCtrl", 	function($scope, $location, approveFac) {
	$scope.approveFac = approveFac;
	angular.element(document).ready(function() {
		onGetResourcesCanApprove($scope);
		onGetAssignmentForApprove($scope);
    });
});

function onGetResourcesCanApprove($scope){
	$scope.approveFac.getResourcesCanApprove(1,1).then(function(data) {
        if (data.status == 200) {    
        	console.log('getResourcesCanApprove succes: ' + data);
        	$scope.ResourcesCanApprove = angular.fromJson(data.data);
        } else {
        	console.log(data.status);
        }
    }, function(data) {
        console.log('getResourcesCanApprove fail: ' + data);
    });
}

function onGetAssignmentForApprove($scope){
	$scope.approveFac.getAssignmentForApprove(resourceId).then(function(data){
		if (data.status == 200) {    
        	console.log('getAssignmentForApprove succes: ' + data);
        	$scope.AssignmentForApprove = angular.fromJson(data.data);
        } else {
        	console.log(data.status);
        }
    }, function(data) {
            console.log('getResourcesCanApprove fail: ' + data);
	});
}