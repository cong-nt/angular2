app.controller("viewTaskCtrl", function($scope) {
	angular.element(document).ready(function() {        
        console.log('view task run');
    });	
});
