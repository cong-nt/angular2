app.directive('hasPermission', function(permissions) {  
  return {
    link: function(scope, element, attrs) {
    	var bPermission = false;
    	var roles = attrs.hasPermission.split(",");
    	for(j = 0; roles!=null && j < roles.length ; j++ ){
		      if((typeof roles[j] !== 'string')) {
		        throw 'hasPermission value must be a string'
		      }
		      var value = roles[j].trim();
		      var notPermissionFlag = value[0] === '!';
		      if(notPermissionFlag) {
		        value = value.slice(1).trim();
		      }

	          var hasPermission = permissions.hasPermission(value);
	          bPermission = hasPermission && !notPermissionFlag || !hasPermission && notPermissionFlag;
	          
	          if(bPermission) break;
    	}
    	 function toggleVisibilityBasedOnPermission() {
	          if(bPermission) {
	            element[0].style.display = 'block';
	          }
	          else {
	            element[0].style.display = 'none';
	          }
	        }
	      
	      toggleVisibilityBasedOnPermission();
	      scope.$on('permissionsChanged', toggleVisibilityBasedOnPermission);
      
    }
  };
});