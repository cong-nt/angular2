app.controller("myTaskCtrl", function($scope, $location, mytaskFac, loadingErrorMessage) {
    $scope.mytaskFac = mytaskFac;
    $scope.loadingErrorMessage = loadingErrorMessage;
    angular.element(document).ready(function() {
        $scope.date = new Date();
        $scope.yesterday = moment().subtract(1, 'days');
        onGetMyTask($scope);
//        onGetListUser($scope);
        onGetListWork($scope);
        onGetListModule($scope);
        onGetListProject($scope);
        onGetListPhase($scope);
        onGetListStatus($scope);
        onGetListBusiness($scope);
    });
    
    angular.element(document.querySelector('#default-search-btn')).bind('click', function(){
        onSearchTask($scope);
    });
    angular.element(document.querySelector('#keyWord')).bind('keypress', function(e) {
        if(e.keyCode==13){
            onSearchTask($scope);
        }
    });
    
    $scope.onAddNewTask = function() {
        var newTask = {
            username : 'khanhthi.nt',
            phoneNumber : '232331',
            email : '<h1>thuat410@yahoo.com</h1>'
        };
        $scope.listUser.push(newTask);
    }
    $scope.onRemoveNewTask = function() {
        $scope.listUser.pop();
    }
    $scope.addNewRow = function() {
        addNewRow($scope);
    }
    $scope.onSaveMyTask = function() {
        onSaveMyTask($scope);
    }
    $scope.onNextMyTask = function() {
        onNextMyTask($scope);
    }
    $scope.onBackMyTask = function() {
        onBackMyTask($scope);
    }
    $scope.delete = function(task) {
        if(confirm("Are you sure you want to delete this item?")){
            $scope.listTask.splice( $scope.listTask.indexOf(task), 1 );
        }
    }
    $scope.onSaveMyTask = function() {
        onSaveMyTask($scope)
    }
    
    $scope.onDeleteMyTask = function(task) {
        onDeleteMyTask(task.id,$scope);
    }
    
    $scope.onSearchTaskAdvanced = function() {
        onSearchTaskAdvanced($scope);
    }
});

function onGetListWork($scope) {
    console.log('getListWork run');
    $scope.mytaskFac.getListTaskInfo(4).then(function(data) {
        // get list payment success
        console.log('getListWork success: ' + data);
        if (data.status == 200) {
            $scope.listWork = data.data;
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('getListWork fail: ' + data);
    });
}

function onGetListModule($scope) {
    console.log('getListModule run');
    $scope.mytaskFac.getListTaskInfo(5).then(function(data) {
        // get list payment success
        console.log('getListModule success: ' + data);
        if (data.status == 200) {
            $scope.listModule = data.data;
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('getListModule fail: ' + data);
    });
}

function addNewRow($scope) {
     var map = new Object();
     var date = moment().startOf('isoweek').format('YYYYMMDD');
     for(var i =0; i<7; i++){
         map[Number(date)+i] = '';
     }
    var newTask = {id: '' , tasBusiness : 'Out of Schedule', mapActual: map};
    $scope.listTask.push(newTask);
}

function onGetMyTask($scope) {

    console.log('getTaskByKeyword run');
    $scope.mytaskFac.getMyTask().then(function(data) {
        // get list payment success
        console.log('getTaskByKeyword success');
        if (data.status == 200) {
            $scope.listTask = angular.fromJson(data.data).listTask;
            $scope.minDate = new Date(angular.fromJson(data.data).minDate);
            $scope.maxDate = new Date(angular.fromJson(data.data).maxDate);
            var startDate = new Date(angular.fromJson(data.data).minDate);
            var endDate = new Date(angular.fromJson(data.data).maxDate);
            $scope.listDate = getDates(startDate, endDate);
            
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('getTaskByKeyword fail: ' + data);
    });

}

function onSaveMyTask($scope) {
    var listTask = $scope.listTask;
    console.log('Save Task run');
    var err = $scope.loadingErrorMessage.getContentErrorMessage().then(function(data) {
    	console.log(data);
    })
    var json = angular.toJson($scope.listTask);
    $scope.mytaskFac.saveMyTask(json).then(function(data) {
        // get list payment success
        console.log('Save Task success: ' + data);
        if (data.status == 200) {
            alert('Success')
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('Save Task fail: ' + data);
    });
}

function onDeleteMyTask(id,$scope) {

    if (confirm("Are you sure you want to delete this task?")) {
        $scope.mytaskFac.deleteMyTask(id).then(function(data) {
            if (data.status == 200) {
                onGetMyTask($scope);
            } else {
                console.log(data.status);
            }
        }, function(data) {
            console.log('on save group fail: ' + data);
        });
    }
}

function onBackMyTask($scope) {

    console.log('onNextMyTask run');
    var dateOut = new Date($scope.minDate);
    var dd = (dateOut.getDate() - 2).toString();
    dd = "00".substring(0, 2 - dd.length) + dd;
    var mm = (dateOut.getMonth() + 1).toString();
    mm = "00".substring(0, 2 - mm.length) + mm;
    var y = (dateOut.getFullYear()).toString();
    var date = y + mm + dd;

    $scope.mytaskFac.backMyTask(date).then(function(data) {
        if (data.status == 200) {
            $scope.listTask = angular.fromJson(data.data).listTask;
            var startDate = new Date(angular.fromJson(data.data).minDate);
            var endDate = new Date(angular.fromJson(data.data).maxDate);
            $scope.minDate = startDate;
            $scope.maxDate = endDate;
            $scope.listDate = getDates(startDate, endDate);

        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('on save task fail: ' + data);
    });
}

function onNextMyTask($scope) {

    console.log('onNextMyTask run');
    var dateOut = new Date($scope.maxDate);
    var dd = (dateOut.getDate() + 1).toString();
    var mm = (dateOut.getMonth() + 1).toString();
    mm = "00".substring(0, 2 - mm.length) + mm;
    var y = (dateOut.getFullYear()).toString();
    var date = y + mm + dd;

    $scope.mytaskFac.nextMyTask(date).then(function(data) {
        if (data.status == 200) {
            $scope.listTask = angular.fromJson(data.data).listTask;
            var startDate = new Date(angular.fromJson(data.data).minDate);
            var endDate = new Date(angular.fromJson(data.data).maxDate);
            $scope.minDate = startDate;
            $scope.maxDate = endDate;
            $scope.listDate = getDates(startDate, endDate);

        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('on save task fail: ' + data);
    });

}

function onGetListProject($scope) {
    console.log('getListProject run');
    $scope.mytaskFac.getListProject().then(function(data) {
        // get list payment success
        console.log('getListProject success: ' + data);
        if (data.status == 200) {
            $scope.listProject = data.data;
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('getListProject fail: ' + data);
    });
}

function onGetListPhase($scope) {
    console.log('getListPhase run');
    $scope.mytaskFac.getListTaskInfo(3).then(function(data) {
        // get list payment success
        console.log('getListPhase success: ' + data);
        if (data.status == 200) {
            $scope.listPhase = data.data;
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('getListPhase fail: ' + data);
    });
}

function onGetListStatus($scope) {
    console.log('getListListStatus run');
    $scope.mytaskFac.getListTaskInfo(1).then(function(data) {
        // get list payment success
        console.log('getListListStatus success: ' + data);
        if (data.status == 200) {
            $scope.listStatus = data.data;
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('getListStatus fail: ' + data);
    });
}

function onGetListBusiness($scope) {
    console.log('getListBusiness run');
    $scope.mytaskFac.getListTaskInfo(2).then(function(data) {
        // get list payment success
        console.log('getListBusiness success: ' + data);
        if (data.status == 200) {
            $scope.listBusiness = data.data;
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('getListBusiness fail: ' + data);
    });
}

function onSearchTask($scope) {
    var keyword = $scope.keyWord;
    console.log('SearchTaskDefault run');
    $scope.mytaskFac.searchTask($scope.keyWord).then(function(data) {
        // get list payment success
        console.log('SearchTaskDefault success');
        if (data.status == 200) {
            $scope.listTask = angular.fromJson(data.data).listTask;
            var startDate = new Date(angular.fromJson(data.data).minDate);
            var endDate = new Date(angular.fromJson(data.data).maxDate);
            $scope.listDate = getDates(startDate, endDate);
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('SearchTaskDefault fail: ' + data);
    });
}

function onSearchTaskAdvanced($scope) {
    console.log('SearchTaskAdvanced run');
    if( $scope.search == undefined) {
        $scope.search = null;
    }
    $scope.mytaskFac.advanceSearchTask($scope.search).then(function(data) {
        // get list payment success
        console.log('SearchTaskAdvanced success');
        if (data.status == 200) {
            $scope.listTask = angular.fromJson(data.data).listTask;
            var startDate = new Date(angular.fromJson(data.data).minDate);
            var endDate = new Date(angular.fromJson(data.data).maxDate);
            $scope.listDate = getDates(startDate, endDate);
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('SearchTaskAdvanced fail: ' + data);
    });
}

$scope.$watch('workerDetail.dateOfBirth', function (newValue) {
    $scope.mydateOfBirth = $filter('date')(newValue, 'yyyy/MM/dd'); 
});