app.controller("viewTaskCtrl", function($scope, $location, viewTaskFac) {
    $scope.viewTaskFac = viewTaskFac;
    $('.input-group.date').datepicker({
        format : "mm/dd/yyyy",
        todayBtn: true,
        autoclose: true,
        todayHighlight: true
    });
    angular.element(document).ready(function() {
        onGetListTaskInfo($scope);
    });
    angular.element(document.querySelector('#default-search-btn')).bind('click', function(){
        onSearchTaskDefault($scope);
    });
    angular.element(document.querySelector('#keyWord')).bind('keypress', function(e) {
        if(e.keyCode==13){
            onSearchTaskDefault($scope);
        }
    });
    angular.element(document.querySelector('#viewtask-search-success-btn')).bind('click', function(){
        onSearchTaskAdvance($scope);
    });
    angular.element(document.querySelector('input.form-control-viewtask')).bind('keypress', function(e) {
        if(e.keyCode==13){
            onSearchTaskAdvance($scope);
            $('#searchModal').modal('hide');
        }
    });
    $scope.onGoToNextWeek = function(){
        onGoToNextWeek($scope);
    };
    $scope.onGoToPreviousWeek = function(){
        onGoToPreviousWeek($scope);
    };
});

/**
 * Tim kiem mac dinh
 * @param $scope Scope
 * @returns Danh sach task
 */
function onSearchTaskDefault($scope) {
    var keyword = $scope.keyWord;
    if (typeof keyword == 'undefined') {
        keyword = '';
    }
    $scope.viewTaskFac.searchTaskDefault(keyword).then(function(data) {
        // get list payment success
        if (data.status == 200) {
            $scope.listViewTask = angular.fromJson(data.data).listTask;
            var startDate = new Date(angular.fromJson(data.data).minDate);
            var endDate = new Date(angular.fromJson(data.data).maxDate);
            $scope.currentDate = startDate;
            $scope.listDate = getDates(startDate, moment($scope.currentDate).add(6, 'day'));
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('SearchTaskDefault fail: ' + data);
    });
}

/**
 * Tim kiem nang cao
 * @param $scope Scope
 * @returns Danh sasch task
 */
function onSearchTaskAdvance($scope) {
    if (typeof $scope.search == 'undefined') {
        $scope.search = {};
    }
    
    $scope.search.startDate = document.querySelector('#input_start_date').value;
    $scope.search.endDate = document.querySelector('#input_end_date').value;
    $scope.search.keyword = $scope.keyWord;
    
    $scope.viewTaskFac.searchTaskAdvance($scope.search).then(function(data) {
        // get list payment success
        if (data.status == 200) {
            $scope.listViewTask = angular.fromJson(data.data).listTask;
            var startDate = new Date(angular.fromJson(data.data).minDate);
            var endDate = new Date(angular.fromJson(data.data).maxDate);
            $scope.currentDate = startDate;
            $scope.listDate = getDates(startDate, moment($scope.currentDate).add(6, 'day'));
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('SearchTaskDefault fail: ' + data);
    });
}

/**
 * Lay danh sach ngay
 * @param startDate Tu ngay
 * @param endDate Den ngay
 * @returns Danh sach ngay
 */
function getDates(startDate, endDate) {
    var dates = [], curDate = startDate, addDays = function(days) {
        var date = new Date(this.valueOf());
        date.setDate(date.getDate() + days);
        return date;
    };
    while (curDate <= endDate) {
        dates.push(curDate);
        curDate = addDays.call(curDate, 1);
    }
    return dates;
};

/**
 * Xem tuan ke tiep
 * @param $scope
 * @returns Danh sach tuan ke tiep
 */
function onGoToNextWeek($scope) {
    $scope.currentDate = moment($scope.currentDate).add(7, 'day').toDate();
    $scope.listDate = getDates($scope.currentDate, moment($scope.currentDate).add(6, 'day'));
}

/**
 * Xem tuan truoc
 * @param $scope
 * @returns Danh sach tuan truoc
 */
function onGoToPreviousWeek($scope) {
    $scope.currentDate = moment($scope.currentDate).subtract(7, 'day').toDate();
    $scope.listDate = getDates($scope.currentDate, moment($scope.currentDate).add(6, 'day'));
}

/**
 * Lay thong tin task (master)
 * @param $scope
 * @returns Danh sach thong tin task
 */
function onGetListTaskInfo($scope) {
    $scope.viewTaskFac.getListTaskInfo().then(function(data) {
        if (data.status == 200) {
            $scope.listTaskInfo = data.data;
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('getListTaskInfo fail: ' + data);
    });
}