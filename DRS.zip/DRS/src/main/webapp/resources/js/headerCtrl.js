app.controller("headerCtrl",
		function($scope, $location, headerFac) {
	$scope.headerFac = headerFac;
	angular.element(document).ready(function() {        
       	onGetUserName($scope);                          
    });
	
	$scope.logout = function () {
        $scope.headerFac.logout().then(function(data) {
            if (data.status == 200) {        	
            	window.location = 'https://192.168.32.11:8443/cas/logout';
            } else {
            	console.log(data.status);
            }
        }, function(data) {
            console.log('getUserName fail: ' + data);
        });
        
    };
});

function onGetUserName($scope) {	
    console.log('getUserName run');
    $scope.headerFac.getUserFullName().then(function(data) {
        // get list payment success
        console.log('getUserName success: ' + data);
        if (data.status == 200) {        	
        	$scope.userName = data.data;  
        } else {
        	console.log(data.status);
        }
    }, function(data) {
        console.log('getUserName fail: ' + data);
    });
}
