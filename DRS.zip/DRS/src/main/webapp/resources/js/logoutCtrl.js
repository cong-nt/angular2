app.controller("logoutCtrl", function($scope, $location,
		logoutFac) {

  $scope.logoutFac = logoutFac;
  $scope.logout = function(){
     $scope.logoutFac.logout().then(function(data) {
            if (data.status == 200) {
            	window.location = "https://localhost:8443/cas/logout";
            } else {
              console.log(data.status);
            }
        } 
     );
  };
})