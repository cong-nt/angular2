app.controller("exportTaskCtrl", function($scope, $location, exportTaskFac) {
    $scope.exportTaskFac = exportTaskFac;
    angular.element(document).ready(function() {
        //onGetTaskByKeyword($scope);
        angular.element(document.querySelector('#export-file-link')).bind('click', function(){
        	var messages = document.getElementsByClassName("errorMessage");
        	for (var i = 0; i < messages.length; i++) {
        		messages[i].style.display = "none";
        	}
        	onGetProjectByUser($scope);
        });
        angular.element(document.querySelector('#save_file_btn')).bind('click', function(){        	
        	onExportProject($scope);
        });
    });
});

function onGetProjectByUser($scope) {
	console.log('GetProjectByUser run');
	var userId = 702;
    $scope.exportTaskFac.getProjectByUser(userId).then(function(data) {
        // get list payment success
        console.log('GetProjectByUser success');
        if (data.status == 200) {        	       	
        	$scope.listProject = angular.fromJson(data.data);      	
        } else {
            console.log(data.status);
        }
    }, function(data) {
        console.log('GetProjectByUser fail: ' + data);
    });
}

function onExportProject($scope) {
	console.log('ExportProject run');
	var projectId = $scope.export_select_project;
	console.log(projectId);
    $scope.exportTaskFac.exportProject(projectId).then(function(data) {
        // get list payment success
        console.log('ExportProject success');
        if (data.status == 200) {        	
        	var success_message = document.getElementById("export_modal_message_success");
        	success_message.style.display = "block";
        	//var filename = data.data;
        	window.open("/drs/export/file_export/" + projectId +"/", '_blank');
        	//$scope.exportTaskFac.startDownLoadStream(filename);
        } else {
        	var fail_message = document.getElementById("export_modal_message_success");
        	fail_message.style.display = "block";
            console.log(data.status);
        }
    }, function(data) {
        console.log('ExportProject fail: ' + data);
    });
}