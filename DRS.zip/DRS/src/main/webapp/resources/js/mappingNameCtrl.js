app.controller("mappingNameCtrl",
	function($scope) {}
)
