app.controller('saveCtrl', function ($scope) {
	// get the file infomation
	$scope.getFileDetails = function (e) {
		$scope.files = [];
		$scope.$apply(function () {
			// store the file object in an array
			for (var i = 0; i < e.files.length; i++) {
				$scope.files.push(e.files[i])
			}
		});
	};
	
	// now form data with file details
	$scope.saveFile = function() {
		// fill form data with file details
		var data = new FormData();
		
		for (var i in $scope.files) {
			data.append("savedFile", $scope.files[i]);
		}
		
		// add listeners
		var objXhr = new XMLHttpRequest();
		objXhr.addEventListener("progress", updateProgress, false);
        objXhr.addEventListener("load", transferComplete, false);
        
        // send file details to the api
        objXhr.open("POST", "/api/upload");
        objXhr.send(data);
	}
	// update progress bar
    function updateProgress(e) {
    	if (e.lengthComputable) {
            document.getElementById('pro').setAttribute('value', e.loaded);
            document.getElementById('pro').setAttribute('max', e.total);
        }
    }
    
    // infomation
    function transferComplete(e) {
        alert("Files uploaded successfully.");
    }
});