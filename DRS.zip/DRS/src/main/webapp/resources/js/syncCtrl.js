app.controller("syncCtrl", function($scope, $location,
        syncFac) {

	$scope.syncFac = syncFac;
	$scope.synchronize = function(){
		 $scope.syncFac.synchronize().then(function(data) {
		        if (data.status == 200) {        	
		        } else {
		        	console.log(data.status);
		        }

		    }, function(data) {
		        console.log('sync fail: ' + data);
		    }
		    
		 );
	};
})
