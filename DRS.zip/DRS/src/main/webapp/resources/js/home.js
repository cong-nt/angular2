var urlPort;
var $scopeFinal;
var appBeam = angular.module('BeamWebApp', [ 'ngRoute', 'ngAnimate',
                                             'pascalprecht.translate', 'ui.bootstrap', 'ngSanitize']);

appBeam.controller('PageCtrl',
        [
         '$scope',
         'mainFac',
         '$translate',
         '$interval',
         '$location',
         '$uibModal',
         '$http',
         '$sce',
         function($scope, mainFac, $translate, $interval, $location, $uibModal, $http, $sce) {
        	 $scopeFinal = $scope;
             $scope.entryUrl = readCookie("entryUrl");
             $scope.idEvent = "";
             $scope.sce = $sce;
             $scope.urlDataCollectorApi = "";
             $scope.versionDataCollectorPath = "dataCollectorApi/v1";
             $scope.dataCollectorPath = "/_ah/api/";
             $scope.urlCollectorApi = "";
             $scope.urlPublicApi = "";
             $scope.versionCollectorPath = "beamApi/v1";
             $scope.versionPublicPath = "publicApi/v1";
             $scope.beamCollectorPath = "/_ah/api/";
             $scope.mainFac = mainFac;
             $scope.listUpcomingEvents;
             $scope.listTopEvents;
             $scope.listSponsorEventDTO;
             $scope.listMainEventDTO;
             $scope.mainVideo;
             $scope.listContentWebPage;
             $scope.currEvent;
             $scope.slidesImage = [];
             $scope.currSlideIndex = 0;
             $scope.isAdminRole = false;
             $scope.roleWebsiteAdmin = 8192;
             $scope.monthNames = [
                                  "Jan", "Feb", "Mar",
                                  "Apr", "May", "Jun", "Jul",
                                  "Aug", "Sep", "Oct",
                                  "Nov", "Dec"
                                ];

             $scope.createBeamTab = '2';
             $scope.eventTab='top-event';

             $scope.interval = 1000;
             $scope.alertThanksFlag = false;

             $scope.listOfArticles = [];
             $scope.$location = $location;
             $scope.mainVideo_;
             $scope.videoCreateBeam;

             // // Update time
             // $interval(function() {
             //     $scope.listTopEvents.events.forEach(function(beamEvent){
             //         if (beamEvent.countDown > 0) {
             //             beamEvent.countDown -= 1;
             //             beamEvent.countDownStr = $scope.getTimeString(beamEvent.countDown);
             //         } else {
             //             beamEvent.countDown = 0;
             //             beamEvent.countDownStr = "Running";
             //         }
             //     });
             // }, $scope.interval);

             mainFac.getLanguages('url').success(function(data) {
                 $scope.lstLanguages = JSON.parse(data.message);
             }).error(function(error) {
                 console.log('error getLanguage' + error);
             });
             $scope.addZero = function(i) {
                 if (i < 10) {
                     i = "0" + i;
                 }
                 return i;
             }
             $scope.currentLanguage = readCookie("currentLanguage");
             $scope.selectedIndexLanguage = readCookie("indexLanguage");
             if ($scope.currentLanguage == null) {
                 $scope.currentLanguage = "VietNam";
                 $scope.selectedIndexLanguage = 1;
                 createCookie("currentLanguage", "VietNam", 20);
                 createCookie("indexLanguage", 1, 20);
             }

             // active language
             $scope.choseLanguage = function($index, id) {
                 createCookie("indexLanguage", $index, 20);
                 $scope.currentLanguage = createCookie(
                         "currentLanguage", id, 20);
                 // $translateProvider.preferredLanguage($scope.currentLanguage);
                 $translate.use($scope.currentLanguage);
                 window.location.reload();
             }

             $scope.onClickTopEvent = function(){
                 $scope.eventTab='top-event';
                 if(navigator.geolocation) {
                     navigator.geolocation.getCurrentPosition(function(position) {
                         // var latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                         onGetUpcomingEvents($scope, position.coords.longitude, position.coords.latitude);
                         // markerCenter.setPosition(latlng);
                         // mapBeam.setCenter(latlng);
                         // clearInterval(animationInterval);
                         // $('#you_location_img').css('background-position', '-144px 0px');
                     });
                 }
             }
             $scope.onClickUpcomingEvent = function(){
                 $scope.eventTab='upcoming-event';
                 onGetTopEvents($scope);
             }

             $scope.getEntryPoint = function() {
                 mainFac.getEntryPoint().success(
                         function(data) {
                             console.log('getportSuccess: ' + data.error
                                     + ' - ' + data.message);
                             if (data.error == 0) {
                                 $scope.entryUrl = JSON
                                 .parse(data.message).url;
                                 createCookie("entryUrl",
                                         $scope.entryUrl, 30);
                                 $scope.urlCollectorApi = buildUrl(
                                         $scope.entryUrl,
                                         $scope.beamCollectorPath,
                                         $scope.versionCollectorPath);
                                 $scope.urlPublicApi = buildUrl(
                                         $scope.entryUrl,
                                         $scope.beamCollectorPath,
                                         $scope.versionPublicPath);
                                 $scope.urlDataCollectorApi = buildUrl(
                                         $scope.entryUrl,
                                         $scope.dataCollectorPath,
                                         $scope.versionDataCollectorPath);

                                 // $scope.onClickTopEvent();
//                                 onGetSponsorEvents($scope);
                                 onGetMainEvents($scope);
                                 onGetTopEvents($scope);
                                 if (navigator.geolocation) {
                                     navigator.geolocation.getCurrentPosition(function(position) {
                                       var pos = {
                                         lat: position.coords.latitude,
                                         lng: position.coords.longitude
                                       };
                                       onGetUpcomingEvents($scope,pos.lng,pos.lat);
                                     }, function() {
                                     });
                                   }
                                 onGetContentWebPage($scope, getCurrentArticle);
                                 console.log('urlCollectorApi: '
                                         + $scope.urlCollectorApi);
                             }
                         });
             }
             $scope.onLanguageClick = function(){
                 $(".multi-language").toggle("slow");
             }    
             
             $scope.onLanguageChange = function(){
//            	 for(var i = 0; i < $scope.currentLanguage.length; i++){            	 
            	 	var index =0;
            		 if($scope.currentLanguage == $scope.lstLanguages[0].id){
            			 index = 1;
            		 }else{
            			 index = 0;
            		 }
            		 
            		 createCookie("indexLanguage", index, 20);
                     $scope.currentLanguage = createCookie(
                             "currentLanguage", $scope.lstLanguages[index].id, 20);
                     // $translateProvider.preferredLanguage($scope.currentLanguage);
                     $translate.use($scope.currentLanguage);
                     window.location.reload();
            	 }
//             }             
             
             
             $scope.loadContents = function(page,idLanguage) {
                 var lstCategories = new Array();
                 mainFac.getListCategoriesByPages('url',page).success(function(data) {
                         if(page == null){
                             console.log("page null");
                         }
                         else{
                             lstCategories  = eval('data' + '.' + page);
                             $scope.getContentsByPage(page, lstCategories, idLanguage);
                         }
                     }).error(function(error){
                         console.log(error + "get list categories by page");
                 });
             }
             
             $scope.getContentsByPage = function(page, lstCategories, idLanguage){
                 mainFac.getListContents('url','',idLanguage).success(function(data){
                     for(var i = 0; i < lstCategories.length; i++){
                         var arrJson = eval('data' + '.' + page + '.' + lstCategories[i]);
                         for(var j = 0; j < arrJson.length; j++){
                             $scope[page + '_' + lstCategories[i] + '_' + arrJson[j].name] = arrJson[j];
                         }
                         $scope[page+'_'+lstCategories[i]] = arrJson;
                     }
                 });
             }   
             $scope.onMainEventClick = function(index){
            	 $('#preloader').show();
            	 window.location.href="#event?id=" + $scope.listMainEventDTO.events[index].eventId;
            	 setTimeout(function() {
           		  	$('#preloader').fadeOut("slow");
            	 }, 1500);
             }
             $scope.onTopEventClick = function(index){
            	 $('#preloader').show();
                 window.location.href="#event?id=" + $scope.listTopEvents.events[index].eventId;
                 setTimeout(function() {
            		  	$('#preloader').fadeOut("slow");
             	 }, 1500);
             }
             $scope.onUpcomingEventClick = function(index){
            	 $('#preloader').show();
                 window.location.href="#event?id=" + $scope.listUpcomingEvents.events[index].eventId;
                 setTimeout(function() {
            		  	$('#preloader').fadeOut("slow");
             	 }, 1500);
             }

             //slider
             $scope.direction = 'left';
             $scope.currentIndex = 0;

             $scope.setCurrentSlideIndex = function (index) {
                 $scope.direction = (index > $scope.currentIndex) ? 'left' : 'right';
                 $scope.currentIndex = index;
             };
             $scope.isCurrentSlideIndex = function (index) {
                 return $scope.currentIndex === index;
             };

             $scope.prevSlide = function () {
                 $scope.direction = 'left';
                 $scope.currentIndex = ($scope.currentIndex < $scope.listMainEventDTO.events.length - 1) ? ++$scope.currentIndex : 0;
             };

             $scope.nextSlide = function () {
                 $scope.direction = 'right';
                 $scope.currentIndex = ($scope.currentIndex > 0) ? --$scope.currentIndex : $scope.listMainEventDTO.events.length - 1;
             };


             $scope.ctF = {
                 email : '',
                 name : '',
                 message : ''
             }
             $scope.onClickSubmitContactForm = function(){
                 console.log('onClickSubmitContactForm run');

                 mainFac.sendMessageOffline($scope.urlDataCollectorApi, $scope.ctF)
                     .success(function(data) {

                             if (data.error == 0) {
                                 console.log('urlDataCollectorApi success: ' + data.message);
                                 // showMessage('contact_sendMessageSuccessfully', '', $translate);
                                 $scope.ctF = {
                                     email : '',
                                     name : '',
                                     message : ''
                                 }
                             } else {
                                 console.log('urlDataCollectorApi fail: ' + data);
                                 processError(data.error);
                                 // showMessage('contact_sendMessageFailed', '', $translate);
                             }
                             $scope.alertThanksFlag = true;
                     }).error(function(data) {
                         console.log('urlDataCollectorApi fail: ' + data);
                        // showMessage('contact_sendMessageFailed', '', $translate);
                     });
             }
             
             $scope.changeEmail = function(){
                 $scope.alertThanksFlag = false;
             }
             $scope.onClickCreateBeamTab = function(tabId){
                 $scope.createBeamTab = tabId;
                 if (tabId == '1'){

                 }
                 else if (tabId == '2'){
                    /* var myPlayer = document.getElementById('createBeamVideoId1');
                     myPlayer.stopVideo();*/
                	 playerBeam.playVideo();
                	 playerBeam.seekTo(0);
                 } else if (tabId == '3'){
                     /*var myPlayer = document.getElementById('createBeamVideoId1');
                     myPlayer.stopVideo();*/
                	 playerBeam.playVideo();
                	 playerBeam.seekTo(46);
                 } else if (tabId == '4'){
                     
                 }
             }

             $scope.monthNames = [
                 "Jan", "Feb", "Mar",
                 "Apr", "May", "Jun", "Jul",
                 "Aug", "Sep", "Oct",
                 "Nov", "Dec"
             ];

             $scope.getDateString = function(datetime){
                 var ttime = new Date(datetime * 1000);
                 return $scope.monthNames[ttime.getMonth()] + " " + $scope.addZero(ttime.getDate()) + ", " + ttime.getFullYear();
             }

             $scope.getTimeString = function(datetime){
//                 var ttime = datetime;
//                 var time2Hour = (s) => Math.round(s / 60 / 60 - 0.5);
//                 var time2Minute = (s) => Math.round((s % (60 * 60)) / 60 - 0.5);
//                 var time2Second = (s) => s % 60;
//                 return $scope.addZero(time2Hour(ttime))
//                     + ":" + $scope.addZero(time2Minute(ttime))
//                     + ":" + $scope.addZero(time2Second(ttime));
             }
             $scope.convertCountDownToTime = function(duration){
                 var tnow = new Date().getTime()/1000;
                 duration = duration - tnow;
                 var seconds = Math.round(duration % 60);
                 var minutes = Math.round((duration % (60 * 60)) / (60) - 0.5);
                 var hours = Math.round((duration % (24 * 60 * 60)) / (60 * 60) - 0.5);
                 var days = Math.round(duration / (24 * 60 * 60) - 0.5);
                 hours = days * 24 + hours;
                 hours = (hours < 10) ? "0" + hours : hours;
                 minutes = (minutes < 10) ? "0" + minutes : minutes;
                 seconds = (seconds < 10) ? "0" + seconds : seconds;
                 return hours + ":" + minutes + ":" + seconds;  
             }
             $interval(function() {
                 if ($scope.listUpcomingEvents){
                     $scope.listUpcomingEvents.events.forEach(function(value){
                         value.countDown --
                         if (value.countDown <= 0){
                             value.mainImageUrl = "./assets/images/phaobopng.gif"
                         } 
                     });
                 }
             }, $scope.interval);

             $('.top-nav > ul > li > a').on('click', function(event) {
                 $('.top-nav > ul > li').removeClass('active-item');
                 $(this).parent().addClass('active-item');
             });
             /*$(window).scroll(function() {
                 var position = $(this).scrollTop();

                 $scope.hashList = ['events', 'beam', 'create-beam', 'news-beam', 'contact'];
                 $scope.hashList.forEach(function(key){
                     if ($scope.hashList.indexOf($location.hash()) >= 0){
                         var target = $('#' + key).offset().top - 100;

                         if (position >= target) {
                             $('.top-nav > ul > li > a').parents().removeClass('active-item');
                             $('.top-nav > ul > li > a[href=#' + key + ']').parent().addClass('active-item');
                         }
                     }
                 })
             });*/

             $scope.onClickAddNews = function(){
                 console.log("onClickAddNews : ");
             }
             
          // save last page access
             $scope.saveLastPageAccess = function(){
                 if (typeof (Storage) !== "undefined") {
                     localStorage.setItem(S_LAST_PAGE_CALL, $location.absUrl());
                 }
             }

             /* logout */
             $scope.logOutClick = function(){
                 $httpFinal = $http;
                 S_LOGIN = "WebAdminLoginDTO";
                 urlLogout = $scope.urlDataCollectorApi + "/user/carrier/logout" ;
                 gotoWebAdminLogOut();
             }

             // controller ready
             angular.element(document).ready(function() {   
           	 
            	setTimeout(function() {
            		  $('#preloader').fadeOut("slow");
            	}, 1500);
                 if (typeof localStorage !== 'undefined') {
                     var loginDTO = JSON.parse(localStorage.getItem("WebAdminLoginDTO"));
                     if (loginDTO && loginDTO != null){
                         if (loginDTO.infoDTO.role == $scope.roleWebsiteAdmin){
                             $scope.isAdminRole = true;
                         }
                     }
                 }
                 $scope.loadContents("home_page",$scope.currentLanguage);
                 $scope.loadContents("footer_page",$scope.currentLanguage);
                 $scope.getEntryPoint();
                 // FB.XFBML.parse();
             });

         } ]);

appBeam.config([ '$translateProvider', function($translateProvider) {
             $translateProvider.translations('English', translationEnglish);
             $translateProvider.translations('VietNam', translationVietnam);
             var langBagasus = readCookie("currentLanguage");
             if (langBagasus == null) {
                 $translateProvider.preferredLanguage('VietNam');
             } else {
                 $translateProvider.preferredLanguage(langBagasus);
             }
         } ]);

appBeam.directive('mainEventDirective', function() {
  return function(scope, element, attrs) {
      if (scope.$last){
          var theme_slider = $("#owl-demo");
          $("#owl-demo").owlCarousel({
              navigation: false,
              slideSpeed: 300,
              paginationSpeed: 400,
              autoPlay: 6000,
              addClassActive: true,
           // transitionStyle: "fade",
              singleItem: true
          });
          // Custom Navigation Events
          $(".next-arrow").click(function() {
              theme_slider.trigger('owl.next');
          });
          $(".prev-arrow").click(function() {
              theme_slider.trigger('owl.prev');
          });
        }
  };
});

appBeam.directive('topEventDirective', function() {
    return function(scope, element, attrs) {
        if (scope.$last){
          }
    };
  });

appBeam.directive('comingEventDirective', function() {
    return function(scope, element, attrs) {
        if (scope.$last){
            $('.tabs').each(function(intex, element) {
                current_tabs = $(this);
                $(this).prepend('<div class="tab-nav line"></div>');
                var tab_buttons = $(element).find('.tab-label');
                $(this).children('.tab-nav').prepend(tab_buttons);
                $(this).children('.tab-item').each(function(i) {
                    $(this).attr("id", "tab-" + (i + 1));
                });
                $(".tab-nav").each(function() {
                    $(this).children().each(function(i) {
                        $(this).attr("href", "#tab-" + (i + 1));
                    });
                });
                $(this).find(".tab-nav a").click(function(event) {
                    $(this).parent().children().removeClass("active-btn");
                    $(this).addClass("active-btn");
                    var tab = $(this).attr("href");
                    $(this).parent().parent().find(".tab-item").not(tab).css("display", "none");
                    $(this).parent().parent().find(tab).fadeIn();
                    return false;
                });
                if (scope.listTopEvents.events.length <= 0){
                    $( "#topEvents" ).hide();
                    $( "#upcomingEvents" ).click();
                } 
            });
          }
    };
  });

appBeam.directive('detailEventDirective', function() {
    return function(scope, element, attrs) {
        if (scope.$last){
            var theme_slider = $("#owl-demo");
            $("#owl-demo").owlCarousel({
                navigation: false,
                slideSpeed: 300,
                paginationSpeed: 400,
                autoPlay: 6000,
                addClassActive: true,
             // transitionStyle: "fade",
                singleItem: true
            });
            // Custom Navigation Events
            $(".next-arrow").click(function() {
                theme_slider.trigger('owl.next');
            });
            $(".prev-arrow").click(function() {
                theme_slider.trigger('owl.prev');
            });
          }
    };
  });
appBeam.controller('ModalController', function ($uibModalInstance, params, mainFac, $sce) {
    var $scope = this;
    $scope.mainFac = mainFac;
    $scope.versionDataCollectorPath = "dataCollectorApi/v1";
    $scope.dataCollectorPath = "/_ah/api/";
    $scope.urlDataCollectorApi = "";
    $scope.entryURL;
    $scope.access_token = "";
    $scope.token_type = "";
    $scope.ycAppId = "";
    $scope.roleWebsiteAdmin = 8192;
    $scope.maxFileSize = 5242880;
    $scope.dz = [];
    $scope.listImageCategory;
    $scope.currContent = {
            name : "",
            category : "",
            pages : "",
            language : "",
            link : "",
            displayText : "",
            shortDescription : "",
            description : "",
            imageId : "",
            categoryOrder : "",
            defaultImageUrl : "",
            video : ""  
    }
    $scope.isCopyMainImage = false;
    $scope.isShowContentArray = [false, false, false, false, false, false, false, false, false, false, false, false]
    $scope.dropzoneIds = [                         
                          {id: '#zthumbs_1', previewId: 'dzpreview_1', heightImage: 105, widthImage: 186.66,
                              templateConfig: {
                                  thumbnailClass: 'beam-extra-image-thumbnail',
                                  couponRemoveThumbnail: 'coupon-remove-thumbnail',
                                  couponRemoveThumbnailImage: 'coupon-remove-thumbnail-image',
                                  thumbnailId: 'extraThumbnail_1'
                              }
                          },];
    $scope.arrLanguages = ['VietNam', 'English'];
    $scope.selectedLanguage = params.language;
    
    $scope.languageitemselected = function (item) {
    	$scope.selectedLanguage = item;
    	$scope.currContent.language = item;
//        $scope.selectedItem = item;
//        alert(item);
    }
    $scope.submitEditModal = function(){
        if (tinymce.get('editedDescription') != null ){
            $scope.currContent.description = tinymce.get('editedDescription').getContent();
        }
        $scope.onPutContentWebPage();
        tinymce.remove();
        $("#bootstrapcss").remove();
        $uibModalInstance.close();
    }
    $scope.closeEditModal = function(){
    	 $scope.selectedLanguage = params.language;
        tinymce.remove();
        $("#bootstrapcss").remove();
        $uibModalInstance.dismiss('cancel');
    }
    function acceptAFile(file, done){
        if (file.type.toString().startsWith("image") && file.size/1024/1024 <= 5){
            done();
        }
    }
    function resizeThumbnail(file){
        var info, srcRatio, trgRatio;
        info = {
            srcX: 0,
            srcY: 0,
            srcWidth: file.width,
            srcHeight: file.height
        };
        srcRatio = file.width / file.height;
        info.optWidth = this.options.thumbnailWidth;
        info.optHeight = this.options.thumbnailHeight;
        if ((info.optWidth == null) && (info.optHeight == null)) {
            info.optWidth = info.srcWidth;
            info.optHeight = info.srcHeight;
        } else if (info.optWidth == null) {
            info.optWidth = srcRatio * info.optHeight;
        } else if (info.optHeight == null) {
            info.optHeight = (1 / srcRatio) * info.optWidth;
        }
        trgRatio = info.optWidth / info.optHeight;
        if (file.height < info.optHeight && file.width >= info.optWidth) {
            info.srcHeight = file.height;
            info.srcWidth = info.srcHeight * trgRatio;
        } else if (file.height >= info.optHeight && file.width < info.optWidth) {
            info.srcWidth = file.width;
            info.srcHeight = info.srcWidth / trgRatio;
        } else {
            if (srcRatio > trgRatio) {
                info.srcHeight = file.height;
                info.srcWidth = info.srcHeight * trgRatio;
            } else {
                info.srcWidth = file.width;
                info.srcHeight = info.srcWidth / trgRatio;
            }
        }
        info.srcX = (file.width - info.srcWidth) / 2;
        info.srcY = (file.height - info.srcHeight) / 2;
        return info;
    }
    var myPreviewTemplate = function (value) {
        return "<div>" +
                "<img data-dz-thumbnail class='" + value.thumbnailClass + "' id='" + value.thumbnailId + "'/>" +
                    "<a data-dz-remove class='" + value.couponRemoveThumbnail + "'>" +
                "<img class='" + value.couponRemoveThumbnailImage + "' src='../admin-images/close_image.png'>" +
                "</a>" +
            "</div>";
    }
    var createDropzone = function(dropzone){
        return new Dropzone(dropzone.id, { // '#uploadInventoryForm'
            acceptedFiles: "image/*",
            accept: acceptAFile,
            url: "/bagasus-upload", // Set the url
            thumbnailHeight: dropzone.heightImage,
            thumbnailWidth: dropzone.widthImage,
            parallelUploads: 100,
            maxFiles: 1,
            maxFilesize : 5, // $scope.maxFileSize,
            // addRemoveLinks: true,
            // dictRemoveFile: "remove Image",
            previewTemplate: myPreviewTemplate(dropzone.templateConfig),
            previewsContainer: dropzone.id,
            // previewsContainer: "#previews",
            autoProcessQueue: false, // Make sure the files aren't queued until manually added
            uploadMultiple: true, // Make sure the files aren't queued until manually added
            clickable: dropzone.id, // Define the element that should be used as click trigger to select files.
            resize: resizeThumbnail,
            dictFileTooBig: "File is too big ({{filesize}}MB). Max filesize: {{maxFilesize}}MB.",
        });
    }
    
    var initializeDropzone = function(dz, index){
        dz.on("addedfile", function (file) {
            if (this.files.length > 1) {
                $scope.tmpImage = this.files[0];
                this.removeFile(this.files[0]);
            } else if (this.files.length == 0) {
                this.files.push(file);
            } else {
                if (file.type.toString().startsWith("image") && file.size <= $scope.maxFileSize ){
                        document.getElementById("btn_save").disabled = false;
                }
                else {
                    this.removeFile(this.files[this.files.length-1]);
                }
            }
        });
        dz.on('removedfile', function (file) {
                document.getElementById("btn_save").disabled = true;
            if (this.files.length == 0)
                showDropZoneText();
        });
        // Update the total progress bar
        dz.on("totaluploadprogress", function (progress) {
            // Materialize.toast("event totaluploadprogress", 6000);
        });
        dz.on("sending", function (file) {
            // Materialize.toast("event sending", 6000);
        });
        // Hide the total progress bar when nothing's uploading anymore
        dz.on("queuecomplete", function (progress) {
            // Materialize.toast("event queuecomplete", 6000);
        });
        dz.on("success", function (file) {
//              Materialize.toast("event success", 6000);
        });
        dz.on("error", function (file, e) {
            Materialize.toast("event error: " + e, 6000);
            this.emit("addedfile", $scope.tmpImage);
            this.createThumbnail($scope.tmpImage);
            $scope.tmpImage = undefined;
        });
        dz.on("thumbnail", function (file, dataUrl) {
            hideDropZoneText();
        });        
        dz.on("reset", function (file) {
            // Materialize.toast("event reset: ", 6000);
            if (this.element.id == 'zthumbs_1')
                document.getElementById("btn_save").disabled = false;
            this.enable();
        });
    }
    $scope.uploadFileToServer = function () {
        // file must be a blob
        var urlGetPushImage = "/user/image/uploadurl/get";
        var file = $scope.dz[0].files[0];
        if (file) {
            showLoading();
            mainFac.onGetUrlPushImage(urlGetPushImage, $scope.ycAppId, $scope.token_type, $scope.access_token).success(function (getImageUploadUrlReturn) {
                //get list payment success
                if (getImageUploadUrlReturn.error == 0) {
                    if (getImageUploadUrlReturn.message != null
                        && getImageUploadUrlReturn.message != "") {
                        var uploadImg = JSON.parse(getImageUploadUrlReturn.message);
                        var getImageUploadUrl = getUrlUploadImageOnServer(uploadImg.uploadUrl);
                        var inputFileName = uploadImg.inputFileName;
                        var fd = new FormData();
                        fd.append(inputFileName, file);
                        fd.append('category',$scope.currContent.category);
                        mainFac.onUploadImage(getImageUploadUrl, fd, $scope.ycAppId, $scope.token_type, $scope.access_token).success(function (dataUpload) {
                            hideLoading();
                            if (dataUpload.error == 0) {
                                if (dataUpload.message != null
                                    && dataUpload.message != "") {
                                    hideLoading();
//                                    if ($scope.isCopyMainImage == true){
//                                        var jsonImage = JSON.parse(dataUpload.message).ids;
//                                        var infoJSON;
//                                        for (key in jsonImage) {
//                                            infoJSON = jsonImage[key];
//                                        }
//                                        $scope.onGetURLImage(infoJSON);
//                                        $scope.dz[0].removeFile($scope.dz[0].files[0]);
//                                    } 
                                    $scope.onGetImageByCategory($scope.currContent.category);
                                } else {
                                    processError(dataUpload.error);
                                }
                            } else {
                                hideLoading();
                                processError(dataUpload.error);
                            }
                        }).error(function (dataUpload) {
                            hideLoading();
                            console.log('onUploadImage fail: ' + dataUpload);
                        });
                    }
                } else {
                    hideLoading();
                    processError(getImageUploadUrlReturn.error);
                }
            }).error(function (dataRegis) {
                //get list payment fail
                hideLoading();
                console.log('getUrlPushImageSuccess fail: ' + dataRegis);
            });
        }
    };
    $scope.onPutContentWebPage = function() {
        mainFac.getEntryPoint().success(
                function(data) {                    
                    if (data.error == 0) {
                        $scope.entryUrl = JSON
                        .parse(data.message).url;
                        $scope.urlDataCollectorApi = buildUrl(
                                $scope.entryUrl,
                                $scope.dataCollectorPath,
                                $scope.versionDataCollectorPath);
                        onPutContentWebPage($scope, $scope.urlDataCollectorApi);
                    }
                });
    }
    $scope.onGetURLImage = function(id){
        var ImageUrlRequestDTO = {
                id : id,
                size : 0,
                crop : false
        }
        mainFac.getEntryPoint().success(
                function(data) {                    
                    if (data.error == 0) {
                        $scope.entryUrl = JSON
                        .parse(data.message).url;
                        $scope.urlDataCollectorApi = buildUrl(
                                $scope.entryUrl,
                                $scope.dataCollectorPath,
                                $scope.versionDataCollectorPath);
                        onGetURLImage($scope, ImageUrlRequestDTO);
                    }
                });
    }
    $scope.onGetImageByCategory = function(category){
        var ImageCategoryDTO = {
               category : category
        }
        mainFac.getEntryPoint().success(
                function(data) {                    
                    if (data.error == 0) {
                        $scope.entryUrl = JSON
                        .parse(data.message).url;
                        $scope.urlDataCollectorApi = buildUrl(
                                $scope.entryUrl,
                                $scope.dataCollectorPath,
                                $scope.versionDataCollectorPath);
                        onGetImageByCategory($scope, ImageCategoryDTO);
                    }
                });
    }
    
    function hideDropZoneText() {
        document.getElementById("dropzone_upload").style.display = "none";
    }

    function showDropZoneText() {
        document.getElementById("dropzone_upload").style.display = "block";
    }

    angular.element(document).ready(function() {
        $scope.currContent.name = params.name;
        $scope.currContent.category = params.category;
        $scope.currContent.pages = params.pages;
        $scope.currContent.language = params.language;
        $scope.currContent.link = params.link;
        $scope.currContent.displayText = params.displayText;
        $scope.currContent.shortDescription = params.shortDescription;
        $scope.currContent.description = params.description;
        $scope.currContent.imageId = params.imageId;
        $scope.currContent.categoryOrder = params.categoryOrder;
        $scope.currContent.defaultImageUrl = params.defaultImageUrl;
        $scope.currContent.video = params.video; 
        $scope.onGetImageByCategory($scope.currContent.category);
        var tmpArr = params.isShowContentArray.split(",");
        for (var i = 0 ; i < 12; i ++ ){
            if (tmpArr[i] == 1){
                $scope.isShowContentArray[i] = true;
            } else {
                $scope.isShowContentArray[i] = false;
            }
        }
        $scope.isCopyMainImage = tmpArr[12] == 1 ? true : false; 
        if ($scope.isCopyMainImage == false){
            $("#popupRight").css("width", "100%");
        } else {
            $("#popupRight").css("width", "75%");
        }
        $('head').append('<link id="bootstrapcss" rel="stylesheet" href="./assets/css/bootstrap.min.css" type="text/css" />');
        if (typeof localStorage !== 'undefined') {
            var loginDTO = JSON.parse(localStorage.getItem("WebAdminLoginDTO"));
            if (loginDTO && loginDTO != null){
                if (loginDTO.infoDTO.role == $scope.roleWebsiteAdmin){
                    $scope.access_token = loginDTO.tokenDTO.access_token;
                    $scope.token_type = loginDTO.tokenDTO.token_type;
                    $scope.ycAppId = loginDTO.ycAppId;
                }
            }
        }
        if ($scope.currContent.description || $scope.currContent.description == ""){
            tinymce.init(
                    {   selector:'textarea#editedDescription',
                        height: 250,
                        plugins: [
                          'advlist autolink lists link image charmap print preview anchor textcolor',
                          'searchreplace visualblocks code fullscreen',
                          'insertdatetime media table contextmenu paste code'
                        ],
                        toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | forecolor backcolor | fontselect | fontsizeselect',
                        fontsize_formats: '8pt 10pt 12pt 14pt 18pt 24pt 36pt',
                        paste_data_images: true,
                        init_instance_callback : function(editor) {
                            editor.setContent($scope.currContent.description);
                          }
                    });
        }
        $scope.dropzoneIds.forEach(function(value){
            $scope.dz.push(createDropzone(value));
        })

        $scope.dz.forEach(initializeDropzone);
    });
});

appBeam.directive('editDirective', function($uibModal) {
    return {
        restrict: 'E',
        template :  "<img src='./assets/images/edit_pen.png' style=' width: 24px; height: 24px; display: inherit;'>",
        link: function(scope, elem, attrs) {
            elem.bind('click', function() {            	 
                scope.$apply(function () {
                    var modalInstance = $uibModal.open({
                        animation: true,
                        ariaLabelledBy: 'modal-title',
                        ariaDescribedBy: 'modal-body',
                        templateUrl: 'mymodal.html',
                        controller: 'ModalController',
                        controllerAs: '$scope',
                        size: 'lg',
                        resolve: {
                            params: function(){
                                return {
                                    name: attrs.name,
                                    category: attrs.category ,
                                    pages: attrs.pages ,
                                    language: attrs.language ,
                                    link: attrs.link ,
                                    displayText: attrs.displaytext ,
                                    shortDescription: attrs.shortdescription ,
                                    description: attrs.description ,
                                    imageId: attrs.imageid ,
                                    categoryOrder: attrs.categoryorder ,
                                    defaultImageUrl: attrs.defaultimageurl ,
                                    video: attrs.video ,
                                    isShowContentArray : attrs.isshowcontentarray 
                                }
                            }
                        }
                    });

                    modalInstance.result.then(function () {
                        // scope.selected = selectedItem;
                        console.log('Modal okay at: ' + new Date());
                    }, function () {
                        console.log('Modal dismissed at: ' + new Date());
                    });
                });
            });
        }
    }
});


appBeam.directive('shareNewsToFacebook', function(){
    function createHTML(href) {
        return '<div class="fb-share-button" ' +
            'data-href="' + href + '" ' +
            'data-layout="button_count">' +
            '</div>';
    }

    return {
        restrict: 'E',
        link: function postLink(scope, elem, attrs) {
            attrs.$observe('link', function (newLink) {
                elem.html(createHTML(newLink));
                if (FB){
                    FB.XFBML.parse(elem[0]);
                }
            });
        }
    }
});

appBeam.directive('numberLikeNewsToFacebook', function(){
    function createHTML(href) {
        return '<div class="fb-like" ' +
            'data-href="' + href + '" ' +
            'data-layout="standard" data-action="like" data-show-faces="true">' +
            '</div>';
    }

    return {
        restrict: 'E',
        link: function postLink(scope, elem, attrs) {
            attrs.$observe('link', function (newLink) {
                elem.html(createHTML(newLink));
                if (FB){
                    FB.XFBML.parse(elem[0]);
                }
            });
        }
    }
});

appBeam.config(['$routeProvider', function($routeProvider) {
    $routeProvider.when('/event', {
        templateUrl : './app/components/event/event.html',
        controller : 'EventCtrl'           	
    }).when('/news', {
        templateUrl : './app/components/news/news.html',
        controller : 'NewsCtrl'
    }).when('/', {
        templateUrl : './app/components/homepage/home.html'
    // }).when('/beam/index_admin', {
    //     templateUrl : './app/components/homepage/home_admin.html'
    }).otherwise({redirectTo:'/'});        
}]);

appBeam.controller('EventCtrl', function($scope,  mainFac) {
	 $scope.mainFac = mainFac;
	 $scope.nextSlide = function() {
         $scope.currSlideIndex = $scope.currSlideIndex + 1 ;
         if ($scope.currSlideIndex >= $scope.slidesImage.length){
             $scope.currSlideIndex = 0;
         }
         $scope.showImageSlide();
        
     }
     $scope.prevSlide= function(){
         $scope.currSlideIndex = $scope.currSlideIndex - 1 ;
         if ($scope.currSlideIndex < 0){
             $scope.currSlideIndex = $scope.slidesImage.length - 1;
         }
         $scope.showImageSlide();
     }
     $scope.showImageSlide = function(){
         for (var i = 0; i < $scope.slidesImage.length; i++ ){
             $scope.slidesImage[i].isShow = false;
         }
         if ($scope.slidesImage[$scope.currSlideIndex]) 
             $scope.slidesImage[$scope.currSlideIndex].isShow = true; 
     }
	 $scope.initializeEvent = function() {
    	 mainFac.getEntryPoint().success(
    			 function(data) {
    				 console.log('getportSuccess: ' + data.error
    						 + ' - ' + data.message);
    				 if (data.error == 0) {
    					 $scope.entryUrl = JSON
    					 .parse(data.message).url;
    					 createCookie("entryUrl",
    							 $scope.entryUrl, 30);
    					 $scope.urlCollectorApi = buildUrl(
    							 $scope.entryUrl,
    							 $scope.beamCollectorPath,
    							 $scope.versionCollectorPath);
    					 onGetDetailEvent($scope) ;
    					 google.maps.event.trigger(mapEvent, "resize");
    				 }
    			 });
     }
	 $scope.initializeMap = function() {            	 
    	 var mapCanvas = document.getElementById('mapEvent');
    	
    	 var mapOptions = {
    			 center: new google.maps.LatLng(10.787767, 106.703777),
    			 zoom: 13,
    			 mapTypeId: google.maps.MapTypeId.ROADMAP
    	 }
    	 mapEvent = new google.maps.Map(mapCanvas, mapOptions);
     }
     
     $scope.radiusToLngLatDistance = function(radius){
         return radius * 360 / (2 * 6371 * Math.PI);
     }

     $scope.drawAreaByTarget = function(){
         var bounds = new google.maps.LatLngBounds();
         mapEvent.fitBounds(bounds);
         for (var i = 0 ; i < $scope.currentTargetList.length; i ++ ){
             $scope.drawDefaultCircle($scope.currentTargetList[i].latitude, 
                                         $scope.currentTargetList[i].longitude, $scope.currentTargetList[i].radius);
             $scope.drawMarker($scope.currentTargetList[i].latitude,$scope.currentTargetList[i].longitude);
             bounds.extend(new google.maps.LatLng($scope.currentTargetList[i].latitude, $scope.currentTargetList[i].longitude));
             var distance = $scope.radiusToLngLatDistance($scope.currentTargetList[i].radius);
             bounds.extend(new google.maps.LatLng($scope.currentTargetList[i].latitude + distance, $scope.currentTargetList[i].longitude + distance));
             bounds.extend(new google.maps.LatLng($scope.currentTargetList[i].latitude - distance, $scope.currentTargetList[i].longitude - distance));
         }
         mapEvent.fitBounds(bounds);
         if (mapEvent.getZoom() > 15) mapEvent.setZoom(15); 
     }
     
     $scope.drawDefaultCircle = function(lat, lng, radius){
         var cityCircle = new google.maps.Circle({
             strokeColor: '#53bfee',
             strokeOpacity: 0.8,
             strokeWeight: 2,
             fillColor: '#53bfee',
             fillOpacity: 0.35,
             map: mapEvent,
             center: new google.maps.LatLng(lat, lng),
             radius: radius*1000
         });
         
     };
     $scope.drawMarker = function(lat, lng){
    	 var image = "./assets/images/ic_beam_marker.png";
         var beachMarker = new google.maps.Marker({
           position: {lat: lat, lng: lng},
           map: mapEvent,
           icon: image
         });
         
     };

    window.onhashchange = function() {
        window.location.href="./";
    };

	 angular.element(document).ready(function() {
         $scope.initializeMap();
         var url = document.URL;
         var stuff = url.split('event?id=');
         if (stuff.length >= 2){
        	 $scope.idEvent = stuff[stuff.length-1];        	 
        	 $scope.initializeEvent();
         }                  
     });
});

appBeam.controller('NewsCtrl', function($scope,  mainFac, $location, $sce) {
    $scope.mainFac = mainFac;
    $scope.sce = $sce;
    $scope.articleTitle = 'This is a article.';

    $scope.currentArticle = {
        mainImgURL: './assets/images/about.jpg',
        title: 'My Title 1',
        url: '#news',
        createdDate: 'April 26th, 2016',
        author: 'Author',
        content: '<h1>This is the content.</h1>'
    };

    $scope.listContentWebPage = [];
    $scope.listOfArticles = [];
    $scope.$location = $location;

    $scope.versionPublicPath = "publicApi/v1";
    $scope.beamCollectorPath = "/_ah/api/";

    $scope.currentLanguage = readCookie("currentLanguage");

    $scope.getEntryPoint = function() {
        mainFac.getEntryPoint().success(
            function(data) {
                console.log('getportSuccess: ' + data.error
                    + ' - ' + data.message);
                if (data.error == 0) {
                    $scope.entryUrl = JSON.parse(data.message).url;
                    createCookie("entryUrl", $scope.entryUrl, 30);
                    $scope.urlPublicApi = buildUrl(
                        $scope.entryUrl,
                        $scope.beamCollectorPath,
                        $scope.versionPublicPath
                    );
                    onGetContentWebPage($scope, getCurrentArticle);
                }
            }
        )
    }

    angular.element(document).ready(function() {
        console.log("NewsCtrl Controller ready: ");

        var url = document.URL;
        var stuff = url.split('news?id=');
        if (stuff.length >= 2){
            $scope.idArticle = stuff[stuff.length-1];
            $scope.getEntryPoint();
        }
    });
});

appBeam
.factory(
        'mainFac',
        [
         '$http',
         function($http) {
             return {

                 getEntryPoint : function() {
                     var urlGetPort = window.location.protocol
                     + "//" + window.location.host
                     + "/get-port";
                     var req = {
                             method : 'GET',
                             async : false,
                             url : urlGetPort,
                             contentType : "application/json; charset=utf-8"
                     }
                     return $http(req);
                 },
                 getLanguages : function(entryUrl) {
                     var result = {
                             url : './assets/translations/GetLanguages.txt',
                             dataType : 'json',
                             method : 'POST',
                             data : '',
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     };
                     return $http(result);
                 },
                 getListPages : function(entryUrl) {
                     var result = {
                             url : './assets/js/txt/GetListPages.txt',
                             dataType : 'json',
                             method : 'POST',
                             data : '',
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     };
                     return $http(result);
                 },

                 // Categories for header
                 getListCategories : function(entryUrl) {
                     var result = {
                             url : './assets/js/txt/GetListCategories.txt',
                             dataType : 'json',
                             method : 'POST',
                             data : '',
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     };
                     return $http(result);
                 },
                 // GET categories for page
                 getListCategoriesByPages : function(entryUrl,
                         pages) {
                     var result = {
                             url : './assets/content/GetListCategoriesByPage.txt',
                             dataType : 'json',
                             method : 'POST',
                             data : '',
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     };
                     return $http(result);
                 },
                 // get contents by categories
                 getListContents : function(entryUrl, category,
                         idLanguage) {
                     var result = {
                             url : './assets/content/GetContents'
                                 + idLanguage + '.txt',
                                 dataType : 'json',
                                 method : 'POST',
                                 data : '',
                                 headers : {
                                     "Content-Type" : "application/json; charset=utf-8"
                                 }
                     };
                     return $http(result);
                 },
                
                 getUpcomingEvents : function(urlRoot, DTO) {
                     var req = {
                             method : 'POST',
                             async : false,
                             url : urlRoot
                             + "/beam/event/upcoming/get",
                             data : JSON.stringify(DTO),
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 getContentWebPage : function(urlRoot, WebsiteContentIndentifyDTO){
                     var req = {
                             method : 'POST',
                             async : false,
                             url : urlRoot + "/public/website/content/get" ,
                             data: JSON.stringify(WebsiteContentIndentifyDTO),
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 getImageByCategory : function(urlRoot, ImageCategoryDTO, ycAppId, token_type, access_token){
                     var req = {
                             method : 'POST',
                             async : false,
                             url : urlRoot + "/user/image/category/urlget" ,
                             data: JSON.stringify(ImageCategoryDTO),
                             headers: {
                                 "Content-Type" : "application/json; charset=utf-8",
                                 'YCAppId': ycAppId,
                                 'Authentication': token_type + " " + access_token
                             }
                     }
                     return $http(req);

                 },

                 getURLImage : function(urlRoot, ImageUrlRequestDTO, ycAppId, token_type, access_token){
                     var req = {
                             method : 'POST',
                             async : false,
                             url : urlRoot + "/user/image/url/get" ,
                             data: JSON.stringify(ImageUrlRequestDTO),
                             headers: {
                                 "Content-Type" : "application/json; charset=utf-8",
                                 'YCAppId': ycAppId,
                                 'Authentication': token_type + " " + access_token
                             }
                     }
                     return $http(req);

                 },
                 putContentWebPage : function(urlRoot, WebsiteContentDTO, ycAppId, token_type, access_token){
                     var req = {
                             method : 'POST',
                             async : false,
                             url : urlRoot + "/admin/website/content/put",
                             data : JSON.stringify(WebsiteContentDTO),
                             headers: {
                                 "Content-Type" : "application/json; charset=utf-8",
                                 'YCAppId': ycAppId,
                                 'Authentication': token_type + " " + access_token
                             }
                     }
                     return $http(req);
                 },
                 onGetUrlPushImage: function (url, ycAppId, token_type, access_token) {
                     var req = {
                             method: 'POST',
                             async: false,
                             url: url,
                             headers: {
                                 'Content-Type': 'application/json',
                                 'YCAppId': ycAppId,
                                 'Authentication': token_type + " " + access_token
                             }
                     }
                     return $http(req);
                 },
                 onUploadImage: function (url, formData, ycAppId, token_type, access_token) {
                     var req = {
                             withCredentials: false,
                             async: false,
                             headers: {
                                 'Content-Type': undefined,
                                 'enctype': 'multipart/form-data',
                                 'YCAppId': ycAppId,
                                 'Authentication': token_type + " " + access_token
                             },
                             transformRequest: angular.identity
                     }
                     return $http.post(url, formData, req);
                 },
                 getTopEvents : function(urlRoot) {

                     var req = {
                             method : 'POST',
                             async : false,
                             url : urlRoot + "/beam/event/top/get",
                             data : '',
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 getSponsorEvents : function(urlRoot) {

                     var req = {
                             method : 'POST',
                             async : false,
                             url : urlRoot + "/beam/event/sponsor/get",
                             data : '',
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 getMainEvents : function(urlRoot) {
                     var req = {
                             method : 'POST',
                             async : false,
                             url : urlRoot + "/beam/event/main/get",
                             data : '',
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 getDetailEvent : function(urlRoot, idEvent) {
                	 var req = {
                             method : 'POST',
                             async : false,
                             url : urlRoot + "/beam/event/details/get",
                             data: JSON.stringify(idEvent),
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 submitMessage : function(urlRoot, contactMessage) {
                     var req = {
                         method : 'POST',
                         async : false,
                         url : urlRoot + "/beam/event/details/get",
                         data: JSON.stringify(contactMessage),
                         headers : {
                             "Content-Type" : "application/json; charset=utf-8"
                         }
                     }
                     return $http(req);
                 },
                 sendMessageOffline : function(urlRoot, contactMessage) {
                     var req = {
                         method : 'POST',
                         async : false,
                         url : urlRoot + "/user/contract/customer/put",
                         data: JSON.stringify(contactMessage),
                         headers : {
                             "Content-Type" : "application/json; charset=utf-8"
                         }
                     }
                     return $http(req);
                 }
             }
         } ]);

function onGetUpcomingEvents($scope, plng, plat) {
    console.log('getUpcomingEvents run');
    var LocationDTO = {
            lng : plng,
            lat : plat
    }
    $scope.mainFac.getUpcomingEvents($scope.urlCollectorApi, LocationDTO)
    .success(
            function(data) {
                // get list payment success
                console.log('getUpcomingEvents success: '
                        + data.message);
                $scope.listMoneyData = [];
                if (data.error == 0) {
                    if (data.message != null && data.message != "") {
                        $scope.listUpcomingEvents = JSON.parse(data.message);
                        $scope.listUpcomingEvents.events.forEach(function(beamEvent){
                            beamEvent.fromTimeStr = $scope.getDateString(beamEvent.fromTime);
                            beamEvent.toTimeStr = $scope.getDateString(beamEvent.toTime);
                            beamEvent.countDown = beamEvent.fromTime - new Date().getTime()/1000 ;
                        })
                    }
                } else {
                    processError(data.error);
                }

            }).error(function(data) {
                console.log('getUpcomingEvents fail: ' + data);
            });
}

function onGetTopEvents($scope) {
    console.log('onGetTopEvents run');
    $scope.mainFac.getTopEvents($scope.urlCollectorApi).success(function(data) {
        // get list payment success
        console.log('getTopEvents success: ' + data.message);
        $scope.listMoneyData = [];
        if (data.error == 0) {
            if (data.message != null && data.message != "") {
                $scope.listTopEvents = JSON.parse(data.message);
                $scope.listTopEvents.events.forEach(function(beamEvent){
                    beamEvent.fromTimeStr = $scope.getDateString(beamEvent.fromTime);
                    beamEvent.toTimeStr = $scope.getDateString(beamEvent.toTime);
                    beamEvent.countDown = new Date().getTime() - beamEvent.fromTime;
                })
            }
        } else {
            processError(data.error);
        }

    }).error(function(data) {
        console.log('getTopEvents fail: ' + data);
    });
}

function onGetImageByCategory($scope, ImageCategoryDTO){
    console.log('onGetImageByCategory run');
    $scope.mainFac.getImageByCategory($scope.urlDataCollectorApi, ImageCategoryDTO, $scope.ycAppId, $scope.token_type, $scope.access_token).success(function(data) {
        console.log('onGetImageByCategory success: ' + data.message);
        if (data.error == 0) {
            if (data.message != null && data.message != "") {
                $scope.listImageCategory = JSON.parse(data.message).images;
            }
        } else {
            processError(data.error);
        }
    }).error(function(data) {
        console.log('onGetImageByCategory fail: ' + data);
    });
}

function onGetURLImage ($scope, ImageUrlRequestDTO){
    console.log('onGetURLImage run');
    $scope.mainFac.getURLImage($scope.urlDataCollectorApi, ImageUrlRequestDTO, $scope.ycAppId, $scope.token_type, $scope.access_token).success(function(data) {
        console.log('onGetURLImage success: ' + data.message);
        if (data.error == 0) {
            if (data.message != null && data.message != "") {
                $scope.currContent.defaultImageUrl = JSON.parse(data.message).url;
            }
        } else {
            processError(data.error);
        }
    }).error(function(data) {
        console.log('onGetURLImage fail: ' + data);
    });
}

function onPutContentWebPage($scope, url) {
    console.log('onPutContentWebPage run');
    $scope.mainFac.putContentWebPage(url, $scope.currContent,  $scope.ycAppId, $scope.token_type, $scope.access_token).success(function(data) {
        // get list payment success
        console.log('putContentWebPage success: ' + data.message);
        if (data.error == 0) {
            if (data.message != null && data.message != "") {
                window.location.reload();
            }
        } else {
            processError(data.error);
        }

    }).error(function(data) {
        console.log('putContentWebPage fail: ' + data);
    });
}

function onGetContentWebPage($scope, func) {
    console.log('onGetContentWebPage run');
    var WebsiteContentIndentifyDTO ={
    		lang: $scope.currentLanguage
	 }
    $scope.mainFac.getContentWebPage($scope.urlPublicApi, WebsiteContentIndentifyDTO).success(function(data) {
        // get list payment success
        console.log('getContentWebPage success: ' + data.message);
        $scope.listContentWebPage = [];
        if (data.error == 0) {
            if (data.message != null && data.message != "") {
                $scope.listContentWebPage = JSON.parse(data.message);
                if ($scope.listContentWebPage.banner_home_video){
                    $scope.mainVideo = $scope.sce.trustAsResourceUrl($scope.listContentWebPage.banner_home_video.video);   
                    $scope.mainVideo_ = $scope.sce.trustAsResourceUrl($scope.listContentWebPage.banner_home_video.video); 
                } else {
                    $scope.mainVideo = $scope.sce.trustAsResourceUrl('https://www.youtube.com/embed/z-P37DJPuPk?rel=0&loop=1&autoplay=1');
                    $scope.mainVideo_ ="z-P37DJPuPk";
                }
               /* if ($scope.listContentWebPage.create_beam_video1){
                    $scope.extraVideo1 = $scope.sce.trustAsResourceUrl($scope.listContentWebPage.create_beam_video1.video);
                } else {
                    $scope.extraVideo1 = $scope.sce.trustAsResourceUrl('https://www.youtube.com/embed/w8ff4BNnaVg?rel=0&loop=1');
                }*/
                if ($scope.listContentWebPage.create_beam_video2){
                    $scope.extraVideo2 = $scope.sce.trustAsResourceUrl($scope.listContentWebPage.create_beam_video2.video);
                    $scope.videoCreateBeam = $scope.sce.trustAsResourceUrl($scope.listContentWebPage.create_beam_video2.video);
                } else {
                    $scope.extraVideo2 = $scope.sce.trustAsResourceUrl('https://www.youtube.com/embed/w8ff4BNnaVg?rel=0&loop=1');
                    $scope.videoCreateBeam = "w8ff4BNnaVg";
                }
                if ($scope.listContentWebPage.create_beam_video3){
                    $scope.extraVideo3 = $scope.sce.trustAsResourceUrl($scope.listContentWebPage.create_beam_video3.video);
                    $scope.videoCreateBeam = $scope.sce.trustAsResourceUrl($scope.listContentWebPage.create_beam_video3.video);
                } else {
                    $scope.extraVideo3 = $scope.sce.trustAsResourceUrl('https://www.youtube.com/embed/w8ff4BNnaVg?rel=0&loop=1&start=45');
                    $scope.videoCreateBeam = "w8ff4BNnaVg";
                }
               /* if ($scope.listContentWebPage.create_beam_video4){
                    $scope.extraVideo4 = $scope.sce.trustAsResourceUrl($scope.listContentWebPage.create_beam_video4.video);
                } else {
                    $scope.extraVideo4 = $scope.sce.trustAsResourceUrl('https://www.youtube.com/embed/w8ff4BNnaVg?rel=0&loop=1');
                }*/
                onInitPlayer();
                if (func)
                    func($scope);
            }
        } else {
            processError(data.error);
        }

    }).error(function(data) {
        console.log('getContentWebPage fail: ' + data);
    });
}


function onGetSponsorEvents($scope) {
    console.log('onGetSponsorEvents run');
    $scope.mainFac.getSponsorEvents($scope.urlCollectorApi).success(function(data) {
        // get list payment success
        console.log('getSponsorEvents success: ' + data.message);
        $scope.listMoneyData = [];
        if (data.error == 0) {
            if (data.message != null && data.message != "") {
                $scope.listSponsorEventDTO = JSON.parse(data.message);
                /*
                 * var VirtualAccountTransactionPagingResultDTO = JSON
                 * .parse(data.message); $scope.listMoneyData =
                 * VirtualAccountTransactionPagingResultDTO.data;
                 * angular.forEach($scope.listMoneyData,function(valueItem,
                 * keyItem) { if(valueItem.amount <0){ valueItem.tempAccount =
                 * valueItem.accountNo; }else{ valueItem.tempAccount =
                 * valueItem.agentId ; }
                 * 
                 * });
                 */
            }
        } else {
            processError(data.error);
        }

    }).error(function(data) {
        console.log('getTopEvents fail: ' + data);
    });
}

function onGetMainEvents($scope) {
    console.log('onGetMainEvents run');
    $scope.mainFac.getMainEvents($scope.urlCollectorApi).success(function(data) {
        // get list payment success
        console.log('onGetMainEvents success: ' + data.message);
        $scope.listMoneyData = [];
        if (data.error == 0) {
            if (data.message != null && data.message != "") {
                $scope.listMainEventDTO = JSON.parse(data.message);   
            }
        } else {
            processError(data.error);
        }

    }).error(function(data) {
        console.log('onGetMainEvents fail: ' + data);
    });
}

function onGetDetailEvent($scope) {	
    console.log('onGetDetailEvent run');
    var eventDTO = {
    		string : $scope.idEvent
    };
    $scope.mainFac.getDetailEvent($scope.urlCollectorApi, eventDTO).success(function(data) {
        // get list payment success
        console.log('onGetDetailEvent success: ' + data.message);
        if (data.error == 0) {
        	if (data.message != null && data.message != "") {
        		$scope.currEvent = JSON.parse(data.message);
        		$scope.currentTargetList = $scope.currEvent.targets;
        		$scope.slidesImage = [];
        		var tmpMainImg = {
        		        isShow : false,
        		        url : $scope.currEvent.mainImageUrl
        		}
        		$scope.slidesImage.push(tmpMainImg);
        		for(var i = 0; i < $scope.currEvent.imageUrls.length; i ++ ) {
                    var tmpImg = {
                            isShow : false,
                            url : $scope.currEvent.imageUrls[i]
                        }             
                    $scope.slidesImage.push(tmpImg);
                }
        		if($scope.currEvent.mainImageUrl !=null){
        			$scope.imgUrl = $scope.currEvent.mainImageUrl;
        		}else{
        			if($scope.currEvent.imageUrls !=null && $scope.currEvent.imageUrls.length >0){
        				$scope.imgUrl = $scope.currEvent.imageUrls[0];
        			}
        		}
        		$scope.currSlideIndex = 0;
                $scope.slidesImage[$scope.currSlideIndex].isShow = true;
//                $scope.currObject = JSON.parse($scope.currEvent.object);
                var timeValid = new Date($scope.currEvent.toTime*1000);
                var timeValidFrom = new Date($scope.currEvent.fromTime*1000);
//                $scope.dateValidString = $scope.monthNames[timeValid.getMonth()] + "-" + timeValid.getDate() + "-" + timeValid.getFullYear();
                $scope.timeTo = timeValid.getFullYear() + "-" + (timeValid.getMonth() + 1) + "-" + timeValid.getDate() +"  " +$scope.addZero(timeValid.getHours()) + ":" +  $scope.addZero(timeValid.getMinutes()) ;
                $scope.timeFrom = timeValidFrom.getFullYear() + "-" + (timeValidFrom.getMonth() + 1) + "-" + timeValidFrom.getDate() +"  " +$scope.addZero(timeValidFrom.getHours()) + ":" +  $scope.addZero(timeValidFrom.getMinutes()) ;;
                $scope.drawAreaByTarget();
                google.maps.event.trigger(mapEvent, "resize");
        	}
        } else {
        	window.location.href="./";
            processError(data.error);
        }

    }).error(function(data) {
        console.log('onGetDetailEvent fail: ' + data);
    });
}

var createArticle = function(content, location){
    return {
        name: content.name,
        defaultImageUrl: content.defaultImageUrl,
        displayText: content.displayText,
        link: content.link,
        absLink: location.protocol() + "://" + location.host() + ":" + location.port() + '/beam/index.html#news?id=' + content.link,
        createdDate: 'April 26th, 2016',
        author: 'Author',
        description: content.description,
        pages: content.pages,
        category: content.category,
        shortDescription: content.shortDescription,
    }
}

var getCurrentArticle = function (scope){
    for (var name in scope.listContentWebPage)
        if (scope.listContentWebPage[name].category == 'News'){
            if (name == scope.idArticle)
                scope.currentArticle = createArticle(scope.listContentWebPage[name], scope.$location);
            else
                scope.listOfArticles.push(createArticle(scope.listContentWebPage[name], scope.$location));
        }
}


//var abc = {{$scope.mainVideo_}};
var player;
var playerBeam;
function onYouTubeIframeAPIReady() {
    console.log("YouTube API ready");

    player = new YT.Player('player', {
        videoId: $scopeFinal.mainVideo_,
        events: {
            'onReady': onPlayerReady,
            'onStateChange': onPlayerStateChange
        }
    });
    
    playerBeam = new YT.Player('playerCreateBeam', {
        videoId: $scopeFinal.videoCreateBeam,
        events: {
            'onReady': onPlayerBeamReady,
            'onStateChange': onPlayerBeamStateChange
        }
    });
    
    
}

function onInitPlayer(){
	 var tag = document.createElement('script');
	 tag.src = "https://www.youtube.com/iframe_api";
	 var firstScriptTag = document.getElementsByTagName('script')[0];
	 firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
}

function onPlayerReady(event) {
    console.log("YouTube video ready");
	player.playVideo();
}

function onPlayerBeamReady(event) {
    console.log("YouTube video ready");
//    playerBeam.playVideo();
}

function onPlayerStateChange(event) {
    switch(event.data) {
        case YT.PlayerState.CUED:
            console.log("YouTube video CUED");
            break;
        case YT.PlayerState.PLAYING:
            console.log("YouTube video PLAYING");
//            isPlaying = true;
//            checkSeek();
            break;
        case YT.PlayerState.BUFFERING:
            console.log("YouTube video BUFFERING");
//            isPlaying = false;
            break;
        case YT.PlayerState.PAUSED:
            console.log("YouTube video PAUSED");
//            isPlaying = false;
            break;
        case YT.PlayerState.ENDED:
            console.log("YouTube video ENDED");
            //isPlaying = false;
			player.playVideo();			
            break;
    }
}

function onPlayerBeamStateChange(event) {
    switch(event.data) {
        case YT.PlayerState.CUED:
            console.log("YouTube video CUED");
            break;
        case YT.PlayerState.PLAYING:
            console.log("YouTube video PLAYING");
//            isPlaying = true;
//            checkSeek();
            break;
        case YT.PlayerState.BUFFERING:
            console.log("YouTube video BUFFERING");
//            isPlaying = false;
            break;
        case YT.PlayerState.PAUSED:
            console.log("YouTube video PAUSED");
//            isPlaying = false;
            break;
        case YT.PlayerState.ENDED:
            console.log("YouTube video ENDED");
            //isPlaying = false;
//			playerBeam.playVideo();			
            break;
    }
}

appBeam.animation('.slide-animation', function () {
    return {
        beforeAddClass: function (element, className, done) {
            var scope = element.scope();

            if (className == 'ng-hide') {
                var finishPoint = element.parent().width();
                if(scope.direction !== 'right') {
                    finishPoint = -finishPoint;
                }
                TweenMax.to(element, 0.5, {left: finishPoint, onComplete: done });
            }
            else {
                done();
            }
        },
        removeClass: function (element, className, done) {
            var scope = element.scope();

            if (className == 'ng-hide') {
                element.removeClass('ng-hide');

                var startPoint = element.parent().width();
                if(scope.direction === 'right') {
                    startPoint = -startPoint;
                }

                TweenMax.fromTo(element, 0.5, { left: startPoint }, {left: 0, onComplete: done });
            }
            else {
                done();
            }
        }
    };
});