var urlRoot = "";
var app = angular.module("myApp", [ 'ngRoute', 'ngLoadingSpinner' ]), permissionList;

app.factory('mytaskFac', [ '$http', function($http) {
    return {
        getListTaskInfo : function(id) {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'mytask/getTaskInfoName/',
                params : {
                    taskId : id
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8",
                }
            }
            return $http(req);
        },
        getMyTask : function() {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'mytask/all/',
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        searchTask : function(keyWord) {
            var req = {
                method : 'POST',
                async : false,
                url : urlRoot + 'mytask/search/',
                dataType : 'json',
                params : {
                    keyword : keyWord
                },
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        getListProject : function() {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'mytask/getProjectByUserId/',
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        getNextWeekTask : function(firstDay, lastDay) {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'mytask/all/',
                params : {
                    firstDay : firstDay,
                    lastDay : lastDay
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        getPreviousWeekTask : function(firstDay, lastDay) {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'mytask/all/',
                params : {
                    firstDay : firstDay,
                    lastDay : lastDay
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        backMyTask : function(date) {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'mytask/back/',
                params : {
                    date : date
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        nextMyTask : function(date) {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'mytask/next/',
                params : {
                    date : date
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        saveMyTask : function(form) {
            var req = {
                method : 'POST',
                async : false,
                url : urlRoot + 'mytask/save/',
                params : {
                    form : form
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        deleteMyTask : function(id) {
            var req = {
                method : 'POST',
                async : false,
                url : urlRoot + 'mytask/delete/',
                params : {
                    id : id
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        advanceSearchTask : function(search) {
            var req = {
                method : 'POST',
                async : false,
                url : urlRoot + 'mytask/searchAdvance/',
                params : {
                    search : search
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        }
    }
} ]);
app.factory('viewTaskFac', [ '$http', function($http) {
    return {
        getListTaskInfo : function() {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'viewtask/getTaskInfo/',
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        searchTaskDefault : function(keyword) {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'viewtask/default_search/',
                dataType : 'json',
                params : {
                    keyword : keyword
                },
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        searchTaskAdvance : function(search) {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'viewtask/advance_search/',
                dataType : 'json',
                params : {
                    search : search
                },
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        }
    }
} ]);

app.factory('importTaskFac', [ '$http', function($http) {
    return {
        getTaskList : function() {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'import',
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        }
    }
} ]);


app.factory('exportTaskFac', [ '$http', function($http) {
    return {
    	getProjectByUser : function(userId) {
            var req = {
                method : 'POST',
                async : false,
                url : urlRoot + 'export/user/' + userId + '/',
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        exportProject : function(projectId) {
        	var req = {
                method : 'POST',
                async : false,
                url : urlRoot + 'export/project_export/' + projectId + '/',
                dataType : 'text',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
        	return $http(req);
        },
        startDownLoadStream : function(filename) {
        	var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'export/file_export/' + filename + '/',
                dataType : 'text',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        }        
    }
} ]);


app.factory(
        'authorizationTaskFac',
        [
         '$http',
         function($http) {
             return {
                 getProjectListByUserPMTL : function(userId) {
                     var req = {
                             method : 'GET',
                             async : false,
                             url : urlRoot + 'authorize_project',
                             dataType : 'json',
                             params: {user_id: userId},
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 getAuthorizedList : function(userId) {
                     var req = {
                             method : 'GET',
                             async : false,
                             url : urlRoot + 'authorized_list',
                             dataType : 'json',
                             params: {user_id: userId},
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 getToResourceList : function(projectId, roleName) {
                     var req = {
                             method : 'GET',
                             async : false,
                             url : urlRoot + 'authorize/to_resource',
                             dataType : 'json',
                             params: {project_id: projectId, role_name: roleName},
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 getFromResourceList : function(projectId, roleName) {
                     var req = {
                             method : 'GET',
                             async : false,
                             url : urlRoot + 'authorize/from_resource',
                             dataType : 'json',
                             params: {project_id: projectId, role_name: roleName},
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 getRoleUserInPj : function(userId, projectId) {
                     var req = {
                             method : 'GET',
                             async : false,
                             url : urlRoot + 'authorize/role_resource',
                             dataType : 'json',
                             params: {project_id: projectId, user_id: userId},
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 saveAuthorization : function(authorizationForm) {
                     var req = {
                             method : 'POST',
                             async : false,
                             url : urlRoot + 'authorize/add',
                             dataType : 'json',
                             data: angular.toJson(authorizationForm),
                             headers : {
                                 "Content-Type" : "application/json; charset=utf-8"
                             }
                     }
                     return $http(req);
                 },
                 deleteAuthorization : function(authorizationId){
                	 var req = {
                			 method:'DELETE',
                			 async:false,
                			 url:urlRoot + 'authorize/delete',
                			 dataType: 'json',
                			 params :{
                				 id : authorizationId
                			 },
                			 headers:{
                				 "Content-Type":"application/json; charset=utf-8"
                			 }
                	 }
                     return $http(req);
                 }
         } 
         }]);


app.factory('groupFac', [ '$http', function($http) {
    return {
        getListGroup : function(projectId) {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'group',
                params : {
                    project_id : projectId
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        getProjectDevs : function(projectId) {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'group/project_devs',
                params : {
                    project_id : projectId
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        getGroupsMembers : function(projectId) {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'group/members',
                params : {
                    project_id : projectId
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        getTeamLeads : function(projectId) {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'group/project_teamleads',
                params : {
                    project_id : projectId
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        saveGroup : function(groupId, groupMembers) {
            var req = {
                method : 'POST',
                async : false,
                url : urlRoot + 'group/post',
                params : {
                    group_id : groupId,
                    group_members : groupMembers
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        },
        deleteGroup : function(groupId) {
            var req = {
                method : 'DELETE',
                async : false,
                url : urlRoot + 'group/delete',
                params : {
                    group_id : groupId,
                },
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        }
    }
} ]);
app.factory(
	'approveFac',
	[
		'$http',
		function($http) {
			return {
				getResourcesCanApprove : function(suppervisiorId,projectId) {
					var req = {
							method : 'POST',
							async : false,
							url : urlRoot + 'resource/canApprove',
							params : {suppervisiorId : suppervisiorId, projectId: projectId},
							dataType : 'application/json',
							headers : {
								"Content-Type" : "application/json; charset=utf-8"
							}
					}
					return $http(req);
				},
				getAssignmentForApprove : function(resourceId) {
					var req = {
							method : 'POST',
							async : false,
							url : urlRoot + 'assignment/canApprove',
							params : {resourceId : resourceId},
							dataType : 'application/json',
							headers : {
								"Content-Type" : "application/json; charset=utf-8"
							}
					}
					return $http(req);
				}
			}
}]);
app.factory('syncFac', [ '$http', function($http) {
    return {
    	synchronize : function() {
            var req = {
                method : 'POST',
                async : false,
                url : urlRoot + 'sync',
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8"
                }
            }
            return $http(req);
        }        
    }
} ])

// Permission
app.factory('permissions', function($rootScope) {
	  var permissionList = [];
	  return {
	    setPermissions: function(permissions) {
	      permissionList = permissions;
	      $rootScope.$broadcast('permissionsChanged');
	    },
	    hasPermission: function (permission) {
	      permission = permission.trim();
	      for(i = 0; permissionList!= null &&  i< permissionList.length; i++) {
	        if (typeof permissionList[i] !== 'string') {
	          return false;
	        }
	        if (permissionList[i].trim() === permission)
	        	return true;
	      };
	      return false;
	    }
	  };
	});
app.factory('authInterceptor', function($q, $location) {
	  return {
	    responseError(response) {
	        console.log('401, 403');
	      if(response.status === 401 || response.status === 403) {

	        $location.path('/unauthorized');
	      }
	      return $q.reject(response);
	    }
	  };
	}).config(function($httpProvider) {
		  //$httpProvider.interceptors.push('authInterceptor');
	});

app.factory('headerFac', [ '$http', function($http) {
    return {
    	logout : function() {
            var req = {
                method : 'GET',
                async : false,
                url : urlRoot + 'logout',
                dataType : 'json',
                headers : {
                    "Content-Type" : "application/json; charset=utf-8",
                }
            }
            return $http(req, function(response){
            	console.log(response.header)
            });
        },
        getUserFullName : function(){
        	var req = {
        			method: 'POST',
        			async : false,
        			url : urlRoot + 'user/getUserFullName',
        			dataType : 'json',
        			headers : {
                        "Content-Type" : "application/json; charset=utf-8"
                    }
                }
                return $http(req);
        	},
        }
}])

app.factory('loadingErrorMessage', ['$http', function($http){
	return {
		getContentErrorMessage: function(){
			var req = {
					method: 'GET',
					async: false,
					url: './resources/json/messageConfig.json',
					dataType: 'json',
					headers: {
						"Content-Type" : "application/json; charset=utf-8"
					}
			}
			return $http(req);
		}
	}
}]);
app.config(function($routeProvider, $locationProvider) {
	$.get(urlRoot + 'api/UserPermission', function(data) {
		  permissionList = data;
		  console.log(data);
//		  angular.bootstrap(document, ['myApp']);
		});
    $routeProvider.when('/viewtask', {
        templateUrl : 'views/viewtask.html',
        controller : 'viewTaskCtrl'
    }).when('/', {
        templateUrl : 'views/mytask.html',
        controller : 'myTaskCtrl'
    }).when('/mytask', {
        templateUrl : 'views/mytask.html',
        controller : 'myTaskCtrl'
    }).when('/import', {
        templateUrl : 'views/import.html',
        controller : 'importCtrl'
    }).when('/approve', {
        templateUrl : 'views/approve.html',
        controller : 'approveCtrl'
    }).when('/mapping-name', {
        templateUrl : 'views/mapping-name.html',
        controller : 'mappingNameCtrl'
    }).when('/group', {
        templateUrl : 'views/group.html',
        controller : 'groupCtrl'
    });
    $locationProvider.html5Mode(true);
});

app.run(function(permissions) { 
	
	  permissions.setPermissions(permissionList);

	});
