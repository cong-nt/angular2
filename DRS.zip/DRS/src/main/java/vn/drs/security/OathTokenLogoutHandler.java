package vn.drs.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

public class OathTokenLogoutHandler implements LogoutSuccessHandler {

	private static org.slf4j.Logger logger = org.slf4j.LoggerFactory
			.getLogger(OathTokenLogoutHandler.class);

	TokenStore tokenstore;

	public TokenStore getTokenstore() {
		return tokenstore;
	}

	public void setTokenstore(TokenStore tokenstore) {
		this.tokenstore = tokenstore;
	}

	@Override
	public void onLogoutSuccess(HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse,
			Authentication paramAuthentication) throws IOException,
			ServletException {
		removeaccess(paramHttpServletRequest);
		paramHttpServletResponse.getOutputStream().write(
				"You Have Logged Out successfully.".getBytes());

	}

	public void removeaccess(HttpServletRequest req) {

		String token = req.getParameter("access_token");
		OAuth2AccessToken authToken = tokenstore.readAccessToken(token);
		if (authToken != null) {
			tokenstore.removeAccessToken(authToken);
		}
		logger.info("\n\tAccess Token Removed Successfully!!!!!!!!");
	}
}
