package vn.drs.security;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import vn.drs.entity.User;
import vn.drs.enums.ErrorCode;
import vn.drs.enums.RoleEnum;
import vn.drs.hibernate.dao.UserDao;

/**
 * @author duy
 */
public class DefaultAuthenticationProvider implements AuthenticationProvider {

	private UserDao userDao;

	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		UsernamePasswordAuthenticationToken token = (UsernamePasswordAuthenticationToken) authentication;
		String loginName = token.getName();
		String loginPassword = (String) token.getCredentials();
		User user = userDao.getByEmail(loginName);
		if (user == null) {
			throw new UsernameNotFoundException(
					ErrorCode.ERR_INCORRECT_USRPWD.name());
		}

		if (!userDao.authentication(user, loginPassword)) {
			throw new BadCredentialsException(
					ErrorCode.ERR_INCORRECT_USRPWD.name());
		}

		return new UsernamePasswordAuthenticationToken(user,
				user.getPassword(), authorities(user));
	}

	public static List<GrantedAuthority> authorities(User user) {

		List<GrantedAuthority> result = new ArrayList<GrantedAuthority>();
		if (user != null) {
			result.add(new SimpleGrantedAuthority(RoleEnum.ROLE_USER.name()));
			result.add(new SimpleGrantedAuthority(RoleEnum.ROLE_CLIENT.name()));
		}
		return result;
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return UsernamePasswordAuthenticationToken.class.equals(authentication);
	}

	public UserDao getUserDao() {
		return userDao;
	}

	@Autowired
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
}
