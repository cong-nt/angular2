package vn.drs.constant;

/**
 * <h5>Cac bien hang so</h5>
 *
 */
public interface Constant {
    final static String FORMAT_YYYYMMDD = "yyyy/MM/dd";
    final static String FORMAT_MMDDYYYY = "MM/dd/yyyy";
    final static String FORMAT_YYYYMMDD_WITHOUT_SLASH = "yyyyMMdd";
    final static String FORMAT_MMDDYY = "MM/dd/yy";

    final static String VALID = "valid";
    final static String ID = "id";

    final static Integer WORK_STATUS_DISAPPROVED = 3;

    final static Integer WORK_STATUS_APPROVED = 2;

    final static Integer WORK_STATUS_SENT = 1;

    final static Integer WORK_STATUS_DRAFT = 0;

    final static String UID = "UID";

    final static String RESOURCE = "Resource";

    final static String NAME = "Name";

    final static String DESCRIPTION = "Description";

    final static String START = "Start";

    final static String END = "End";

    final static String ERROR = "error";

    final static String MIN_DATE = "minDate";

    final static String MAX_DATE = "maxDate";

    final static String LIST_TASK = "listTask";

    final static String BASSIGNMENT_ID = "BAssignment.id";

    final static String WOR_PLAN_DATE = "worPlanDate";

    final static String WOR_WORK_DATE = "worWorkDate";

    final static String WOR_STATUS = "worStatus";

    static enum taskInfo {
        STATUS(1), BUSINESS(2), PHASE(3), WORK(4), MODULE(5);
        private final Integer value;

        taskInfo(Integer value) {
            this.value = value;
        }

        public Integer getValue() {
            return value;
        }
    };
}
