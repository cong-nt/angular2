package vn.drs.core.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.googlecode.genericdao.dao.hibernate.GenericDAOImpl;

import vn.drs.entity.AbstractEntity;
import vn.drs.util.Utils;

/**
 * @author duy
 */
public class BaseDaoImpl<T extends AbstractEntity> extends
		GenericDAOImpl<T, String> implements BaseDao<T> {

	@Autowired
    protected SessionFactory sessionFactory;
	
	public BaseDaoImpl() {
		super();
	}

	public BaseDaoImpl(Class<T> entityClass) {
		super();
		this.persistentClass = entityClass;
	}

	@Autowired
	public void anyMethodName(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
	}

	public T merge(T entity) {
		return super._merge(entity);
	}

	public void detach(T entity) {
		this.getSession().evict(entity);
	}

	@Override
	public T saveOrMerge(T entity) {
		if (entity.getId() != null) {
			return merge(entity);
		} else {
			save(entity);
			return entity;
		}
	}
	
	@Override
	public T replaceWithExistingAttr(T entity) {
		// get existing entity
		T existingEntity = find(entity.getId());
		try {
			Utils.replaceNullProperties(existingEntity, entity);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		return entity;
	}

	public T mergeWithExistingAttr(T entity) {
		return merge(replaceWithExistingAttr(entity));
	}
}
