package vn.drs.core.dao;

import com.googlecode.genericdao.dao.hibernate.GenericDAO;

import vn.drs.entity.AbstractEntity;

/**
 * @author duy
 */
public interface BaseDao<T extends AbstractEntity> extends GenericDAO<T, String> {
	T merge(T entity);
	T saveOrMerge(T entity);
	void detach(T entity);
	/**
	 * sometime we only want to update some properties(not all), we have to load old entity
	 * and set it manually. By calling this method, any null property and empty string of updating entity
	 * will be replaced by property of persistent entity.
	 * Note that primitive property and property with default value will not affect because it never be null.
	 * Consider changing primitive type to wrapper class to make it work.
	 * @param entity
	 * @return
	 */
	T mergeWithExistingAttr(T entity);
	
	/**
	 * replace any null properties of transient entity with persistent entity.
	 * this function is differ from function {@link BaseDao#mergeWithExistingAttr(AbstractEntity)} that
	 * it not calling function {@link #merge(AbstractEntity)}. It's only return transient entity.
	 * @param entity
	 * @return merged transient entity
	 */
	T replaceWithExistingAttr(T entity);
}
