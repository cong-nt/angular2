package vn.drs.core.dao;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vn.drs.entity.AbstractEntity;

@Repository
public class HibernateDAOFactory extends DAOFactory {  
	  
	@Autowired	
	SessionFactory sessionFactory;
	
    public <T extends AbstractEntity> BaseDao<T> instantiateDAO(Class<T> entityClass) {  
    	BaseDaoImpl<T> dao = new BaseDaoImpl<T>(entityClass);
    	dao.setSessionFactory(sessionFactory);    
        return dao;
    }  
  
}