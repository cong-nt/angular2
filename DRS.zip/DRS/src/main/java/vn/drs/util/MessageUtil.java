package vn.drs.util;

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.i18n.LocaleContextHolder;

/**
 * The utility class which supports for the parameterization and
 * internationalization of such messages.
 * 
 * This is wrapper of {@link org.springframework.context.MessageSource}.
 * 
 * @author duy
 * 
 */
public class MessageUtil {

	private MessageUtil() {
	}

	private static MessageSource messageSource;

	static {
		ApplicationContext applicationContext = ApplicationContextUtils
				.getApplicationContext();
		messageSource = applicationContext.getBean(MessageSource.class);
	}

	/**
	 * Try to resolve the message using all the attributes contained within the
	 * {@code MessageSourceResolvable} argument that was passed in.
	 * <p>
	 * NOTE: We must throw a {@code NoSuchMessageException} on this method since
	 * at the time of calling this method we aren't able to determine if the
	 * {@code defaultMessage} property of the resolvable is null or not.
	 * 
	 * @param resolvable
	 *            value object storing attributes required to properly resolve a
	 *            message
	 * @return the resolved message
	 */
	public static String getMessage(MessageSourceResolvable resolvable) {
		Locale currentLocale = LocaleContextHolder.getLocale();
		return messageSource.getMessage(resolvable, currentLocale);
	}

	/**
	 * Try to resolve the message. Treat as an error if the message can't be
	 * found.
	 * 
	 * @param code
	 *            the code to lookup up, such as 'calculator.noRateSet'
	 * @param args
	 *            Array of arguments that will be filled in for params within
	 *            the message (params look like "{0}", "{1,date}", "{2,time}"
	 *            within a message), or {@code null} if none.
	 * @return the resolved message
	 */
	public static String getMessage(String code, Object[] args) {
		Locale currentLocale = LocaleContextHolder.getLocale();
		return messageSource.getMessage(code, args, currentLocale);
	}

	/**
	 * Try to resolve the message. Treat as an error if the message can't be
	 * found.
	 * 
	 * @param code
	 *            the code to lookup up, such as 'calculator.noRateSet'
	 * @return the resolved message
	 */
	public static String getMessage(String code) {
		Locale currentLocale = LocaleContextHolder.getLocale();
		return messageSource.getMessage(code, null, currentLocale);
	}

	/**
	 * Try to resolve the message. Return default message if no message was
	 * found.
	 * 
	 * @param code
	 *            the code to lookup up, such as 'calculator.noRateSet'. Users
	 *            of this class are encouraged to base message names on the
	 *            relevant fully qualified class name, thus avoiding conflict
	 *            and ensuring maximum clarity.
	 * @param args
	 *            array of arguments that will be filled in for params within
	 *            the message (params look like "{0}", "{1,date}", "{2,time}"
	 *            within a message), or {@code null} if none.
	 * @param defaultMessage
	 *            String to return if the lookup fails
	 * @return the resolved message if the lookup was successful; otherwise the
	 *         default message passed as a parameter
	 */
	public static String getMessage(String code, Object[] args,
			String defaultMessage) {
		Locale currentLocale = LocaleContextHolder.getLocale();
		return messageSource.getMessage(code, args, defaultMessage,
				currentLocale);
	}
}
