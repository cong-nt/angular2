package vn.drs.util;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import net.sf.jni4net.Bridge;
import util.Util;

public class MppUtil {

    private static MppUtil singleton;

    public static MppUtil instance() {
        synchronized (MppUtil.class) {
            if (singleton == null) {
                singleton = new MppUtil();
                try {
                    singleton.bridge();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return singleton;
        }
    }

    private void bridge() throws Exception {
        bridge("Util.j4n.dll");
    }

    private void bridge(String libPath) throws Exception {
        URL url = Util.class.getProtectionDomain().getCodeSource().getLocation();
        File libFile = new File(url.toURI());
        File parent = libFile.getParentFile();
        File fileJ4n = new File(parent, libPath);
        if (fileJ4n.exists()) {
            Bridge.setVerbose(true);
            Bridge.init(parent);
            Bridge.LoadAndRegisterAssemblyFrom(fileJ4n);
        }
    }

    public void openFileMPP(String fileMpp) {
        Util.openApplication("");
        File file = new File(fileMpp);
        Util.openFileMPP(file.getAbsolutePath());
    }

    public void write(Integer resourceID, Integer taskID, Double duration, String date) throws IOException {
        Util.write("", resourceID, taskID, (int) (duration * 60), date);
    }

    public void saveNewFileMPP(String fileMpp) {
        File file = new File(fileMpp);
        Util.saveNewFileMPP(file.getAbsolutePath());
    }

    public void closeCurrentFileMPP(boolean isSave) {
        Util.closeCurrentFileMPP(isSave);
    }
}
