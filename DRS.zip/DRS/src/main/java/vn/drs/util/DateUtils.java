package vn.drs.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import vn.drs.constant.Constant;

/**
 * <h5>Cac ham common xu ly ngay thang</h5>
 * <p>
 * Cac ham common xu ly ngay thang
 * </p>
 *
 */
public class DateUtils {

    /**
     * <p>
     * Chuyen chuoi sang ngay
     * </p>
     * 
     * @param string
     *            chuoi ngay kieu format yyyy/MM/dd
     * @return ngay
     */
    public static Date stringToDate(String string) {
        SimpleDateFormat formatter = new SimpleDateFormat(
                Constant.FORMAT_YYYYMMDD);
        try {
            Date date = formatter.parse(string);
            return date;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * <p>
     * Chuyen chuoi sang ngay
     * </p>
     * 
     * @param string
     *            chuoi ngay
     * @param format
     *            format cua ngay
     * @return ngay
     */
    public static Date stringToDate(String string, String format) {
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        try {
            Date date = formatter.parse(string);
            return date;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * <p>
     * Chuyen doi ngay sang chuoi
     * </p>
     * 
     * @param date
     *            ngay
     * @return ngay kieu chuoi yyyy/MM/dd
     */
    public static String dateToString(Date date) {
        if (date != null) {
            SimpleDateFormat sdf = new SimpleDateFormat(
                    Constant.FORMAT_YYYYMMDD);
            String stringDate = sdf.format(date);
            return stringDate;
        } else {
            return "";
        }
    }

    /**
     * <p>
     * Chuyen doi ngay sang chuoi
     * </p>
     * 
     * @param date
     *            ngay
     * @return ngay kieu chuoi yyyyMMdd
     */
    public static String dateToStringWithoutFlash(Date date) {
        if (date != null) {
            SimpleDateFormat sdf = new SimpleDateFormat(
                    Constant.FORMAT_YYYYMMDD_WITHOUT_SLASH);
            String stringDate = sdf.format(date);
            return stringDate;
        } else {
            return "";
        }
    }

    /**
     * <p>
     * Chuyen ngay qua kieu String
     * </p>
     * 
     * @param date
     *            Ngay
     * @param format
     *            Kieu format
     * @return Ngay (kieu String)
     */
    public static String dateToString(Date date, String format) {
        if (date != null) {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            String stringDate = sdf.format(date);
            return stringDate;
        } else {
            return "";
        }
    }

    /**
     * <p>
     * So sanh ngay
     * </p>
     * <p>
     * -1: neu ngay 1 < ngay 2
     * </p>
     * <p>
     * 0: neu ngay 1 = ngay 2
     * </p>
     * <p>
     * 1: neu ngay 1 > ngay 2
     * </p>
     * 
     * @param date1
     *            ngay 1
     * @param date2
     *            ngay 2
     * @return int
     */
    public static int compareDate(Date date1, Date date2) {
        SimpleDateFormat math = new SimpleDateFormat("yyyyMMdd");
        Long date1asLong = new Long(math.format(date1));
        Long date2asLong = new Long(math.format(date2));
        return date1asLong.compareTo(date2asLong);
    }

    /**
     * <p>
     * Bo gio, phut, giay ra khoi ngay
     * </p>
     * 
     * @param date
     *            Ngay
     * @return Ngay
     */
    public static Date removeTime(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    /**
     * <p>
     * Lay gio, phut, giay cuoi cung trong ngay
     * </p>
     * 
     * @param date
     *            Ngay
     * @return Ngay, gio
     */
    public static Date midnight(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        return calendar.getTime();
    }

    /**
     * <p>
     * Lay ngay chu nhat
     * </p>
     * 
     * @return Ngay chu nhat
     */
    public static Date getEndDateOfWeek() {
        // Get calendar set to current date and time
        Calendar c = Calendar.getInstance();
        // Set the calendar to Monday of the current week
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        c.set(Calendar.HOUR, 0);
        c.set(Calendar.MINUTE, 0);
        c.add(Calendar.DATE, 6);
        return c.getTime();
    }

    /**
     * <p>
     * Lay ngay thu 2
     * </p>
     * 
     * @return Ngay thu 2
     */
    public static Date getStartDateOfWeek() {
        // Get calendar set to current date and time
        Calendar c = Calendar.getInstance();
        // Set the calendar to Monday of the current week
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        c.set(Calendar.HOUR, 0);
        c.set(Calendar.MINUTE, 0);
        return c.getTime();
    }

    /**
     * <p>
     * Lay ngay thu 2
     * </p>
     * 
     * @param date
     *            Ngay trong tuan
     * @return Ngay thu 2
     */
    public static Date getStartDateOfWeek(Date date) {
        // Get calendar set to current date and time
        Calendar c = toCalendar(date);
        // Set the calendar to Monday of the current week
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        c.set(Calendar.HOUR, 0);
        c.set(Calendar.MINUTE, 0);
        return c.getTime();
    }

    /**
     * <p>
     * Lay ngay chu nhat
     * </p>
     * 
     * @param date
     *            Ngay trong tuan
     * @return Ngay chu nhat
     */
    public static Date getEndDateOfWeek(Date date) {
        // Get calendar set to current date and time
        Calendar c = toCalendar(date);
        // Set the calendar to Monday of the current week
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        c.set(Calendar.HOUR, 0);
        c.set(Calendar.MINUTE, 0);
        c.add(Calendar.DATE, 6);
        return c.getTime();
    }

    /**
     * <p>
     * Chuyen kieu ngay thanh kieu calendar
     * </p>
     * 
     * @param date
     *            Ngay
     * @return Calendar
     */
    public static Calendar toCalendar(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }

    /**
     * <p>
     * Kiem tra string kieu ngay
     * </p>
     * 
     * @param dateToValidate
     *            String date
     * @param dateFromat
     *            Kieu format
     * @return True neu dung la ngay, false neu khong phai ngay
     */
    public static boolean isDate(String dateToValidate, String dateFromat) {
        if (dateToValidate == null) {
            return false;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
        sdf.setLenient(false);
        try {
            // if not valid, it will throw ParseException
            Date date = sdf.parse(dateToValidate);
            System.out.println(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

}