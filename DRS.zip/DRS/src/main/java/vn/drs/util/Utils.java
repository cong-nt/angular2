package vn.drs.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.util.StringUtils;

/**
 * @author duy
 */
public class Utils {

    private Utils() {
    }

    /**
     * Any null properties of destination object will be replaced by source
     * object.
     * 
     * @param source
     * @param destinate
     * @throws Exception
     */
    public static void replaceNullProperties(Object source, Object destinate)
            throws Exception {
        if (source.getClass() != destinate.getClass()) {
            throw new Exception(
                    "Source and destination must be the same class");
        }
        // find all null properties of destination object
        List<Field> nullFields = getNullFields(destinate);
        for (Field field : nullFields) {
            Object value = PropertyUtils.getProperty(source, field.getName());
            PropertyUtils.setProperty(destinate, field.getName(), value);
        }
    }

    public static List<Field> getNullFields(Object obj) {
        List<Field> fields = new ArrayList<Field>();
        Field[] attributes = obj.getClass().getDeclaredFields();
        for (Field field : attributes) {
            try {
                Object value = PropertyUtils.getProperty(obj, field.getName());
                if (value == null) {
                    fields.add(field);
                } else if ((value instanceof String)
                        && ((String) value).isEmpty()) {
                    fields.add(field);
                }
            } catch (Exception e) {
                // ignore unknown field
            }
        }
        return fields;
    }

    public static Integer convertObjectToInt(Object str) {
        if (str == null || StringUtils.isEmpty(str)) {
            return null;
        }
        return (Integer) (str);
    }
}
