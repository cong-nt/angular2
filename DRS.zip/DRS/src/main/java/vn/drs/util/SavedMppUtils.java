package vn.drs.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

public class SavedMppUtils {

    public void transformToServer(MultipartFile file, String name) throws IOException {
        String rootPath = null;
        String fPath = null;
        String fServerPath = null;
        if (!file.isEmpty()) {
            byte[] bytes = file.getBytes();
            // Creating the directory to store file
            rootPath = System.getProperty("catalina.home");
            fPath = rootPath + File.separator + "upload";
            File dir = new File(fPath);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            fServerPath = dir.getAbsolutePath() + File.separator + name;
            // Create the file on server
            File serverFile = new File(fServerPath);
            BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
            stream.write(bytes);
            stream.close();

        }
    }

}
