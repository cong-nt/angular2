package vn.drs.service;

import java.util.List;

import vn.drs.entity.BAssignment;

public interface BAssignmentService {
    public List<BAssignment> getListAssignmentByResourceId(Integer resourceId);
}
