package vn.drs.service;

import java.util.List;

import vn.drs.entity.BResource;
import vn.drs.synchronize.model.PProjectUser;

public interface BResourceService {

    // Lay tat ca resouce co the duoc uy quyen den dua vao role cua resource
    // hien tai trong du an do
    public List<BResource> getToResourceAuthorization(int projectId,
            String resourceRoleName);

    // Lay tat ca resouce co the uy quyen dua vao role cua resource hien tai
    // trong du an do
    public List<BResource> getFromResourceAuthorization(int projectId,
            String resourceRoleName);

    // Lay resouce va role cua resource do voi userId va projectId
    public List<BResource> getResourceByUserAndPj(int userId, int projectId);

    // Luu resource
    public void saveBResource(BResource bResource);

    /* Lay nhung resource theo supervisior va projectId co the approve duoc */
    public List<BResource> getResourceCanApprove(Integer userId,
            Integer projectId);

    public List<BResource> getAllResource();

    // Lay danh sach dev trong du an chua thuoc group nao
    List<BResource> getProjectDevs(int projectId) throws Exception;

    // Lay danh sach nhom trong du an
    List<BResource> getProjectGroups(int projectId) throws Exception;

    // Lay danh sach teamlead trong du an
    List<BResource> getProjectTeamLeads(int projectId) throws Exception;

    // Lay danh sach cac thanh vien da co nhom trong du an
    List<BResource> getProjectGroupMembers(int projectId) throws Exception;

    // Luu group
    void saveOrUpdateGroup(int groupId, Integer... resourceIds)
            throws Exception;

    // Xoa group
    void deleteGroup(int groupId) throws Exception;

    // Dong bo resource
    void syncResource(List<PProjectUser> pProjectUsers) throws Exception;
	
    // Lay tat ca resource cua project
    public List<BResource> getProjectResource(Integer id);
}
