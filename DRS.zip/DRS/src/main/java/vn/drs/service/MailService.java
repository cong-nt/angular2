package vn.drs.service;

import java.util.Date;
import java.util.List;

import vn.drs.entity.BResource;

public interface MailService {

    boolean sendDailyMail(List<BResource> resources) throws Exception;

    boolean sendRemindActualEffort(BResource resources) throws Exception;

    boolean sendAuthorize(BResource resource, BResource authorizer, Date fromDate,
            Date toDate, String autReasons) throws Exception;

    boolean sendDestroyAuthorize(BResource resource, BResource authorizer,
            Date fromDate, Date toDate, String autReasons) throws Exception;

    boolean sendExpiredAuthorizeToAuthorizer(BResource resource,
            BResource authorizedUser, Date fromDate, Date toDate,
            String autReasons) throws Exception;

    boolean sendExpiredAuthorizeToAuthorizedUser(BResource resource,
            BResource authorizer, Date fromDate, Date toDate, String autReasons)
            throws Exception;

    boolean sendDisapprovalTask(BResource resource, String disapprovalPerson,
            String contentDisapproval) throws Exception;

    boolean sendImportSchedual(List<BResource> resource) throws Exception;

}
