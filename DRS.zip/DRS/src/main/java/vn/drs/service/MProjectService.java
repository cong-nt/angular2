package vn.drs.service;

import java.util.List;

import vn.drs.entity.MProject;
import vn.drs.synchronize.model.PProject;

public interface MProjectService {
    
    public List<MProject> getProjectByPMTL(int userId);

    /**
     * <p>
     * Lay thong tin du an dua vao ngay ten du an
     * </p>
     * 
     * @param prjName
     *            project name
     * @return project
     */
    MProject getProjectByName(String prjName);

    /**
     * <p>
     * Lay thong tin du an dua vao ngay project id
     * </p>
     * 
     * @param projectId
     *            project Id
     * @return project
     */
    public MProject getProjectById(int projectId);

    /**
     * <p>
     * Lay danh sach du an ma nhan vien tham gia
     * </p>
     * 
     * @param userId
     *            user Id
     * @return project
     */
    public List<MProject> getProjectByUserId(int userId);
    
    // Dong bo project
    void syncProject(List<PProject> pProjects) throws Exception;
    
    /**
     * <p>
     * Luu project
     * </p>
     * 
     * @param mProject
     *            Doi tuong project
     * @return none
     */
    public void saveProject(MProject mProject);
}
