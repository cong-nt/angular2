package vn.drs.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.mail.Address;
import javax.mail.Message.RecipientType;
import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import freemarker.template.Configuration;
import vn.drs.service.MailService;
import vn.drs.entity.BResource;;

@Service("MailServiceImpl")
public class MailServiceImpl implements MailService {

    @Autowired
    JavaMailSender mailSender;

    @Autowired
    private Configuration freemarkerConfiguration;

    private boolean sendMail(String subject, String content, String... toMails)
            throws Exception {
        MimeMessage email = mailSender.createMimeMessage();
        Multipart multipart = new MimeMultipart("alternative");
        email.addFrom(new Address[] { new InternetAddress(
                ((JavaMailSenderImpl) mailSender).getUsername()) });

        InternetAddress[] addresses = new InternetAddress[toMails.length];

        for (int i = 0; i < toMails.length; i++)
            addresses[i] = new InternetAddress(toMails[i]);

        email.addRecipients(RecipientType.TO, addresses);
        email.setSubject(subject, "UTF-8");
        MimeBodyPart htmlPart = new MimeBodyPart();
        htmlPart.setContent(content, "text/html; charset=utf-8");
        multipart.addBodyPart(htmlPart);
        email.setContent(multipart);
        mailSender.send(email);
        return true;
    }

    enum MailTemplate {
        DAILY_MAIL, REMIND_ACTUAL_EFFORT, AUTHORIZE, DESTROY_AUTHORIZE, EXPIRED_AUTHORIZE_TO_AUTHORIZER, EXPIRED_AUTHORIZE_TO_AUTHORIZED_USER, REGISTER_EVENT_MAIL, DISAPPROVAL_TASK, IMPORT_SCHEDUAL;
    }

    private String getFreeMarkerTemplateContent(Map<String, Object> model,
            MailTemplate template) throws Exception {
        StringBuffer content = new StringBuffer();
        switch (template) {
        case DAILY_MAIL:
            content.append(FreeMarkerTemplateUtils
                    .processTemplateIntoString(freemarkerConfiguration
                            .getTemplate("dailyMail.txt", "utf-8"), model));
            break;
        case REMIND_ACTUAL_EFFORT:
            content.append(
                    FreeMarkerTemplateUtils
                            .processTemplateIntoString(
                                    freemarkerConfiguration.getTemplate(
                                            "remindActualEffort.txt", "utf-8"),
                                    model));
            break;
        case AUTHORIZE:
            content.append(FreeMarkerTemplateUtils
                    .processTemplateIntoString(freemarkerConfiguration
                            .getTemplate("authorize.txt", "utf-8"), model));
            break;

        case DESTROY_AUTHORIZE:
            content.append(
                    FreeMarkerTemplateUtils
                            .processTemplateIntoString(
                                    freemarkerConfiguration.getTemplate(
                                            "destroyAuthorize.txt", "utf-8"),
                                    model));
            break;

        case EXPIRED_AUTHORIZE_TO_AUTHORIZER:
            content.append(FreeMarkerTemplateUtils.processTemplateIntoString(
                    freemarkerConfiguration.getTemplate(
                            "expiredAuthorizeToAuthorizer.txt", "utf-8"),
                    model));
            break;

        case EXPIRED_AUTHORIZE_TO_AUTHORIZED_USER:
            content.append(FreeMarkerTemplateUtils.processTemplateIntoString(
                    freemarkerConfiguration.getTemplate(
                            "expiredAuthorizeToAuthorizedUser.txt", "utf-8"),
                    model));
            break;
        case DISAPPROVAL_TASK:
            content.append(
                    FreeMarkerTemplateUtils
                            .processTemplateIntoString(
                                    freemarkerConfiguration.getTemplate(
                                            "disapprovalTask.txt", "utf-8"),
                                    model));
            break;
        case IMPORT_SCHEDUAL:
            content.append(
                    FreeMarkerTemplateUtils
                            .processTemplateIntoString(
                                    freemarkerConfiguration.getTemplate(
                                            "importSchedual.txt", "utf-8"),
                                    model));
            break;
        default:
            break;
        }
        return content.toString();
    }

    /*
     * Gui Daily Mail luc 16:00
     */
    @Override
    public boolean sendDailyMail(List<BResource> resources) throws Exception {
        boolean isSucessSendEmail = true;
        Map<String, Object> model = new HashMap<String, Object>();
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        model.put("date", dateFormat.format(date));
        String content = getFreeMarkerTemplateContent(model,
                MailTemplate.DAILY_MAIL);
        for (BResource resource : resources) {
            String subject = "[Daily report]["
                    + resource.getMProject().getPrjName()
                    + "] - Cập nhật Actual Effort";
            String toMails = resource.getMUsers().getUsrEmail();
            isSucessSendEmail = sendMail(subject, content, toMails);
        }
        return isSucessSendEmail;
    }

    /*
     * Gui mail nhac nho cap nhat Actual Effort
     */
    @Override
    public boolean sendRemindActualEffort(BResource resource) throws Exception {
        boolean isSucessSendEmail = true;
        Map<String, Object> model = new HashMap<String, Object>();
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        model.put("date", dateFormat.format(date));
        model.put("recipientName", resource.getMUsers().getUsrFullName());
        String content = getFreeMarkerTemplateContent(model,
                MailTemplate.REMIND_ACTUAL_EFFORT);
        String subject = "[Daily report][" + resource.getMProject().getPrjName()
                + "] - Yêu cầu cập nhật gấp Actual Effort";
        String toMails = resource.getMUsers().getUsrEmail();
        isSucessSendEmail = sendMail(subject, content, toMails);
        return isSucessSendEmail;
    }

    /*
     * Gui mail den nguoi duoc uy quyen
     */
    @Override
    public boolean sendAuthorize(BResource resource, BResource authorizer,
            Date fromDate, Date toDate, String autReasons) throws Exception {
        boolean isSucessSendEmail = true;
        Map<String, Object> model = new HashMap<String, Object>();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        model.put("fromDate", dateFormat.format(fromDate));
        model.put("toDate", dateFormat.format(toDate));
        model.put("recipientName", resource.getMUsers().getUsrFullName());
        model.put("authorizer", authorizer.getMUsers().getUsrFullName());
        model.put("autReasons", autReasons);
        String content = getFreeMarkerTemplateContent(model,
                MailTemplate.AUTHORIZE);
        String subject = "[Daily report][" + resource.getMProject().getPrjName()
                + "] - Ủy quyền công việc";
        String toMails = resource.getMUsers().getUsrEmail();
        isSucessSendEmail = sendMail(subject, content, toMails);
        return isSucessSendEmail;
    }

    /*
     * Gui mail khi huy uy quyen
     */
    @Override
    public boolean sendDestroyAuthorize(BResource resource, BResource authorizer,
            Date fromDate, Date toDate, String autReasons) throws Exception {
        boolean isSucessSendEmail = true;
        Map<String, Object> model = new HashMap<String, Object>();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        model.put("fromDate", dateFormat.format(fromDate));
        model.put("toDate", dateFormat.format(toDate));
        model.put("recipientName", resource.getMUsers().getUsrFullName());
        model.put("authorizer", authorizer.getMUsers().getUsrFullName());
        model.put("autReasons", autReasons);
        String content = getFreeMarkerTemplateContent(model,
                MailTemplate.DESTROY_AUTHORIZE);
        String subject = "[Daily report][" + resource.getMProject().getPrjName()
                + "] - Hủy ủy quyền công việc";
        String toMails = resource.getMUsers().getUsrEmail();
        isSucessSendEmail = sendMail(subject, content, toMails);
        return isSucessSendEmail;
    }

    /*
     * Gui mail den nguoi uy quyen khi het thoi han
     */
    @Override
    public boolean sendExpiredAuthorizeToAuthorizer(BResource resource,
            BResource authorizedUser, Date fromDate, Date toDate,
            String autReasons) throws Exception {
        boolean isSucessSendEmail = true;
        Map<String, Object> model = new HashMap<String, Object>();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        model.put("fromDate", dateFormat.format(fromDate));
        model.put("toDate", dateFormat.format(toDate));
        model.put("recipientName", resource.getMUsers().getUsrFullName());
        model.put("authorizedUser", authorizedUser.getMUsers().getUsrFullName());
        model.put("autReasons", autReasons);
        String content = getFreeMarkerTemplateContent(model,
                MailTemplate.EXPIRED_AUTHORIZE_TO_AUTHORIZER);
        String subject = "[Daily report][" + resource.getMProject().getPrjName()
                + "] - Hết thời gian ủy quyền";
        String toMails = resource.getMUsers().getUsrEmail();
        isSucessSendEmail = sendMail(subject, content, toMails);
        return isSucessSendEmail;
    }

    /*
     * Gui mail den nguoi duoc uy quyen khi het thoi han
     */
    @Override
    public boolean sendExpiredAuthorizeToAuthorizedUser(BResource resource,
            BResource authorizer, Date fromDate, Date toDate, String autReasons)
            throws Exception {
        boolean isSucessSendEmail = true;
        Map<String, Object> model = new HashMap<String, Object>();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        model.put("fromDate", dateFormat.format(fromDate));
        model.put("toDate", dateFormat.format(toDate));
        model.put("recipientName", resource.getMUsers().getUsrFullName());
        model.put("authorizer", authorizer.getMUsers().getUsrFullName());
        model.put("autReasons", autReasons);
        String content = getFreeMarkerTemplateContent(model,
                MailTemplate.EXPIRED_AUTHORIZE_TO_AUTHORIZED_USER);
        String subject = "[Daily report][" + resource.getMProject().getPrjName()
                + "] - Hết thời gian ủy quyền";
        String toMails = resource.getMUsers().getUsrEmail();
        isSucessSendEmail = sendMail(subject, content, toMails);
        return isSucessSendEmail;
    }

    /*
     * Gui mail thong bao task bi tu choi
     */
    @Override
    public boolean sendDisapprovalTask(BResource resource,
            String disapprovalPerson, String contentDisapproval)
            throws Exception {
        boolean isSucessSendEmail = true;
        Map<String, Object> model = new HashMap<String, Object>();
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        model.put("date", dateFormat.format(date));
        model.put("recipientName", resource.getMUsers().getUsrFullName());
        model.put("disapprovalPerson", disapprovalPerson);
        model.put("contentDisapproval", contentDisapproval);
        String content = getFreeMarkerTemplateContent(model,
                MailTemplate.DISAPPROVAL_TASK);
        String subject = "[Daily report][" + resource.getMProject().getPrjName()
                + "] - Từ chối thông tin Actual Effort";
        String toMails = resource.getMUsers().getUsrEmail();
        isSucessSendEmail = sendMail(subject, content, toMails);
        return isSucessSendEmail;
    }

    /*
     * Gui mail thong bao thay doi schedual
     */
    @Override
    public boolean sendImportSchedual(List<BResource> resources)
            throws Exception {
        boolean isSucessSendEmail = true;
        Map<String, Object> model = new HashMap<String, Object>();
        String content = getFreeMarkerTemplateContent(model,
                MailTemplate.IMPORT_SCHEDUAL);
        for (BResource resource : resources) {
            String subject = "[Daily report]["
                    + resource.getMProject().getPrjName()
                    + "] - Thông báo cập nhật schedual";
            String toMails = resource.getMUsers().getUsrEmail();
            isSucessSendEmail = sendMail(subject, content, toMails);
        }
        return isSucessSendEmail;
    }

}
