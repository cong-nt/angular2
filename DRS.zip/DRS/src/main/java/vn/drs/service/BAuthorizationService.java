package vn.drs.service;

import java.util.List;

import vn.drs.entity.BAuthorization;

public interface BAuthorizationService {

    // Lay tat ca chung thuc da tao cua 1 user
    public List<BAuthorization> getAuthorizationByCreator(int userId);

    // Tao 1 uy quyen moi
    public void addNewAuthorization(Object authorizationJsonObj) throws Exception;
    
    // Huy uy quyen
    void deleteAuthorization (int authorizationId) throws Exception;
}
