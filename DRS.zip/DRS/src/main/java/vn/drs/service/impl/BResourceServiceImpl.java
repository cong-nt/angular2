package vn.drs.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.genericdao.search.Filter;
import com.googlecode.genericdao.search.Search;

import vn.drs.core.dao.BaseDao;
import vn.drs.core.dao.HibernateDAOFactory;
import vn.drs.entity.AbstractEntity;
import vn.drs.entity.BAuthorization;
import vn.drs.entity.BResource;
import vn.drs.entity.MRole;
import vn.drs.hibernate.dao.ResourceDao;
import vn.drs.service.BResourceService;
import vn.drs.synchronize.model.PProjectUser;

@Service
public class BResourceServiceImpl implements BResourceService {

    @Autowired
    private HibernateDAOFactory hibFactory;

    @Autowired
    private ResourceDao resourceDao;

    @Override
    public List<BResource> getToResourceAuthorization(int projectId,
            String resourceRoleName) {

        // Tao DAO
        BaseDao<BResource> authorizationDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();

        // Them dieu kien
        search.addFilterEqual("MProject.id", projectId);

        // Kiem tra Role
        if ("TL".equals(resourceRoleName)) {
            search.addFilterEqual("MRole.rolName", "TL");
        } else if ("PL".equals(resourceRoleName)) {
            search.addFilterIn("MRole.rolName", "TL", "PL");
        }
        if ("PM".equals(resourceRoleName)) {
            search.addFilterEqual("MRole.rolName", "PL");
        }

        // Them cac field can lay
        search.addField("id");
        search.addField("resShortName");
        search.addField("MRole.rolName");
        search.setResultMode(Search.RESULT_MAP);

        // Tra ve danh sach resource
        List<BResource> resourceList = authorizationDao.search(search);
        return resourceList;
    }

    @Override
    public List<BResource> getResourceByUserAndPj(int userId, int projectId) {

        // Tao DAO
        BaseDao<BResource> authorizationDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();

        // Them dieu kien
        search.addFilterAnd(Filter.equal("MProject.id", projectId),
                Filter.equal("MUsers.id", userId));

        // Them cac field can lay
        search.addField("id");
        search.addField("resShortName");
        search.addField("MRole.id");
        search.addField("MRole.rolName");
        search.setResultMode(Search.RESULT_MAP);

        // Tra ve danh sach resource
        List<BResource> resourceList = authorizationDao.search(search);
        return resourceList;
    }

    @Override
    public List<BResource> getFromResourceAuthorization(int projectId,
            String resourceRoleName) {

        // Tao DAO
        BaseDao<BResource> authorizationDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();

        // Them dieu kien
        search.addFilterEqual("MProject.id", projectId);
        //
        if ("TL".equals(resourceRoleName)) {
            search.addFilterEqual("MRole.rolName", "TL");
        } else if ("PL".equals(resourceRoleName)) {
            search.addFilterIn("MRole.rolName", "TL", "PL");
        }
        if ("PM".equals(resourceRoleName)) {
            search.addFilterEqual("MRole.rolName", "PL");
        }
        // end
        search.addField("id");
        search.addField("resShortName");
        search.setResultMode(Search.RESULT_MAP);

        // Tra ve danh sach resource
        List<BResource> resourceList = authorizationDao.search(search);
        return resourceList;
    }

    @Override
    public List<BResource> getResourceCanApprove(Integer userId,
            Integer projectId) {
        BaseDao<BResource> bResourceDao = hibFactory
                .instantiateDAO(BResource.class);
        String roleName = getRoleName(userId, projectId);

        Search search = new Search();
        List<BResource> listResource = null;
        // search.addFilterEqual("BResource.id", projectId);
        // role PMO, PM , PL hien thi cac user tu teamlearn tro xuong tro xuong
        if (MRole.PMO.equals(roleName) || MRole.PM.equals(roleName)
                || MRole.PL.equals(roleName)) {
            List<String> listRole = new ArrayList<>();
            listRole.add(MRole.TL);
            listRole.add(MRole.DEV);
            listResource = getResourceByRolesInProject(projectId, listRole);
        } else if (MRole.TL.equals(roleName)) {
            listResource = getResourceBySupervisor(userId, projectId);
        }
        return listResource;
    }

    /**
     * ham lay danh sach cac resource duoi quyen trong project
     * 
     * @param userId
     *            user id
     * @param projectId.
     *            project id.
     * @return
     */
    private List<BResource> getResourceBySupervisor(Integer userId,
            Integer projectId) {
        BaseDao<BResource> bResourceDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();
        search.addFilterEqual("BResource.MUsers.id", userId);
        search.addFilterEqual("MProject.id", projectId);
        return bResourceDao.search(search);
    }

    /**
     * ham lay danh sach cac resource theo project va role id
     * 
     * @param projectId
     *            project id
     * @param listRole.
     *            danh sach role.
     * @return
     */
    private List<BResource> getResourceByRolesInProject(Integer projectId,
            List<String> listRole) {
        BaseDao<BResource> bResourceDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();
        search.addFilterIn("MRole.rolName", listRole);
        search.addFilterEqual("MProject.id", projectId);
        return bResourceDao.search(search);
    }

    private String getRoleName(Integer userId, Integer projectId) {
        BaseDao<MRole> mRoleDao = hibFactory.instantiateDAO(MRole.class);
        Search search = new Search();

        search.addField("rolName");
        search.addFilterEqual("BResources.MUsers.id", userId);
        search.addFilterEqual("BResources.MProject.id", projectId);

        String mRole = mRoleDao.searchUnique(search);
        return mRole;
    }

    private ArrayList<Integer> getAuthorizedId(Integer suppervisiorId) {
        ArrayList<Integer> getAuthorizedId = new ArrayList<Integer>();
        BaseDao<BAuthorization> BAuthorization = hibFactory
                .instantiateDAO(BAuthorization.class);
        Search search = new Search();
        search.addFilterEqual("BResourceByAutAuthorizedId.MUsers.id",
                suppervisiorId);
        List<BAuthorization> bAuths = BAuthorization.search(search);
        for (BAuthorization auth : bAuths) {
            getAuthorizedId.add(auth.getBResourceByAutResourceId().getId());
        }
        return getAuthorizedId;
    }

    @Override
    public List<BResource> getAllResource() {
        BaseDao<BResource> BResourceDao = hibFactory
                .instantiateDAO(BResource.class);
        return BResourceDao.findAll();
    }

    @Override
    public List<BResource> getProjectDevs(int projectId) throws Exception {
        BaseDao<BResource> resoureDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();
        search.addFilterEqual("MProject.id", projectId);
        search.addFilterEqual("MRole.rolName", MRole.DEV);
        search.addFilterEqual("valid", vn.drs.entity.AbstractEntity.VALID);
        search.addFilterOr(Filter.isNull("BResource"),
                Filter.and(Filter.isNotNull("BResource"),
                        Filter.equal("valid", AbstractEntity.INVALID)));
        search.addField("id");
        search.addField("resShortName");
        search.addSortAsc("resShortName");
        search.setResultMode(Search.RESULT_MAP);

        return resoureDao.search(search);
    }

    @Override
    public List<BResource> getProjectGroups(int projectId) throws Exception {
        BaseDao<BResource> resoureDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();
        search.addFilterEqual("MProject.id", projectId);
        search.addFilterEqual("MProject.valid", AbstractEntity.VALID);
        search.addFilterEqual("valid", AbstractEntity.VALID);
        search.addFilterNotNull("BResource");
        search.addField("BResource.id");
        search.addField("BResource.resShortName");

        search.setDistinct(Boolean.TRUE);
        search.addSortAsc("BResource.resShortName");

        search.setResultMode(Search.RESULT_MAP);

        return resoureDao.search(search);
    }

    @Override
    public List<BResource> getProjectTeamLeads(int projectId) throws Exception {
        BaseDao<BResource> resoureDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();
        search.addFilterEqual("MProject.id", projectId);
        search.addFilterEqual("MRole.rolName", MRole.TL);
        search.addFilterEqual("valid", AbstractEntity.VALID);
        search.addFilterEmpty("BResources");
        search.addField("id");
        search.addField("resShortName");
        search.addSortAsc("resShortName");
        search.setResultMode(Search.RESULT_MAP);
        return resoureDao.search(search);
    }

    @Override
    public List<BResource> getProjectGroupMembers(int projectId)
            throws Exception {
        BaseDao<BResource> resoureDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();
        search.addFilterEqual("MProject.id", projectId);
        search.addFilterEqual("MRole.rolName", MRole.DEV);
        search.addFilterEqual("valid", AbstractEntity.VALID);
        search.addFilterAnd(Filter.isNotNull("BResource"),
                Filter.equal("valid", AbstractEntity.VALID));
        search.addField("id");
        search.addField("resShortName");
        search.addField("BResource.id");
        search.addField("BResource.resShortName");
        search.addSortAsc("resShortName");
        search.setResultMode(Search.RESULT_MAP);

        return resoureDao.search(search);
    }

    @Override
    public void saveOrUpdateGroup(int groupId, Integer... resourceIds)
            throws Exception {
        BaseDao<BResource> resoureDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();
        search.addFilterOr(Filter.in("id", resourceIds),
                Filter.equal("BResource.id", groupId));
        search.addFilterEqual("MRole.rolName", MRole.DEV);
        List<BResource> resouces = resoureDao.search(search);
        BResource supervisor = new BResource();
        supervisor.setId(groupId);
        List<Integer> resouceIds = Arrays.asList(resourceIds);
        for (BResource resource : resouces) {
            if (resouceIds.contains(resource.getId())) {
                resource.setBResource(supervisor);
                resource.setModifiedDate(new Date());
            } else {
                resource.setBResource(null);
                resource.setModifiedDate(new Date());
            }
        }

        resoureDao.save(resouces.toArray(new BResource[resouces.size()]));
    }

    @Override
    public void deleteGroup(int groupId) throws Exception {
        BaseDao<BResource> resoureDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();
        search.addFilterEqual("BResource.id", groupId);
        List<BResource> resouces = resoureDao.search(search);
        for (BResource resource : resouces) {
            resource.setBResource(null);
            resource.setModifiedDate(new Date());
        }
        resoureDao.save(resouces.toArray(new BResource[resouces.size()]));
    }

    @Override
    public void syncResource(List<PProjectUser> pProjectUsers)
            throws Exception {
        resourceDao.syncResource(pProjectUsers);
    }

    @Override
    public void saveBResource(BResource bResource) {
        BaseDao<BResource> taskDao = hibFactory.instantiateDAO(BResource.class);
        taskDao.save(bResource);
    }

    @Override
    public List<BResource> getProjectResource(Integer projectId) {
        BaseDao<BResource> resoureDao = hibFactory
                .instantiateDAO(BResource.class);
        Search search = new Search();
        search.addFilterEqual("MProject.id", projectId);
        search.addFilterEqual("valid", AbstractEntity.VALID);
        return resoureDao.search(search);
    }

}
