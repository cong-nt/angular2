package vn.drs.service;

import java.util.Date;
import java.util.List;

import vn.drs.entity.BWork;

/**
 * <h5>Work service</h5>
 * <p>
 * Cac ham xu ly lien quan den work (plan & actual work)
 * </p>
 *
 */
public interface BWorkService {

    /**
     * <p>
     * Lay danh sach plan & work
     * </p>
     * 
     * @param assignmentId
     *            assignment Id
     * @return Danh sach work
     */
    public List<BWork> getWorkByAssignment(Integer assignmentId);
    
    void approve(Integer...workIds) throws Exception;
    
    void disapprove(Integer...workIds) throws Exception;

    /**
     * <p>
     * Lay danh sach plan & work theo project va ngay
     * </p>
     * 
     * @param date
     *            ngay can lay thong tin
     * @param projectId
     *            project Id
     * @return Danh sach work
     */
    public List<BWork> getWorkApproveByProjectAndDate(Date date, int projectId);

}
