package vn.drs.service;

import java.util.List;

import vn.drs.synchronize.model.PUser;

public interface MUsersService {
    
    // Dong bo user
    void syncUser(List<PUser> pUsers) throws Exception;

    // Lay ten day du cua User dua vao ten dang nhap
    public String userFullName(String shortName);
}
