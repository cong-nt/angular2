package vn.drs.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import vn.drs.constant.Constant;
import vn.drs.core.dao.HibernateDAOFactory;
import vn.drs.entity.BAssignment;
import vn.drs.entity.BWork;
import vn.drs.entity.MProject;
import vn.drs.service.BWorkService;
import vn.drs.service.ExportService;
import vn.drs.service.MProjectService;
import vn.drs.util.DateUtils;
import vn.drs.util.MppUtil;

@Service
public class ExportServiceImpl implements ExportService {

    @Autowired
    private String mppFolder;

    @Autowired
    private HibernateDAOFactory hibFactory;

    @Autowired
    private MProjectService mProjectService;

    @Autowired
    private BWorkService bWorkService;

    /**
     * {@inheritDoc}
     */
    @Override
    public String exportProject(int projectId, Date date) {
        MProject project = mProjectService.getProjectById(projectId);
        String mppFile = project.getPrjMppFilename();
        File file = new File(mppFolder, mppFile);
        if (!file.exists())
            return "";

        MppUtil.instance();
        MppUtil.instance().openFileMPP(file.getAbsolutePath());
        List<BWork> bworks = bWorkService
                .getWorkApproveByProjectAndDate(new Date(), projectId);
        bworks.size();
        for (BWork bwork : bworks) {
            BAssignment assignment = bwork.getBAssignment();
            try {
                MppUtil.instance().write(assignment.getBResource().getResUid(),
                        assignment.getBTask().getTasUniqueId(),
                        bwork.getWorWorkHours(),
                        DateUtils.dateToString(bwork.getWorWorkDate(),
                                Constant.FORMAT_MMDDYY));
            } catch (IOException ex) {
                ex.printStackTrace();
            }

        }
        MppUtil.instance().closeCurrentFileMPP(true);
        return mppFile;
    }
}
