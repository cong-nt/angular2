package vn.drs.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import vn.drs.hibernate.dao.RoleDao;
import vn.drs.service.MRoleService;
import vn.drs.synchronize.model.PRole;

@Service
public class MRoleServiceImpl implements MRoleService{

    @Autowired
    private RoleDao roleDao;
    
    @Override
    public void syncRole(List<PRole> pRoles) throws Exception {
        roleDao.syncRole(pRoles);
    }

}
