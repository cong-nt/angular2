package vn.drs.service;

import java.util.List;

import vn.drs.entity.MTaskInfo;

public interface MTaskInfoService {

    /**
     * <p>
     * Lay thong tin task info
     * </p>
     * 
     * @param type Kieu info
     * @return Danh sach task info
     */
    public List<MTaskInfo> getTaskInfoNameByType(int type);

    /**
     * <p>
     * Lay tat ca thong tin task
     * </p>
     * 
     * @return Danh sach task info
     */
    public List<MTaskInfo> getAllTaskInfo();

}
