package vn.drs.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.genericdao.search.Search;

import vn.drs.core.dao.BaseDao;
import vn.drs.core.dao.HibernateDAOFactory;
import vn.drs.entity.BWork;
import vn.drs.entity.MProject;
import vn.drs.service.BWorkService;
import vn.drs.util.DateUtils;

@Service
public class BWorkServiceImpl implements BWorkService {

    private static final int BWORK_APPROVE = 2;
    @Autowired
    private HibernateDAOFactory hibFactory;

    /**
     * {@inheritDoc}
     */
    @Override
    public List<BWork> getWorkByAssignment(Integer assignmentId) {
        BaseDao<BWork> bWorkDao = hibFactory.instantiateDAO(BWork.class);
        Search search = new Search();
        search.addFilterEqual("BAssignment.id", assignmentId);
        search.addSort("worPlanDate", false);
        search.addSort("worWorkDate", false);
        return bWorkDao.search(search);
    }

	@Override
	public void approve(Integer...workIds) throws Exception {
		 BaseDao<BWork> bWorkDao = hibFactory.instantiateDAO(BWork.class);
		  Search search = new Search();
	        search.addFilterIn("BAssignment.BResource.id", workIds);
	        List<BWork> works = bWorkDao.search(search);
	        for(BWork work : works){
	        	work.setModifiedDate(new Date());
	        	work.setWorStatus(2);
	        }
	        
	        bWorkDao.save(works.toArray(new BWork[works.size()]));
	}

	@Override
	public void disapprove(Integer... workIds) throws Exception {
		BaseDao<BWork> bWorkDao = hibFactory.instantiateDAO(BWork.class);
        Search search = new Search();
        search.addFilterIn("BAssignment.BResource.id", workIds);
        List<BWork> works = bWorkDao.search(search);
        for(BWork work : works){
        	work.setModifiedDate(new Date());
        	work.setWorStatus(0);
        }
        
        bWorkDao.save(works.toArray(new BWork[works.size()]));
	}

    /**
     * {@inheritDoc}
     */
    @Override
    public List<BWork> getWorkApproveByProjectAndDate(Date date,
            int projectId) {

        BaseDao<BWork> bWorkDao = hibFactory.instantiateDAO(BWork.class);
        // tao mproject
        MProject project = new MProject();
        project.setId(projectId);
        // search
        Search search = new Search(BWork.class);
        search.addFilterGreaterOrEqual("worWorkDate",
                DateUtils.removeTime(date));
        search.addFilterLessOrEqual("worWorkDate", DateUtils.midnight(date));
        search.addFilterEqual("BAssignment.BTask.MProject", project);
        search.addFilterEqual("worStatus", BWORK_APPROVE);
        search.addFetch("BAssignment").addFetch("BAssignment.BResource");
        search.addFetch("BAssignment.BTask");
        return bWorkDao.search(search);
    }
}
