package vn.drs.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.genericdao.search.Search;

import vn.drs.core.dao.BaseDao;
import vn.drs.core.dao.HibernateDAOFactory;
import vn.drs.entity.MTaskInfo;
import vn.drs.service.MTaskInfoService;

@Service
public class MTaskInfoServiceImpl implements MTaskInfoService {

    @Autowired
    private HibernateDAOFactory hibFactory;

    /**
     * {@inheritDoc}
     */
    @Override
    public List<MTaskInfo> getTaskInfoNameByType(int type) {
        BaseDao<MTaskInfo> mTaskInfoDao = hibFactory.instantiateDAO(MTaskInfo.class);
        Search search = new Search();
        search.addFilterEqual("infType", type);
        search.addFilterEqual("valid", 1);
        search.addField("infName");
        search.addField("id");
        search.setResultMode(Search.RESULT_MAP);
        return mTaskInfoDao.search(search);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<MTaskInfo> getAllTaskInfo() {
        BaseDao<MTaskInfo> mTaskInfoDao = hibFactory.instantiateDAO(MTaskInfo.class);
        Search search = new Search();
        search.addFilterEqual("valid", 1);
        search.addField("id");
        search.addField("infName");
        search.addField("infType");
        search.setResultMode(Search.RESULT_MAP);
        return mTaskInfoDao.search(search);
    }

}
