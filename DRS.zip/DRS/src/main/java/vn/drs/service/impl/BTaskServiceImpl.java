package vn.drs.service.impl;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.genericdao.search.Filter;
import com.googlecode.genericdao.search.Search;

import vn.drs.constant.Constant;
import vn.drs.core.dao.BaseDao;
import vn.drs.core.dao.HibernateDAOFactory;
import vn.drs.dto.ViewTaskDTO;
import vn.drs.entity.AbstractEntity;
import vn.drs.entity.BAssignment;
import vn.drs.entity.BResource;
import vn.drs.entity.BTask;
import vn.drs.entity.BWork;
import vn.drs.entity.MProject;
import vn.drs.entity.MTaskInfo;
import vn.drs.service.BTaskService;
import vn.drs.service.BWorkService;
import vn.drs.util.CopierBeanUtils;
import vn.drs.util.DateUtils;

/**
 * <h5>Task service</h5>
 * <p>
 * Cac ham xu ly lien quan den task
 * </p>
 *
 */
@Service
public class BTaskServiceImpl implements BTaskService {

    @Autowired
    private HibernateDAOFactory hibFactory;

    @Autowired
    private BWorkService bWorkService;

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, Object> search(String keyword, Integer projectId,
            Integer work, Integer business, Integer phase, Integer status,
            String resourceName, Date startTime, Date endTime) {
        BaseDao<BTask> bTaskDao = hibFactory.instantiateDAO(BTask.class);
        Map<String, Object> mapReturn = new HashMap<>();
        DecimalFormat format = new DecimalFormat();
        format.setDecimalSeparatorAlwaysShown(false);
        Search search = new Search();

        // Tim kiem theo tu khoa
        if (StringUtils.isNotBlank(keyword)) {
            String likeKeyword = "%" + keyword + "%";
            search.addFilterOr(Filter.like("tasName", likeKeyword),
                    Filter.like("tasDescription", likeKeyword));
        }

        // Tim kiem theo cac dieu kien da chon
        if (projectId != null && projectId > 0) {
            search.addFilterEqual("MProject.id", projectId);
        }
        if (work != null && work > 0) {
            search.addFilterEqual("MTaskInfoByTasWork.id", work);
        }
        if (business != null && business > 0) {
            search.addFilterEqual("MTaskInfoByTasBusiness.id", business);
        }
        if (phase != null && phase > 0) {
            search.addFilterEqual("MTaskInfoByTasPhase.id", phase);
        }
        if (status != null && status > 0) {
            search.addFilterEqual("MTaskInfoByTasStatus.id", status);
        }
        if (startTime != null) {
            search.addFilterOr(
                    Filter.greaterOrEqual("tasActualStartTime",
                            DateUtils.removeTime(startTime)),
                    Filter.greaterOrEqual("tasPlanStartTime",
                            DateUtils.removeTime(startTime)));
        }
        if (endTime != null) {
            search.addFilterOr(
                    Filter.lessOrEqual("tasActualEndTime",
                            DateUtils.midnight(endTime)),
                    Filter.lessOrEqual("tasPlanEndTime",
                            DateUtils.midnight(endTime)));
        }
        // Sap xep theo id giam dan
        search.addSort(Constant.ID, true);

        List<BTask> mapResult = bTaskDao.search(search);
        List<ViewTaskDTO> listTask = new ArrayList<>();
        Date minDate = new Date(Long.MAX_VALUE);
        Date maxDate = new Date(0);

        // Convert qua danh sach DTO de hien thi len man hinh
        for (BTask bTask : mapResult) {
            for (BAssignment assignment : bTask.getBAssignments()) {

                // Tim kiem theo resource name
                if (StringUtils.isNotBlank(resourceName)) {
                    if (!assignment.getBResource().getResShortName()
                            .toLowerCase().contains(resourceName.toLowerCase())
                            && !assignment.getBResource().getMUsers()
                                    .getUsrFullName().toLowerCase()
                                    .contains(resourceName.toLowerCase())) {
                        continue;
                    }
                }
                ViewTaskDTO viewTaskDTO = new ViewTaskDTO();
                CopierBeanUtils.copyExcludeNull(bTask, viewTaskDTO);
                if (bTask.getMProject() != null) {
                    viewTaskDTO.setTasProject(bTask.getMProject().getPrjName());
                }
                if (bTask.getMTaskInfoByTasBusiness() != null) {
                    viewTaskDTO.setTasBusiness(
                            bTask.getMTaskInfoByTasBusiness().getInfName());
                }
                if (bTask.getMTaskInfoByTasPhase() != null) {
                    viewTaskDTO.setTasPhase(
                            bTask.getMTaskInfoByTasPhase().getInfName());
                }
                if (bTask.getMTaskInfoByTasWork() != null) {
                    viewTaskDTO.setTasWork(
                            bTask.getMTaskInfoByTasWork().getInfName());
                }
                if (bTask.getMTaskInfoByTasModule() != null) {
                    viewTaskDTO.setTasModule(
                            bTask.getMTaskInfoByTasModule().getInfName());
                }
                if (bTask.getMTaskInfoByTasStatus() != null) {
                    viewTaskDTO.setTasStatus(
                            bTask.getMTaskInfoByTasStatus().getInfName());
                }
                if (assignment.getBResource() != null) {
                    viewTaskDTO.setTasResourceName(
                            assignment.getBResource().getResShortName());
                }
                Map<String, String> mapPlan = new HashMap<>();
                Map<String, String> mapActual = new HashMap<>();
                List<BWork> listWork = bWorkService
                        .getWorkByAssignment(assignment.getId());
                for (BWork bWork : listWork) {
                    mapPlan.put(
                            DateUtils.dateToString(bWork.getWorPlanDate(),
                                    Constant.FORMAT_YYYYMMDD_WITHOUT_SLASH),
                            format.format(bWork.getWorPlanHours()));
                    mapActual.put(
                            DateUtils.dateToString(bWork.getWorWorkDate(),
                                    Constant.FORMAT_YYYYMMDD_WITHOUT_SLASH),
                            format.format(bWork.getWorWorkHours()));
                }
                viewTaskDTO.setMapPlan(mapPlan);
                viewTaskDTO.setMapActual(mapActual);
                listTask.add(viewTaskDTO);
            }
            if (DateUtils.compareDate(minDate,
                    bTask.getTasPlanStartTime()) > 0) {
                minDate = bTask.getTasPlanStartTime();
            }
            if (DateUtils.compareDate(minDate,
                    bTask.getTasActualStartTime()) > 0) {
                minDate = bTask.getTasActualStartTime();
            }
            if (DateUtils.compareDate(maxDate, bTask.getTasPlanEndTime()) < 0) {
                maxDate = bTask.getTasPlanEndTime();
            }
            if (DateUtils.compareDate(maxDate,
                    bTask.getTasActualEndTime()) < 0) {
                maxDate = bTask.getTasActualEndTime();
            }
        }
        mapReturn.put("listTask", listTask);
        mapReturn.put("minDate",
                DateUtils.dateToString(DateUtils.getStartDateOfWeek(minDate)));
        mapReturn.put("maxDate",
                DateUtils.dateToString(DateUtils.getEndDateOfWeek(maxDate)));

        return mapReturn;
    }

    /**
     * {@inheritDoc}
     * 
     * @throws ParseException
     */
    @Override
    public Map<String, Object> getAllTask(int resourceId, Date startDate,
            Date endDate) throws ParseException {

        BaseDao<BTask> bTaskDao = hibFactory.instantiateDAO(BTask.class);
        Map<String, Object> mapReturn = new HashMap<>();
        DecimalFormat format = new DecimalFormat();
        format.setDecimalSeparatorAlwaysShown(false);
        Search search = new Search();

        search.addFilterEqual(Constant.VALID, AbstractEntity.VALID);
        search.addFilterEqual("BAssignments.BResource.id", resourceId);
        if (endDate != null) {
            search.addFilterLessOrEqual("tasPlanEndTime",
                    DateUtils.removeTime(endDate));

        }
        if (startDate != null) {
            search.addFilterGreaterOrEqual("tasPlanStartTime",
                    DateUtils.removeTime(startDate));
        }

        // Sap xep theo id giam dan
        search.addSort(Constant.ID, true);

        List<BTask> mapResult = bTaskDao.search(search);

        // Convert qua danh sach DTO de hien thi len man hinh
        mapReturn = convertDtoListTask(resourceId, mapResult,
                startDate, endDate);
        return mapReturn;

    }

    /**
     * {@inheritDoc}
     * 
     * @throws ParseException
     */
    @Override
    public Map<String, Object> searchMyTask(int resourceId, String keyword,
            Integer projectId,
            Integer work, Integer business, Integer phase, Integer status,
            Date startDate, Date endDate) throws ParseException {

        BaseDao<BTask> bTaskDao = hibFactory.instantiateDAO(BTask.class);
        Map<String, Object> mapReturn = new HashMap<>();
        DecimalFormat format = new DecimalFormat();
        format.setDecimalSeparatorAlwaysShown(false);

        Search search = new Search();
        search.addFilterEqual(Constant.VALID, AbstractEntity.VALID);
        search.addFilterEqual("BAssignments.BResource.id", resourceId);

        if (endDate != null) {
            search.addFilterLessOrEqual("tasPlanEndTime",
                    DateUtils.removeTime(endDate));

        }
        if (startDate != null) {
            search.addFilterGreaterOrEqual("tasPlanStartTime",
                    DateUtils.removeTime(startDate));
        }

        // Tim kiem theo tu khoa
        if (StringUtils.isNotBlank(keyword)) {
            String likeKeyword = "%" + keyword + "%";
            search.addFilterOr(Filter.like("tasName", likeKeyword),
                    Filter.like("tasDescription", likeKeyword));
        } else {
            // Tim kiem theo cac dieu kien da chon
            if (projectId != null && projectId > 0) {
                search.addFilterEqual("MProject.id", projectId);
            }
            if (work != null && work > 0) {
                search.addFilterEqual("MTaskInfoByTasWork.id", work);
            }
            if (business != null && business > 0) {
                search.addFilterEqual("MTaskInfoByTasBusiness.id", business);
            }
            if (phase != null && phase > 0) {
                search.addFilterEqual("MTaskInfoByTasPhase.id", phase);
            }
            if (status != null && status > 0) {
                search.addFilterEqual("MTaskInfoByTasStatus.id", status);
            }
        }
        // Sap xep theo id giam dan
        search.addSort(Constant.ID, true);

        List<BTask> mapResult = bTaskDao.search(search);
        List<ViewTaskDTO> listTask = new ArrayList<>();

        // Convert qua danh sach DTO de hien thi len man hinh
        mapReturn = convertDtoListTask(resourceId, mapResult,
                startDate, endDate);
        return mapReturn;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<BTask> getAllTaskByProject(MProject mProject) {
        BaseDao<BTask> taskDao = hibFactory.instantiateDAO(BTask.class);
        Search search = new Search();
        search.addFilterEqual("MProject", mProject);
        return taskDao.search(search);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void deleteTask(int taskId) throws Exception {
        BaseDao<BTask> taskDao = hibFactory.instantiateDAO(BTask.class);
        Search search = new Search();
        search.addFilterEqual(Constant.ID, taskId);
        BTask task = taskDao.searchUnique(search);
        task.setValid(AbstractEntity.INVALID);
        task.setModifiedDate(new Date());

        int resourceId = 1;

        for (BAssignment assignment : task.getBAssignments()) {
            if (assignment.getBResource().getId() == resourceId) {
                assignment.setValid(AbstractEntity.INVALID);

                for (BWork work : assignment.getBWorks())
                    work.setValid(AbstractEntity.INVALID);
            }
        }

        taskDao.save(task);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void saveTask(BTask bTask) {
        BaseDao<BTask> taskDao = hibFactory.instantiateDAO(BTask.class);
        taskDao.save(bTask);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void saveMyTask(List<ViewTaskDTO> lst, int resourceId)
            throws Exception {

        List<BTask> lstTask = new ArrayList<BTask>();
        List<BWork> lstWork = new ArrayList<BWork>();

        // Thiet lap thoi gian cho table Work
        BaseDao<BResource> resourceBase = hibFactory
                .instantiateDAO(BResource.class);
        Search searchResource = new Search();
        searchResource.addFilterEqual(Constant.ID, resourceId);
        BResource resource = resourceBase.searchUnique(searchResource);

        for (ViewTaskDTO dto : lst) {
            BTask tsk = new BTask();
            tsk.setId(Integer.parseInt(dto.getId()));
            tsk.setTasName(dto.getTasName());
            tsk.setTasName(dto.getTasName());
            tsk.setTasDescription(dto.getTasDescription());
            tsk.setTasPlanStartTime(dto.getTasPlanStartTime());
            tsk.setTasPlanEndTime(dto.getTasPlanEndTime());
            tsk.setTasActualStartTime(dto.getTasActualStartTime());
            tsk.setTasActualEndTime(dto.getTasActualEndTime());
            MTaskInfo work = new MTaskInfo();
            work.setId(dto.getTasWorkId());
            tsk.setMTaskInfoByTasWork(work);
            MTaskInfo bussiness = new MTaskInfo();
            bussiness.setId(dto.getTasBusinessId());
            tsk.setMTaskInfoByTasBusiness(bussiness);
            MTaskInfo phase = new MTaskInfo();
            phase.setId(dto.getTasPhaseId());
            tsk.setMTaskInfoByTasPhase(phase);
            MTaskInfo module = new MTaskInfo();
            module.setId(dto.getTasModuleId());
            tsk.setMTaskInfoByTasModule(module);
            MProject pj = new MProject();
            pj.setId(dto.getTasProjectId());
            tsk.setMProject(pj);
            MTaskInfo status = new MTaskInfo();
            status.setId(dto.getTasStatusId());
            tsk.setMTaskInfoByTasStatus(status);
            tsk.setTasUniqueId(dto.getTasUniqueId());
            tsk.setCreatedDate(new Date());
            tsk.setModifiedDate(new Date());
            tsk.setValid(AbstractEntity.VALID);

            BAssignment ass = new BAssignment();
            ass.setId(dto.getTasAssId());
            ass.setBResource(resource);
            ass.setAssUid(tsk.getTasUniqueId());
            ass.setAssPlanHours(dto.getTasAssPlanHours());
            ass.setAssWorkHours(dto.getTasAssWorkHours());
            ass.setBTask(tsk);

            Map<String, String> mapPlan = dto.getMapPlan();
            Map<String, String> mapActual = dto.getMapActual();

            // Thiet lap thoi gian cho table Work
            BaseDao<BWork> workBase = hibFactory
                    .instantiateDAO(BWork.class);
            Search searchWork = new Search();
            searchWork.addFilterEqual(Constant.BASSIGNMENT_ID,
                    dto.getTasAssId());
            lstWork = workBase.search(searchWork);

            for (BWork w : lstWork) {
                String datePlanDate = DateUtils
                        .dateToStringWithoutFlash(w.getWorPlanDate());
                String dateActualDate = DateUtils
                        .dateToStringWithoutFlash(w.getWorWorkDate());

                if (mapPlan.get(datePlanDate) != null) {
                    w.setWorPlanHours(
                            Double.valueOf(mapPlan.get(datePlanDate)) + 1);
                    mapPlan.remove(datePlanDate);
                }
                if (mapActual.get(datePlanDate) != null) {
                    w.setWorWorkHours(
                            Double.valueOf(mapActual.get(dateActualDate)) + 1);
                    mapActual.remove(dateActualDate);
                }
                w.setCreatedDate(new Date());
                w.setModifiedDate(new Date());
                w.setBAssignment(ass);
                ass.getBWorks().add(w);
            }

            for (Map.Entry<String, String> entry : mapPlan.entrySet()) {
                BWork newWork = new BWork();
                Date PlanDate = DateUtils.stringToDate(entry.getKey(),
                        Constant.FORMAT_YYYYMMDD_WITHOUT_SLASH);
                newWork.setWorPlanDate(PlanDate);
                newWork.setWorPlanHours(Double.valueOf(entry.getValue()));
                newWork.setWorWorkDate(PlanDate);
                newWork.setWorWorkHours(
                        Double.valueOf(mapActual.get(entry.getKey())));
                newWork.setBAssignment(ass);
                newWork.setCreatedDate(new Date());
                newWork.setModifiedDate(new Date());
                ass.getBWorks().add(newWork);
            }

            tsk.getBAssignments().add(ass);
            lstTask.add(tsk);
        }

        // Save table task
        BaseDao<BTask> taskDao = hibFactory
                .instantiateDAO(
                        BTask.class);
        taskDao.save(lstTask.toArray(new BTask[lstTask.size()]));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void sendMyTask(List<ViewTaskDTO> lst, int resourceId)
            throws Exception {
        saveMyTask(lst, resourceId);

        BaseDao<BWork> workDao = hibFactory.instantiateDAO(BWork.class);
        Search search = new Search();
        search.addFilterEqual("BAssignment.BResource.id", resourceId);
        Date currentDate = new Date();
        search.addFilterGreaterOrEqual(Constant.WOR_WORK_DATE,
                DateUtils.removeTime(currentDate));
        search.addFilterLessOrEqual(Constant.WOR_WORK_DATE,
                DateUtils.midnight(currentDate));
        List<BWork> listWork = workDao.search(search);

        for (BWork w : listWork) {
            w.setWorStatus(1);
        }

        // Save table task
        workDao.save(listWork.toArray(new BWork[listWork.size()]));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isSendRequest(int resourceId, Date date) {
        BaseDao<BWork> workDao = hibFactory.instantiateDAO(BWork.class);
        Search search = new Search();
        search.addFilterEqual("BAssignment.BResource.id", resourceId);
        search.addFilterOr(
                Filter.equal(Constant.WOR_STATUS,
                        BWork.worStatus.SEND.getValue()),
                Filter.equal(Constant.WOR_STATUS,
                        BWork.worStatus.APPROVED.getValue()));
        search.addFilterGreaterOrEqual(Constant.WOR_WORK_DATE,
                DateUtils.removeTime(date));
        search.addFilterLessOrEqual(Constant.WOR_WORK_DATE,
                DateUtils.midnight(date));
        List<BWork> listWork = workDao.search(search);
        if (listWork != null && listWork.size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * 
     * @param resourceId
     * @param mapResult
     * @param startDate
     * @param endDate
     * @return
     */
    private Map<String, Object> convertDtoListTask(int resourceId,
            List<BTask> mapResult, Date startDate,
            Date endDate) {
        DecimalFormat format = new DecimalFormat();
        Map<String, Object> mapReturn = new HashMap<>();
        List<ViewTaskDTO> listTask = new ArrayList<>();

        for (BTask bTask : mapResult) {
            Date actualStartTime = bTask.getTasActualStartTime();
            Date actualEndTime = bTask.getTasActualEndTime();
            Date planStartTime = bTask.getTasPlanStartTime();
            Date planEndTime = bTask.getTasPlanEndTime();

            for (BAssignment assignment : bTask.getBAssignments()) {

                if (assignment.getBResource().getId() == resourceId) {
                    ViewTaskDTO viewTaskDTO = new ViewTaskDTO();
                    CopierBeanUtils.copyExcludeNull(bTask, viewTaskDTO);
                    viewTaskDTO.setTasProject(bTask.getMProject().getPrjName());
                    viewTaskDTO.setTasProjectId(bTask.getMProject().getId());
                    viewTaskDTO.setTasBusiness(
                            bTask.getMTaskInfoByTasBusiness().getInfName());
                    viewTaskDTO.setTasBusinessId(
                            bTask.getMTaskInfoByTasBusiness().getId());
                    viewTaskDTO.setTasPhase(
                            bTask.getMTaskInfoByTasPhase().getInfName());
                    viewTaskDTO.setTasPhaseId(
                            bTask.getMTaskInfoByTasPhase().getId());
                    viewTaskDTO.setTasWork(
                            bTask.getMTaskInfoByTasWork().getInfName());
                    viewTaskDTO.setTasWorkId(
                            bTask.getMTaskInfoByTasWork().getId());
                    viewTaskDTO.setTasModule(
                            bTask.getMTaskInfoByTasModule().getInfName());
                    viewTaskDTO.setTasModuleId(
                            bTask.getMTaskInfoByTasModule().getId());
                    viewTaskDTO.setTasStatus(
                            bTask.getMTaskInfoByTasStatus().getInfName());
                    viewTaskDTO.setTasStatusId(
                            bTask.getMTaskInfoByTasStatus().getId());
                    viewTaskDTO.setTasAssId(assignment.getId());

                    Map<String, String> mapPlan = new HashMap<>();
                    Map<String, String> mapActual = new HashMap<>();
                    BaseDao<BWork> bWorkDao = hibFactory
                            .instantiateDAO(BWork.class);
                    Search search1 = new Search();
                    search1.addFilterEqual(Constant.BASSIGNMENT_ID,
                            assignment.getId());
                    search1.addFilterOr(
                            Filter.greaterOrEqual(Constant.WOR_PLAN_DATE,
                                    DateUtils.removeTime(startDate)),
                            Filter.greaterOrEqual(Constant.WOR_WORK_DATE,
                                    DateUtils.removeTime(startDate)));
                    search1.addFilterOr(
                            Filter.lessOrEqual(Constant.WOR_PLAN_DATE,
                                    DateUtils.removeTime(endDate)),
                            Filter.lessOrEqual(Constant.WOR_WORK_DATE,
                                    DateUtils.removeTime(endDate)));

                    List<BWork> listWork = bWorkDao.search(search1);
                    for (BWork bWork : listWork) {
                        mapPlan.put(
                                DateUtils.dateToString(bWork.getWorPlanDate(),
                                        Constant.FORMAT_YYYYMMDD_WITHOUT_SLASH),
                                format.format(bWork.getWorPlanHours()));
                        mapActual.put(
                                DateUtils.dateToString(bWork.getWorWorkDate(),
                                        Constant.FORMAT_YYYYMMDD_WITHOUT_SLASH),
                                format.format(bWork.getWorWorkHours()));
                    }
                    viewTaskDTO
                            .setTasAssPlanHours(assignment.getAssPlanHours());
                    viewTaskDTO
                            .setTasAssWorkHours(assignment.getAssWorkHours());

                    viewTaskDTO.setMapPlan(mapPlan);
                    viewTaskDTO.setMapActual(mapActual);
                    viewTaskDTO
                            .setTasActualStartTime(actualStartTime);
                    viewTaskDTO
                            .setTasActualEndTime(actualEndTime);
                    viewTaskDTO
                            .setTasPlanStartTime(planStartTime);
                    viewTaskDTO
                            .setTasPlanEndTime(planEndTime);
                    listTask.add(viewTaskDTO);
                }
            }
        }
        mapReturn.put(Constant.LIST_TASK, listTask);
        mapReturn.put(Constant.MIN_DATE, DateUtils.dateToString(startDate));
        mapReturn.put(Constant.MAX_DATE, DateUtils.dateToString(endDate));
        return mapReturn;
    }
}
