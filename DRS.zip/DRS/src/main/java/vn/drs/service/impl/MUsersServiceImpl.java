package vn.drs.service.impl;

import java.io.FileNotFoundException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.googlecode.genericdao.search.Search;

import vn.drs.core.dao.BaseDao;
import vn.drs.core.dao.HibernateDAOFactory;
import vn.drs.entity.MUsers;
import vn.drs.hibernate.dao.MUserDao;
import vn.drs.service.MUsersService;
import vn.drs.synchronize.model.PUser;

@Service
public class MUsersServiceImpl implements MUsersService{

	private final int FIRST_INDEX = 0;
	
	@Autowired
    private HibernateDAOFactory hibFactory;

    @Autowired
    private MUserDao mUserDao;
    
    @Override
    public void syncUser(List<PUser> pUsers) throws Exception {
        mUserDao.syncUser(pUsers);
    }
    
    @PostConstruct
    public void initSSL() throws FileNotFoundException{
		System.setProperty("javax.net.ssl.trustStore",
				ResourceUtils.getFile("classpath:certification/thekeystore").getAbsolutePath());
		System.setProperty("javax.net.ssl.trustStorePassword", "123456");

		HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
			public boolean verify(String hostname, SSLSession session) {
				// ip address of the service URL(like.23.28.244.244)
				if (hostname.equals("192.168.32.11"))
					return true;
				return false;
			}
		});

    }

	@Override
	public String userFullName(String shortName) {
		// Khoi tao lop mUserDao
		BaseDao<MUsers> mUsersDao = hibFactory.instantiateDAO(MUsers.class);
		Search search = new Search();
		// Tim user theo ten dang nhap cua user
		search.addFilterEqual("usrUserName", shortName);
		// Chi lay ten day du cua user dua vao ten dang nhap
		search.addField("usrFullName");

		// Neu khong lay duoc full name cua user thi tra ve chuoi shortName
		String userFullName = mUsersDao.search(search).get(FIRST_INDEX) != null
				? (String) mUsersDao.search(search).get(FIRST_INDEX) : shortName;

		// Tra ve ten day du cua user
		return userFullName;
	}

}
