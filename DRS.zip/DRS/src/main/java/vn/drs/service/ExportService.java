package vn.drs.service;

import java.util.Date;

public interface ExportService {

    /**
     * export data cua project theo ngay
     * 
     * @param projectId
     *            project Id
     * @param Date
     *            ngay export
     * @return ten file export
     */
    String exportProject(int projectId, Date date);

}
