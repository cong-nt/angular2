package vn.drs.service;

import java.util.List;

import vn.drs.entity.MUsers;
import vn.drs.entity.User;

public interface UserService {
	public List<MUsers> getAllUser();
	public List<User> findUserByName(String name);
} 
