package vn.drs.service;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import vn.drs.dto.ViewTaskDTO;
import vn.drs.entity.BTask;
import vn.drs.entity.MProject;

/**
 * <h5>Task service</h5>
 * <p>
 * Cac ham xu ly lien quan den task
 * </p>
 *
 */
public interface BTaskService {

    /**
     * <p>
     * Tim kiem task theo cac tieu chi
     * </p>
     * 
     * @param keyword
     *            Tu khoa tim kiem
     * @param projectId
     *            Project id
     * @param work
     *            Phan loai task
     * @param business
     *            In schedule hay Out of schedule
     * @param phase
     *            Phase cua du an
     * @param status
     *            Tinh trang task
     * @param resourceName
     *            Ten nhan vien
     * @param startTime
     *            Thoi gian bat dau (work time)
     * @param endTime
     *            Thoi gian ket thuc (work time)
     * @return Danh sach task
     */
    public Map<String, Object> search(String keyword, Integer projectId,
            Integer work, Integer business, Integer phase, Integer status,
            String resourceName, Date startTime, Date endTime);

    /**
     * <p>
     * Lay toan bo danh sach task
     * </p>
     * 
     * @param resourceId
     *            Id cua member
     * @param startDate
     *            Ngay bat dau cua task
     * @param endDate
     *            Ngay ket thuc cua task
     * @return Danh sach task
     * @throws ParseException
     */
    public Map<String, Object> getAllTask(int resourceId, Date startDate,
            Date endDate) throws ParseException;

    /**
     * <p>
     * Xoa task
     * </p>
     * 
     * @param taskId
     *            task id
     * @throws Exception
     */
    public void deleteTask(int taskId) throws Exception;

    /**
     * </p>
     * Luu task
     * </p>
     * 
     * @param bTask
     *            Btask object
     * @throws Exception
     */
    public void saveTask(BTask bTask);

    /**
     * 
     * @param lst
     * @throws Exception
     */
    public void saveMyTask(List<ViewTaskDTO> lst, int resourceId)
            throws Exception;

    /**
     * 
     * @param lst
     * @throws Exception
     */
    public void sendMyTask(List<ViewTaskDTO> lst, int resourceId)
            throws Exception;

    /**
     * </p>
     * Lay danh sach Task theo dua an
     * </p>
     * 
     * @param mProject
     *            MProject object
     * @throws Exception
     */
    public List<BTask> getAllTaskByProject(MProject mProject);

    public Map<String, Object> searchMyTask(int resourceId, String keyword,
            Integer projectId,
            Integer work, Integer business, Integer phase, Integer status,
            Date startDate, Date endDate) throws ParseException;

    /**
     * <p>
     * Kiem tra user trong ngay da gui request chua
     * </p>
     * 
     * @param resourceId
     *            Id cua member
     * @param date
     *            Ngay request
     * @return True neu da gui request, False neu chua gui request
     */
    public boolean isSendRequest(int resourceId, Date date);
}
