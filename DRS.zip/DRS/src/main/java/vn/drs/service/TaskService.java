package vn.drs.service;

import java.util.List;

import vn.drs.entity.BTask;

public interface TaskService {

    public List<BTask> getAllTask();

	public void saveTask(BTask bTask);
}
