package vn.drs.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.genericdao.search.Search;

import vn.drs.core.dao.BaseDao;
import vn.drs.core.dao.HibernateDAOFactory;
import vn.drs.entity.BAssignment;
import vn.drs.service.BAssignmentService;

@Service
public class BAssignmentServiceImpl implements BAssignmentService {

    @Autowired
    private HibernateDAOFactory hibFactory;

    @Override
    public List<BAssignment> getListAssignmentByResourceId(Integer resourceId) {
        BaseDao<BAssignment> BAssignmentDao = hibFactory
                .instantiateDAO(BAssignment.class);
        Search search = new Search();

        search.addFilterEqual("BResource.id", resourceId);

        search.addField("BTask.MProject.prjName", "prjName");
        search.addField("BTask.tasName", "tasName");

        search.addField("BWorks.worPlanDate", "worPlanDate");
        search.addField("BWorks.worPlanHours", "worPlanHours");
        search.addField("BWorks.worWorkDate", "worWorkDate");
        search.addField("BWorks.worWorkHours", "worWorkHours");
        search.addField("BWorks.worStatus", "worStatus");
        search.addField("BWorks.worIsVerified", "worIsVerified");

        search.setResultMode(Search.RESULT_MAP);

        return BAssignmentDao.search(search);
    }

}
