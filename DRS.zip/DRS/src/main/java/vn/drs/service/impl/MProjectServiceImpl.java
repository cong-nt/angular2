package vn.drs.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.googlecode.genericdao.search.Search;

import vn.drs.core.dao.BaseDao;
import vn.drs.core.dao.HibernateDAOFactory;
import vn.drs.entity.MProject;
import vn.drs.hibernate.dao.ProjectDao;
import vn.drs.service.MProjectService;
import vn.drs.synchronize.model.PProject;

@Service
public class MProjectServiceImpl implements MProjectService {

    @Autowired
    private HibernateDAOFactory hibFactory;

    @Autowired
    ProjectDao projectDao;

    @Override
    public List<MProject> getProjectByPMTL(int userId) {
        // Tao Dao
        BaseDao<MProject> projectDao = hibFactory
                .instantiateDAO(MProject.class);
        // Khoi tao va them dieu kien search
        Search search = new Search();
        search.addField("id");
        search.addField("prjName");
        search.addFilterEqual("BResources.MUsers.id", userId);
        search.addFilterIn("BResources.MRole.rolName", "PL",
                "PM", "TL");
        search.setResultMode(Search.RESULT_MAP);
        return projectDao.search(search);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public MProject getProjectByName(String prjName) {
        BaseDao<MProject> prjDao = hibFactory.instantiateDAO(MProject.class);
        Search search = new Search();
        search.addFilterEqual("prjName", prjName);
        return prjDao.searchUnique(search);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public MProject getProjectById(int projectId) {
        // Tao Dao
        BaseDao<MProject> projectDao = hibFactory
                .instantiateDAO(MProject.class);
        // Khoi tao va them dieu kien search
        Search search = new Search();
        search.addFilterEqual("id", projectId);
        return projectDao.searchUnique(search);
    }

    @Override
    public List<MProject> getProjectByUserId(int userId) {
        // Tao Dao
        BaseDao<MProject> projectDao = hibFactory
                .instantiateDAO(MProject.class);
        // Khoi tao va them dieu kien search
        Search search = new Search();
        search.addField("id");
        search.addField("prjName");
        search.addFilterEqual("BResources.MUsers.id", userId);
        search.setResultMode(Search.RESULT_MAP);
        search.setDistinct(true);
        return projectDao.search(search);
    }

    @Override
    public void syncProject(List<PProject> pProjects) throws Exception {
        projectDao.syncProject(pProjects);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void saveProject(MProject mProject) {
        // Tao Dao
        BaseDao<MProject> projectDao = hibFactory
                .instantiateDAO(MProject.class);
        // Luu project
        projectDao.save(mProject);
    }

}
