package vn.drs.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.genericdao.search.Filter;
import com.googlecode.genericdao.search.Search;

import vn.drs.core.dao.BaseDao;
import vn.drs.core.dao.HibernateDAOFactory;
import vn.drs.entity.AbstractEntity;
import vn.drs.entity.BAuthorization;
import vn.drs.entity.BResource;
import vn.drs.entity.MProject;
import vn.drs.service.BAuthorizationService;
import vn.drs.service.MailService;

@Service
public class BAuthorizationServiceImpl implements BAuthorizationService {

    @Autowired
    private HibernateDAOFactory hibFactory;

    @Autowired
    private MailService mailService;

    @Override
    public List<BAuthorization> getAuthorizationByCreator(int userId) {
        // Tao DAO
        BaseDao<BAuthorization> authorizationDao = hibFactory.instantiateDAO(BAuthorization.class);

        // Them dieu kien Search
        Search search = new Search();
        search.addFilterIn("BResourceByAutCreatorId.MUsers.id", userId);
        search.addField("MProject.prjName");
        search.addField("BResourceByAutResourceId.resShortName");
        search.addField("BResourceByAutAuthorizedId.resShortName");
        search.addField("autEffectiveDate");
        search.addField("autExpirationDate");
        search.addField("autReasons");
        search.addField("valid");
        search.addField("id");
        search.setResultMode(Search.RESULT_MAP);

        // Tra ve ket qua
        return authorizationDao.search(search);
    }

    @Override
    public void addNewAuthorization(Object authorizationJsonObj) throws Exception {
        // Parse du lieu ra Map
        HashMap<String, Object> mapResource = (HashMap<String, Object>) authorizationJsonObj;

        // Lay du lieu trong Map
        int creatorId = (int) mapResource.get("BResourceByAutCreatorId.id");
        int authorizedId = (int) mapResource.get("BResourceByAutAuthorizedId.id");
        int resourceId = (int) mapResource.get("BResourceByAutResourceId.id");
        int projectId = (int) mapResource.get("MProject.id");
        String autEffectiveDate = (String) mapResource.get("autEffectiveDate");
        String autExpirationDate = (String) mapResource.get("autExpirationDate");
        String autReason = (String) mapResource.get("autReasons");
        Date currentDate = new Date();
        SimpleDateFormat parseFormat = new SimpleDateFormat(
                "MM/dd/yyyy");
        Date effectiveDate = parseFormat.parse(autEffectiveDate);
        Date expirationDate = parseFormat.parse(autExpirationDate);

        // Kiem tra nguoi uy quyen da thuc hien uy quyen cho nguoi nao trong cung thoi gian chua
        if (checkDuplicateAuthorization(projectId, resourceId, effectiveDate, expirationDate) == true) {
            throw new system.Exception("Bi trung ngay uy quyen");
        }

        // Tao doi tuong authorization
        BAuthorization authorization = new BAuthorization();
        BResource resource = new BResource();
        BResource authorized = new BResource();
        BResource creator = new BResource();
        MProject project = new MProject();

        // Set gia tri vao bien
        resource.setId(resourceId);
        authorized.setId(authorizedId);
        creator.setId(creatorId);
        project.setId(projectId);

        authorization.setBResourceByAutResourceId(resource);
        authorization.setBResourceByAutAuthorizedId(authorized);
        authorization.setBResourceByAutCreatorId(creator);
        authorization.setMProject(project);
        authorization.setAutEffectiveDate(effectiveDate);
        authorization.setAutExpirationDate(expirationDate);
        authorization.setAutReasons(autReason);
        authorization.setCreatedDate(currentDate);
        authorization.setModifiedDate(currentDate);
        authorization.setValid(AbstractEntity.VALID);

        // Tao Dao
        BaseDao<BAuthorization> authorizationDao = hibFactory.instantiateDAO(BAuthorization.class);
        BaseDao<BResource> resourceDao = hibFactory.instantiateDAO(BResource.class);
        if(authorizationDao.save(authorization) == true){
            Search resourceSearch = new Search();
            resourceSearch.addFilterEqual("id", resourceId);
            resource = (BResource) resourceDao.searchUnique(resourceSearch);

            Search authorizedSearch = new Search();
            authorizedSearch.addFilterEqual("id", authorizedId);
            authorized = (BResource) resourceDao.searchUnique(authorizedSearch);
            
            mailService.sendAuthorize(resource, authorized, effectiveDate, expirationDate, autReason);
        };
    }

    private boolean checkDuplicateAuthorization(int projectId, int resourceId, Date effectiveDate,
            Date expirationDate) {
        // Tao DAO
        BaseDao<BAuthorization> authorizationDao = hibFactory.instantiateDAO(BAuthorization.class);

        // Them dieu kien Search
        Search search = new Search();
        search.addField("id");
        search.addFilterIn("BResourceByAutResourceId.id", resourceId);
        search.addFilterEqual("MProject.id", projectId);
        search.addFilterEqual("valid", AbstractEntity.VALID);
        Filter filter1 = Filter.and(Filter.lessOrEqual("autEffectiveDate", expirationDate),
                Filter.greaterOrEqual("autEffectiveDate", effectiveDate));
        Filter filter2 = Filter.and(Filter.lessOrEqual("autExpirationDate", expirationDate),
                Filter.greaterOrEqual("autExpirationDate", effectiveDate));
        search.addFilterOr(filter1, filter2);
        List<BAuthorization> authorization = authorizationDao.search(search);
        if (authorization.size() > 0) {
            return true;
        }
        return false;
    }

    @Override
    public void deleteAuthorization(int authorizationId) throws Exception {
        // huy uy quyen
        BaseDao<BAuthorization> authorizationDao = hibFactory
                .instantiateDAO(BAuthorization.class);
        BAuthorization authorization = new BAuthorization();
        authorization.setId(authorizationId);
        authorization.setValid((byte) 0);
        authorization.setModifiedDate(new Date());
        authorization = authorizationDao.mergeWithExistingAttr(authorization);

        // gui mail thong bao
        Search search = new Search();
        search.addFilterIn("id", authorization.getId());
        search.addFetch("BResourceByAutAuthorizedId");
        search.addFetch("BResourceByAutResourceId");
        authorization = authorizationDao.searchUnique(search);
        BResource recieverId = authorization.getBResourceByAutAuthorizedId();
        BResource authorizerId = authorization.getBResourceByAutResourceId();
        Date autEffectiveDate = authorization.getAutEffectiveDate();
        Date autExpirationDate = authorization.getAutExpirationDate();
        String autReasons = authorization.getAutReasons();
        mailService.sendDestroyAuthorize(recieverId, authorizerId,
                autEffectiveDate, autExpirationDate, autReasons);

    }
}
