package vn.drs.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.genericdao.search.Search;

import vn.drs.core.dao.BaseDao;
import vn.drs.core.dao.HibernateDAOFactory;
import vn.drs.entity.MUsers;
import vn.drs.entity.User;
import vn.drs.service.UserService;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private HibernateDAOFactory hibFactory;

    @Override
    public List<MUsers> getAllUser() {
        BaseDao<MUsers> userDao = hibFactory.instantiateDAO(MUsers.class);
        return userDao.findAll();
    }

    @Override
    public List<User> findUserByName(String name) {
        BaseDao<User> userDao = hibFactory.instantiateDAO(User.class);
        Search search = new Search();
        search.addFilterEqual("username", "Duy");
        return userDao.search(search);
    }

}
