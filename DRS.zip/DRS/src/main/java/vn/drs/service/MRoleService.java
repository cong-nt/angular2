package vn.drs.service;

import java.util.List;

import vn.drs.synchronize.model.PRole;

public interface MRoleService {
    
    // Dong bo role
    void syncRole(List<PRole> pRoles) throws Exception;
}
