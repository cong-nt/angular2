package vn.drs.hibernate.dao;

import java.util.Date;
import java.util.List;

import vn.drs.core.dao.BaseDao;
import vn.drs.entity.BWork;

public interface WorkDao extends BaseDao<BWork> {

    List<BWork> findByWorkDateAttachAssignment(Date date);

    List<BWork> findByWorkDate(Date date);

    List<BWork> findByWorkDateAttachAssignment(Date date, int projectId);

}
