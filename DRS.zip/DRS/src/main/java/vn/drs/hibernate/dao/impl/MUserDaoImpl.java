package vn.drs.hibernate.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import vn.drs.core.dao.BaseDaoImpl;
import vn.drs.entity.AbstractEntity;
import vn.drs.entity.MUsers;
import vn.drs.hibernate.dao.MUserDao;
import vn.drs.synchronize.model.PUser;

@Repository("mUserDao")
public class MUserDaoImpl extends BaseDaoImpl<MUsers> implements MUserDao {

    @Autowired
    @Qualifier("sessionFactory")
    private SessionFactory sessionFactory;

    @Override
    public void syncUser(List<PUser> pUsers) throws Exception {
        Session session = sessionFactory.getCurrentSession();
        StringBuilder sql;
        Query query;

        List<Integer> ids =  new ArrayList<Integer>();
        for (PUser pUser : pUsers) {
            ids.add(pUser.getId());
            sql = new StringBuilder();
            sql.append(
                    "INSERT INTO m_users(id, usr_user_name, usr_full_name, usr_email, created_date, valid) ")
                    .append("VALUES(:id, :userName, :fullName, :userMail, :date, :valid) ")
                    .append("ON DUPLICATE KEY UPDATE usr_user_name=:userName")
                    .append(", usr_full_name=:fullName")
                    .append(", usr_email=:userMail")
                    .append(", modified_date= :date, valid = :valid");
            query = session.createSQLQuery(sql.toString());
            query.setParameter("id", pUser.getId());
            query.setParameter("userName", pUser.getUserName());
            query.setParameter("fullName", pUser.getFullName());
            query.setParameter("userMail", pUser.getUserEmail());
            query.setParameter("date", new Date());
            query.setParameter("valid", pUser.getBlock() != PUser.BLOCK
                    ? AbstractEntity.VALID : AbstractEntity.INVALID);
            query.executeUpdate();
        }
        query = session.createSQLQuery("UPDATE  m_users set valid = :valid, modified_date= :date where id not in :ids");
        query.setParameterList("ids", ids);
        query.setParameter("valid", AbstractEntity.INVALID);
        query.setParameter("date", new Date());
        query.executeUpdate();
        
    }
}
