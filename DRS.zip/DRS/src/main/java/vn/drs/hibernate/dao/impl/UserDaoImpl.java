package vn.drs.hibernate.dao.impl;

import org.springframework.stereotype.Repository;

import com.googlecode.genericdao.search.Search;

import vn.drs.core.dao.BaseDaoImpl;
import vn.drs.entity.User;
import vn.drs.hibernate.dao.UserDao;

/**
 * @author duy
 */
@Repository("userDao")
public class UserDaoImpl extends BaseDaoImpl<User> implements UserDao {

	@Override
	public User getByName(String username) {
		return searchUnique(new Search(User.class).addFilterEqual("username",
				username));
	}

	@Override
	public User getByEmail(String email) {
		return searchUnique(new Search(User.class).addFilterEqual("email",
				email));
	}

	@Override
	public boolean authentication(User user, String password) {
		return user.getPassword().equals(password);
	}
}
