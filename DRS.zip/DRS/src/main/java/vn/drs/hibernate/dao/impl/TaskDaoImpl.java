package vn.drs.hibernate.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import vn.drs.core.dao.BaseDaoImpl;
import vn.drs.entity.BTask;
import vn.drs.hibernate.dao.TaskDao;

@Repository("taskDao")
public class TaskDaoImpl extends BaseDaoImpl<BTask> implements TaskDao {

    @Override
    public List<BTask> getMyTask(String id) {

        // Session session = sessionFactory.getCurrentSession();
        // String sql = "SELECT * FROM b_task";
        // List<HashMap<String, Object>> lstMaps = session.createSQLQuery(sql)
        // .setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP).list();

        /*
         * Session sessionHb = sessionFactory.openSession(); String sql =
         * "SELECT tas_name workItem, tas_description description FROM b_assignment ass LEFT JOIN drs.b_task tsk ON ass.ass_task_id = tsk.id "
         * + " WHERE ass.ass_resource_id = '1'"; SQLQuery query = sessionHb.createSQLQuery(sql); //
         * query.setParameter("id", id); query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP); return query.list();
         */

        Session sessionHb = sessionFactory.openSession();
        Criteria crit = sessionHb.createCriteria(BTask.class);
        crit.add(Restrictions.eq("id", 2));
        List<BTask> results = crit.list();
        return results;
    }
}
