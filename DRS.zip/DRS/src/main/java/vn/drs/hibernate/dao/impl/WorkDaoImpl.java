package vn.drs.hibernate.dao.impl;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.googlecode.genericdao.search.Search;

import vn.drs.core.dao.BaseDaoImpl;
import vn.drs.entity.BWork;
import vn.drs.entity.MProject;
import vn.drs.hibernate.dao.WorkDao;
import vn.drs.util.DateUtils;

@Repository("workDao")
public class WorkDaoImpl extends BaseDaoImpl<BWork> implements WorkDao {

    @Override
    public List<BWork> findByWorkDate(Date date) {
        return search(new Search(BWork.class)
                .addFilterGreaterOrEqual("worWorkDate",
                        DateUtils.removeTime(date))
                .addFilterLessOrEqual("worWorkDate", DateUtils.midnight(date)));
    }

    @Override
    public List<BWork> findByWorkDateAttachAssignment(Date date) {
        return search(new Search(BWork.class)
                .addFilterGreaterOrEqual("worWorkDate",
                        DateUtils.removeTime(date))
                .addFilterLessOrEqual("worWorkDate", DateUtils.midnight(date))
                .addFetch("BAssignment").addFetch("BAssignment.BResource")
                .addFetch("BAssignment.BTask"));
    }

    @Override
    public List<BWork> findByWorkDateAttachAssignment(Date date,
            int projectId) {
        MProject project = new MProject();
        project.setId(projectId);

        return search(new Search(BWork.class)
                .addFilterGreaterOrEqual("worWorkDate",
                        DateUtils.removeTime(date))
                .addFilterLessOrEqual("worWorkDate", DateUtils.midnight(date))
                .addFilterEqual("BAssignment.BTask.MProject", project)
                .addFetch("BAssignment").addFetch("BAssignment.BResource")
                .addFetch("BAssignment.BTask"));
    }

}
