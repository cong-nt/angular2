package vn.drs.hibernate.dao;

import java.util.List;

import vn.drs.core.dao.BaseDao;
import vn.drs.entity.MProject;
import vn.drs.synchronize.model.PProject;

public interface ProjectDao extends BaseDao<MProject> {

    // Dong bo project
    void syncProject(List<PProject> pProjects) throws Exception;
}
