package vn.drs.hibernate.dao;

import java.util.List;

import vn.drs.core.dao.BaseDao;
import vn.drs.entity.BResource;
import vn.drs.synchronize.model.PProjectUser;

public interface ResourceDao extends BaseDao<BResource> {

    // Dong bo resource
    void syncResource(List<PProjectUser> pProjectUsers) throws Exception;
}
