package vn.drs.hibernate.dao;

import vn.drs.core.dao.BaseDao;
import vn.drs.entity.User;

public interface ExportDao extends BaseDao<User> {
    /**
     * thong tin can thay doi torng mot du an mot project la : task id,
     * ressource id, duration time
     */

    /**
     * thong tin can de thay doi trong mot project. project file in here.
     */
}
