package vn.drs.hibernate.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import vn.drs.core.dao.BaseDaoImpl;
import vn.drs.entity.AbstractEntity;
import vn.drs.entity.MRole;
import vn.drs.hibernate.dao.RoleDao;
import vn.drs.synchronize.model.PRole;
import vn.drs.synchronize.model.PUser;

@Repository("mRoleDao")
public class RoleDaoImpl extends BaseDaoImpl<MRole> implements RoleDao {

    @Autowired
    @Qualifier("sessionFactory")
    private SessionFactory sessionFactory;
    
    @Override
    public void syncRole(List<PRole> pRoles) throws Exception {
        Session session = sessionFactory.getCurrentSession();
        StringBuilder sql;
        Query query;

        List<Integer> ids =  new ArrayList<Integer>();
        for (PRole pRole: pRoles) {
            ids.add(pRole.getId());
            sql = new StringBuilder();
            sql.append(
                    "INSERT INTO m_role(id, rol_name, created_date, valid) ")
                    .append("VALUES(:id, :roleName, :date, :valid) ")
                    .append("ON DUPLICATE KEY UPDATE rol_name=:roleName")
                    .append(", modified_date= :date, valid = :valid");
            query = session.createSQLQuery(sql.toString());
            query.setParameter("id", pRole.getId());
            query.setParameter("roleName", pRole.getRole());
            query.setParameter("date" , new Date());
            query.setParameter("valid", AbstractEntity.VALID);
            query.executeUpdate();
        }     

        query = session.createSQLQuery("UPDATE  m_role set valid = :valid, modified_date= :date  where id not in :ids");
        query.setParameterList("ids", ids);
        query.setParameter("valid", AbstractEntity.INVALID);
        query.setParameter("date", new Date());
        query.executeUpdate();
        
    }

}
