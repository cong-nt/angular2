package vn.drs.hibernate.dao;

import vn.drs.core.dao.BaseDao;
import vn.drs.entity.BAssignment;

public interface AssignmentDao extends BaseDao<BAssignment> {

}
