package vn.drs.hibernate.dao.impl;

import org.springframework.stereotype.Repository;

import vn.drs.core.dao.BaseDaoImpl;
import vn.drs.entity.User;
import vn.drs.hibernate.dao.ExportDao;

/**
 * @author hoang.vm
 */
@Repository("exportDao")
public class ExportDaoImpl extends BaseDaoImpl<User> implements ExportDao {

}
