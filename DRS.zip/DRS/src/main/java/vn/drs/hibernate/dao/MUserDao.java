package vn.drs.hibernate.dao;

import java.util.List;

import vn.drs.core.dao.BaseDao;
import vn.drs.entity.MUsers;
import vn.drs.synchronize.model.PUser;

/**
 * @author duy
 */
public interface MUserDao extends BaseDao<MUsers> {
    
    // Dong bo user
    void syncUser(List<PUser> pUsers) throws Exception;
}
