package vn.drs.hibernate.dao;

import java.util.List;

import vn.drs.core.dao.BaseDao;
import vn.drs.entity.MRole;
import vn.drs.synchronize.model.PRole;

/**
 * @author duy
 */
public interface RoleDao extends BaseDao<MRole> {
    
    // Dong bo role
    void syncRole(List<PRole> pRoles) throws Exception;
}
