package vn.drs.hibernate.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import vn.drs.core.dao.BaseDaoImpl;
import vn.drs.entity.AbstractEntity;
import vn.drs.entity.BResource;
import vn.drs.hibernate.dao.ResourceDao;
import vn.drs.synchronize.model.PProjectUser;
import vn.drs.synchronize.model.PUser;

@Repository("resourceDao")
public class ResourceDaoImpl extends BaseDaoImpl<BResource>
        implements ResourceDao {

    @Autowired
    @Qualifier("sessionFactory")
    private SessionFactory sessionFactory;

    @Override
    public void syncResource(List<PProjectUser> pProjectUsers)
            throws Exception {
        Session session = sessionFactory.getCurrentSession();
        StringBuilder sql;
        Query query;

        List<Integer> ids =  new ArrayList<Integer>();
        for (PProjectUser pProjectUser: pProjectUsers) {
            ids.add(pProjectUser.getId());
            sql = new StringBuilder();
            sql.append(
                    "INSERT INTO b_resource(id, res_user_id, res_project_id, res_role_id, created_date, valid) ")
                    .append("VALUES(:id, :userId, :projectId, :roleId, :date, :valid) ")
                    .append("ON DUPLICATE KEY UPDATE res_user_id=:userId")
                    .append(", res_project_id=:projectId")
                    .append(", res_role_id=:roleId")
                    .append(", modified_date= :date, valid = :valid");
            query = session.createSQLQuery(sql.toString());
            query.setParameter("id", pProjectUser.getId());
            query.setParameter("userId", pProjectUser.getUserId());
            query.setParameter("projectId", pProjectUser.getProjectId());
            query.setParameter("roleId", pProjectUser.getRoleId());
            query.setParameter("date" , new Date());
            query.setParameter("valid", AbstractEntity.VALID);
            query.executeUpdate();
        }    

        query = session.createSQLQuery("UPDATE  b_resource set valid = :valid, modified_date= :date where id not in :ids");
        query.setParameterList("ids", ids);
        query.setParameter("valid", AbstractEntity.INVALID);
        query.setParameter("date", new Date());
        query.executeUpdate();
    }

}
