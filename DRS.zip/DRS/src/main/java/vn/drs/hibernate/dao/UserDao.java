package vn.drs.hibernate.dao;

import vn.drs.core.dao.BaseDao;
import vn.drs.entity.User;


/**
 * @author duy
 */
public interface UserDao extends BaseDao<User> {
	public User getByName(String username);
    public User getByEmail(String email);
    public boolean authentication(User user, String password);
}
