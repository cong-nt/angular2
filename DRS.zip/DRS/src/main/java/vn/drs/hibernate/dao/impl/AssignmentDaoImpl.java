package vn.drs.hibernate.dao.impl;

import org.springframework.stereotype.Repository;

import vn.drs.core.dao.BaseDaoImpl;
import vn.drs.entity.BAssignment;
import vn.drs.hibernate.dao.AssignmentDao;

@Repository("assignmentDao")
public class AssignmentDaoImpl extends BaseDaoImpl<BAssignment>
        implements AssignmentDao {

}
