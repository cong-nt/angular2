package vn.drs.hibernate.dao;

import java.util.List;

import vn.drs.core.dao.BaseDao;
import vn.drs.entity.BTask;

public interface TaskDao extends BaseDao<BTask> {
    public List<BTask> getMyTask(String id);
}
