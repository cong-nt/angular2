package vn.drs.synchronize.service;

public interface SynchronizeService {

    void synchronoze() throws Exception;
}
