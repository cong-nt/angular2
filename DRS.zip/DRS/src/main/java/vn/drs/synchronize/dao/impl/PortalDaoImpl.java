package vn.drs.synchronize.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.GenericTypeResolver;
import org.springframework.stereotype.Repository;

import vn.drs.synchronize.dao.PortalDao;
import vn.drs.synchronize.model.PAbstractEntity;
import vn.drs.synchronize.model.PProject;
import vn.drs.synchronize.model.PProjectUser;
import vn.drs.synchronize.model.PRole;
import vn.drs.synchronize.model.PUser;

@Repository
public class PortalDaoImpl implements PortalDao {

    @Autowired
    @Qualifier("portalSessionFactory")
    private SessionFactory sessionFac;

    @Override
    public List<PUser> getAllUser() throws Exception {
        return (List<PUser>) sessionFac.getCurrentSession()
                .createCriteria(PUser.class)
                .list();
    }

    @Override
    public List<PRole> getAllRole() throws Exception {
        return (List<PRole>) sessionFac.getCurrentSession()
                .createCriteria(PRole.class).list();
    }

    @Override
    public List<PProject> getAllProject() throws Exception {
        return (List<PProject>) sessionFac.getCurrentSession()
                .createCriteria(PProject.class)
                .list();
    }

    @Override
    public List<PProjectUser> getAllProjectUser() throws Exception {
        Query query = sessionFac.getCurrentSession()
                .createSQLQuery(
                        new StringBuilder("select PROJECT_USER.id as id, ")
                                .append("PROJECT_USER.user_id as userId, ")
                                .append("PROJECT_USER.role_id as roleId, ")
                                .append("PROJECT_USER.project_id as projectId ")
                                .append("from o3o8m_pf_project_user as PROJECT_USER ")
                                .append("inner join o3o8m_users as USER ")
                                .append("on PROJECT_USER.user_id = USER.id and USER.block <> :block ")
                                .append("inner join o3o8m_pf_projects as PROJECT ")
                                .append("on PROJECT_USER.project_id = PROJECT.id and PROJECT.state <> :state ")
                                .toString())
                .setResultTransformer(
                        Transformers.aliasToBean(PProjectUser.class));

        query.setParameter("block", PUser.BLOCK);
        query.setParameter("state", PProject.STATE_DELETE);

        return (List<PProjectUser>) query.list();
    }

}
