package vn.drs.synchronize.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import vn.drs.service.BResourceService;
import vn.drs.service.MProjectService;
import vn.drs.service.MRoleService;
import vn.drs.service.MUsersService;
import vn.drs.synchronize.dao.PortalDao;
import vn.drs.synchronize.model.PProject;
import vn.drs.synchronize.model.PProjectUser;
import vn.drs.synchronize.model.PRole;
import vn.drs.synchronize.model.PUser;
import vn.drs.synchronize.service.SynchronizeService;

@Service
public class SynchronizeServiceImpl implements SynchronizeService {

    @Autowired
    private PortalDao portalDao;

    @Autowired
    private MProjectService mProjectService;

    @Autowired
    private BResourceService bResourceService;

    @Autowired
    private MRoleService mRoleService;

    @Autowired
    private MUsersService mUsersService;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public void synchronoze() throws Exception {
        List<PUser> pUsers = portalDao.getAllUser();
        List<PRole> pRoles = portalDao.getAllRole();
        List<PProject> pProjects = portalDao.getAllProject();
        List<PProjectUser> pProjectUsers = portalDao.getAllProjectUser();

        mUsersService.syncUser(pUsers);
        mRoleService.syncRole(pRoles);
        mProjectService.syncProject(pProjects);
        bResourceService.syncResource(pProjectUsers);

    }

}
