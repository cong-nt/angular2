package vn.drs.synchronize.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import vn.drs.entity.MRole;

@Entity
@Table(name = "o3o8m_pf_project_role")
public class PRole extends PAbstractEntity implements Serializable {

    @Column(name = "role")
    private String role;

    public PRole() {
        super();
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
