package vn.drs.synchronize.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import vn.drs.entity.MProject;

@Entity
@Table(name = "o3o8m_pf_projects")
public class PProject extends PAbstractEntity implements Serializable {

    public static Integer STATE_DELETE = -2;
    
    @Column(name = "title")
    private String title;

    @Column(name = "created_by")
    private Integer creatorId;

    @Column(name = "description")
    private String description;

    @Column(name = "created")
    private Date createdDate;

    @Column(name = "modified")
    private Date modifiedDate;
    
    @Column(name="state")
    private Integer state;

    public PProject() {
        super();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(Integer creatorId) {
        this.creatorId = creatorId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

}
