package vn.drs.synchronize.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import vn.drs.entity.MUsers;

@Entity
@Table(name = "o3o8m_users")
public class PUser extends PAbstractEntity implements Serializable {


    public static Integer BLOCK = 1;
    
    @Column(name = "username")
    private String userName;

    @Column(name = "name")
    private String fullName;

    @Column(name = "email")
    private String userEmail;
    
    @Column(name="block")
    private int block;

    public PUser() {
        super();
        // TODO Auto-generated constructor stub
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public int getBlock() {
        return block;
    }

    public void setBlock(int block) {
        this.block = block;
    }
}
