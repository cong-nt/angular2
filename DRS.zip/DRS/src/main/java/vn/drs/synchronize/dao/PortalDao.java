package vn.drs.synchronize.dao;

import java.util.List;

import vn.drs.synchronize.model.PAbstractEntity;
import vn.drs.synchronize.model.PProject;
import vn.drs.synchronize.model.PProjectUser;
import vn.drs.synchronize.model.PRole;
import vn.drs.synchronize.model.PUser;

public interface PortalDao {
    List<PUser> getAllUser() throws Exception;
    List<PRole> getAllRole() throws Exception;
    List<PProject> getAllProject() throws Exception;
    List<PProjectUser> getAllProjectUser() throws Exception;
}
