package vn.drs.enums;

/**
 * @author duy
 */
public enum ErrorCode {

	ERR_INCORRECT_USRPWD;

	private String errorCode;
	private String defaultMessage;
	private String localeMessage;

	private ErrorCode() {
	}

	private ErrorCode(String errorCode, String defaultMessage,
			String localeMessage) {
		this.errorCode = errorCode;
		this.defaultMessage = defaultMessage;
		this.localeMessage = localeMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getDefaultMessage() {
		return defaultMessage;
	}

	public String getLocaleMessage() {
		return localeMessage;
	}
}
