package vn.drs.enums;

/**
 * @author duy
 */
public enum RoleEnum {
	ROLE_USER, ROLE_CLIENT;

	private String type;
	private int id;

	private RoleEnum() {
	}
	
	private RoleEnum(String type, int id) {
		this.type = type;
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public int getId() {
		return id;
	}
}
