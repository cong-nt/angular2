package vn.drs.dto;

import java.util.Date;
import java.util.List;
import java.util.Map;

import vn.drs.entity.BWork;

public class ViewTaskDTO {

    private String id;
    private String tasResourceName;
    private String tasProject;
    private String tasBusiness;
    private String tasModule;
    private String tasPhase;
    private String tasWork;
    private String tasName;
    private String tasDescription;
    private Date tasPlanStartTime;
    private Date tasPlanEndTime;
    private Date tasActualStartTime;
    private Date tasActualEndTime;
    private String tasStatus;
    private Integer tasUniqueId;
    private Map<String, String> mapPlan;
    private Map<String, String> mapActual;
    private int tasProjectId;
    private int tasBusinessId;
    private int tasModuleId;
    private int tasPhaseId;
    private int tasWorkId;
    private int tasStatusId;
    private double tasPercent;
    private double tasAssPlanHours;
    private double tasAssWorkHours;
    private double tasAssPlanStartTime;
    private double tasAssPlanEndTime;
    private double tasAssWorkStartTime;
    private double tasAssWorkEndTime;
    private int tasAssId;
    private List<BWork> listWork;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTasResourceName() {
        return tasResourceName;
    }

    public void setTasResourceName(String tasResourceName) {
        this.tasResourceName = tasResourceName;
    }

    public String getTasProject() {
        return tasProject;
    }

    public void setTasProject(String tasProject) {
        this.tasProject = tasProject;
    }

    public String getTasBusiness() {
        return tasBusiness;
    }

    public void setTasBusiness(String tasBusiness) {
        this.tasBusiness = tasBusiness;
    }

    public String getTasModule() {
        return tasModule;
    }

    public void setTasModule(String tasModule) {
        this.tasModule = tasModule;
    }

    public String getTasPhase() {
        return tasPhase;
    }

    public void setTasPhase(String tasPhase) {
        this.tasPhase = tasPhase;
    }

    public String getTasWork() {
        return tasWork;
    }

    public void setTasWork(String tasWork) {
        this.tasWork = tasWork;
    }

    public String getTasName() {
        return tasName;
    }

    public void setTasName(String tasName) {
        this.tasName = tasName;
    }

    public String getTasDescription() {
        return tasDescription;
    }

    public void setTasDescription(String tasDescription) {
        this.tasDescription = tasDescription;
    }

    public Date getTasPlanStartTime() {
        return tasPlanStartTime;
    }

    public void setTasPlanStartTime(Date tasPlanStartTime) {
        this.tasPlanStartTime = tasPlanStartTime;
    }

    public Date getTasPlanEndTime() {
        return tasPlanEndTime;
    }

    public void setTasPlanEndTime(Date tasPlanEndTime) {
        this.tasPlanEndTime = tasPlanEndTime;
    }

    public Date getTasActualStartTime() {
        return tasActualStartTime;
    }

    public void setTasActualStartTime(Date tasActualStartTime) {
        this.tasActualStartTime = tasActualStartTime;
    }

    public Date getTasActualEndTime() {
        return tasActualEndTime;
    }

    public void setTasActualEndTime(Date tasActualEndTime) {
        this.tasActualEndTime = tasActualEndTime;
    }

    public String getTasStatus() {
        return tasStatus;
    }

    public void setTasStatus(String tasStatus) {
        this.tasStatus = tasStatus;
    }

    public Integer getTasUniqueId() {
        return tasUniqueId;
    }

    public void setTasUniqueId(Integer tasUniqueId) {
        this.tasUniqueId = tasUniqueId;
    }

    public Map<String, String> getMapPlan() {
        return mapPlan;
    }

    public void setMapPlan(Map<String, String> mapPlan) {
        this.mapPlan = mapPlan;
    }

    public Map<String, String> getMapActual() {
        return mapActual;
    }

    public void setMapActual(Map<String, String> mapActual) {
        this.mapActual = mapActual;
    }

    public int getTasProjectId() {
        return tasProjectId;
    }

    public void setTasProjectId(int tasProjectId) {
        this.tasProjectId = tasProjectId;
    }

    public int getTasBusinessId() {
        return tasBusinessId;
    }

    public void setTasBusinessId(int tasBusinessId) {
        this.tasBusinessId = tasBusinessId;
    }

    public int getTasModuleId() {
        return tasModuleId;
    }

    public void setTasModuleId(int tasModuleId) {
        this.tasModuleId = tasModuleId;
    }

    public int getTasPhaseId() {
        return tasPhaseId;
    }

    public void setTasPhaseId(int tasPhaseId) {
        this.tasPhaseId = tasPhaseId;
    }

    public int getTasWorkId() {
        return tasWorkId;
    }

    public void setTasWorkId(int tasWorkId) {
        this.tasWorkId = tasWorkId;
    }

    public int getTasStatusId() {
        return tasStatusId;
    }

    public void setTasStatusId(int tasStatusId) {
        this.tasStatusId = tasStatusId;
    }

    public double getTasPercent() {
        return tasPercent;
    }

    public void setTasPercent(double tasPercent) {
        this.tasPercent = tasPercent;
    }

    public double getTasAssPlanHours() {
        return tasAssPlanHours;
    }

    public void setTasAssPlanHours(double tasAssPlanHours) {
        this.tasAssPlanHours = tasAssPlanHours;
    }

    public double getTasAssWorkHours() {
        return tasAssWorkHours;
    }

    public void setTasAssWorkHours(double tasAssWorkHours) {
        this.tasAssWorkHours = tasAssWorkHours;
    }

    public double getTasAssPlanStartTime() {
        return tasAssPlanStartTime;
    }

    public void setTasAssPlanStartTime(double tasAssPlanStartTime) {
        this.tasAssPlanStartTime = tasAssPlanStartTime;
    }

    public double getTasAssPlanEndTime() {
        return tasAssPlanEndTime;
    }

    public void setTasAssPlanEndTime(double tasAssPlanEndTime) {
        this.tasAssPlanEndTime = tasAssPlanEndTime;
    }

    public double getTasAssWorkStartTime() {
        return tasAssWorkStartTime;
    }

    public void setTasAssWorkStartTime(double tasAssWorkStartTime) {
        this.tasAssWorkStartTime = tasAssWorkStartTime;
    }

    public double getTasAssWorkEndTime() {
        return tasAssWorkEndTime;
    }

    public void setTasAssWorkEndTime(double tasAssWorkEndTime) {
        this.tasAssWorkEndTime = tasAssWorkEndTime;
    }

    public int getTasAssId() {
        return tasAssId;
    }

    public void setTasAssId(int tasAssId) {
        this.tasAssId = tasAssId;
    }

    public List<BWork> getListWork() {
        return listWork;
    }

    public void setListWork(List<BWork> listWork) {
        this.listWork = listWork;
    }
}
