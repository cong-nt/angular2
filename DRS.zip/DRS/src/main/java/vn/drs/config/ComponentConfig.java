package vn.drs.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
//@PropertySource({ "classpath:db.properties" })
@ComponentScan(basePackages = "vn.drs", excludeFilters = { @Filter(Configuration.class) })
@ImportResource({ "classpath:spring-config.xml", "classpath:hibernate.xml" })
@EnableTransactionManagement(proxyTargetClass = true)
/**
 * @author duy
 */
public class ComponentConfig {
}
