package vn.drs.config;

import java.util.List;
import java.util.Locale;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.orm.hibernate4.support.OpenSessionInViewInterceptor;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.hibernate4.Hibernate4Module;

import vn.drs.util.ApplicationContextUtils;

/**
 * @author duy
 */
@Configuration
@EnableWebMvc
public class WebConfig extends WebMvcConfigurerAdapter {
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Bean
	public OpenSessionInViewInterceptor openSessionInterceptor() {
		OpenSessionInViewInterceptor os = new OpenSessionInViewInterceptor();
		os.setSessionFactory(sessionFactory);
		return os;
	}
	
	@Override
	public void configureDefaultServletHandling(
			DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addWebRequestInterceptor(openSessionInterceptor());
		registry.addInterceptor(localeChangeInterceptor());
		super.addInterceptors(registry);
	}
	
	@Bean
	public ViewResolver viewResolver() {
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setPrefix("/views/");
		viewResolver.setSuffix(".html");
		return viewResolver;
	}

	public class HibernateAwareObjectMapper extends ObjectMapper {
		private static final long serialVersionUID = 864915188910701832L;

		public HibernateAwareObjectMapper() {
			Hibernate4Module hm = new Hibernate4Module();
			hm.configure(Hibernate4Module.Feature.FORCE_LAZY_LOADING, true);
			hm.configure(
					Hibernate4Module.Feature.SERIALIZE_IDENTIFIER_FOR_LAZY_NOT_LOADED_OBJECTS,
					true);
			this.registerModule(hm);
			this.setSerializationInclusion(Include.NON_NULL);
		}
	}

	@Bean
	public ObjectMapper objectMapper() {
		ObjectMapper mapper = new HibernateAwareObjectMapper();
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
				false);
		return mapper;
	}

	@Bean
	public MappingJackson2HttpMessageConverter jsonConverter() {
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
		converter.setObjectMapper(objectMapper());
		return converter;
	}

	@Override
	public void configureMessageConverters(
			List<HttpMessageConverter<?>> converters) {
		converters.add(jsonConverter());
		super.configureMessageConverters(converters);
	}

	@Bean
	public MultipartResolver multipartResolver() {
		CommonsMultipartResolver m = new CommonsMultipartResolver();
		// m.setMaxUploadSize(MAX_UPLOAD_SIZE);
		return m;
	}
	
	@Bean
	public ApplicationContextUtils applicationContextUtils() {
		return new ApplicationContextUtils();
	}
	
	@Bean
	public LocaleResolver localeResolver() {
		final SessionLocaleResolver ret = new SessionLocaleResolver();
		ret.setDefaultLocale(new Locale("en"));
		return ret;
	}

	@Bean
	public LocaleChangeInterceptor localeChangeInterceptor() {
		LocaleChangeInterceptor localeChangeInterceptor = new LocaleChangeInterceptor();
		localeChangeInterceptor.setParamName("language");
		return localeChangeInterceptor;
	}
	
	@Bean
	public MessageSource messageSource() {
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		messageSource.setDefaultEncoding("UTF-8");
		messageSource.setBasename("messages/messages");
		return messageSource;
	}
}
