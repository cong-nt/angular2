package vn.drs.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import vn.drs.service.MailService;

@Configuration
@EnableAsync
@EnableScheduling
public class DailyMailConfig {

    @Autowired
    private MailService mailService;

    @Scheduled(cron = "0 0 16 * * ?")
    public void sendDailyMail() throws Exception {
    }
}
