package vn.drs.config;

import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;

import freemarker.template.TemplateException;



@Configuration
@ComponentScan(basePackages = "vn.drs.service")
@PropertySource("classpath:mail.properties")
public class EmailConfig {

    @Autowired
    private Environment enviroment;

    @Bean
    public JavaMailSender getMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        // Configure mail service
        mailSender.setHost(enviroment.getRequiredProperty("mail.host"));
        mailSender.setPort(Integer.parseInt(enviroment
                .getRequiredProperty("mail.port")));
        mailSender.setUsername(enviroment.getRequiredProperty("mail.username"));
        mailSender.setPassword(enviroment.getRequiredProperty("mail.password"));

        // Configure mail properties
        Properties javaMailProperties = new Properties();
        javaMailProperties.put("mail.smtp.starttls.enable",
                enviroment.getRequiredProperty("mail.smtp.starttls.enable"));
        javaMailProperties.put("mail.smtp.ssl.trust",
                enviroment.getRequiredProperty("mail.smtp.ssl.trust"));
        javaMailProperties.put("mail.smtp.auth",
                enviroment.getRequiredProperty("mail.smtp.auth"));
        javaMailProperties.put("mail.transport.protocol",
                enviroment.getRequiredProperty("mail.transport.protocol"));
        javaMailProperties.put("mail.debug",
                enviroment.getRequiredProperty("mail.debug"));

        mailSender.setJavaMailProperties(javaMailProperties);

        return mailSender;
    }

    public FreeMarkerConfigurationFactoryBean getFreeMarkerConfigurationFactory() {
        FreeMarkerConfigurationFactoryBean bean = new FreeMarkerConfigurationFactoryBean();
        bean.setTemplateLoaderPath("/mailtemplates/");
        return bean;
    }

    @Bean
    public freemarker.template.Configuration getFreeMarkerConfiguration()
            throws IOException, TemplateException {
        return getFreeMarkerConfigurationFactory().createConfiguration();
    }    
}
