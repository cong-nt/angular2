package vn.drs.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource({"classpath:oauth/security.xml"})
public class SecurityConfig {
	
}
