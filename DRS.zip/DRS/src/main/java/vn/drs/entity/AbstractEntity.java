package vn.drs.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

/**
 * @author duy
 */
@Inheritance(strategy = InheritanceType.JOINED)
@MappedSuperclass
public class AbstractEntity {

    private Integer id;

    @Version
    @Column(name = "VERSION", updatable = true)
    private Long version = 0L;

    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    /** The constructor. */
    public AbstractEntity() {
        this.valid = VALID;
        this.modifiedDate = new Date();
        this.createdDate = new Date();
    }

    /** The Constant VALID. */
    public static final byte VALID = 1;

    /** The Constant INVALID. */
    public static final byte INVALID = 0;

    /** The created date. */
    private Date createdDate;

    /** The modified date. */
    private Date modifiedDate;

    /** The valid. */
    private Byte valid;

    /**
     * <h1>getCreatedDate</h1>
     * <p>
     * Gets the created date
     * </p>
     * 
     * @return Date the created date
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true, length = 19)
    public Date getCreatedDate() {
        return this.createdDate;
    }

    /**
     * <h1>setCreatedDate</h1>
     * <p>
     * Sets the created date
     * </p>
     * <h3>input</h3>
     * <table style="border: 1px solid black;">
     * <tr>
     * <th style="border: 1px solid black;">param</th>
     * <th style="border: 1px solid black;">type</th>
     * <th style="border: 1px solid black;">descripton</th>
     * </tr>
     * <tr>
     * <td style="border: 1px solid black;">createdDate</td>
     * <td style="border: 1px solid black;">Date</td>
     * <td style="border: 1px solid black;">createdDate the new created
     * date</td>
     * </tr>
     * </table>
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * <h1>getModifiedDate</h1>
     * <p>
     * Gets the modified date
     * </p>
     * 
     * @return Date the modified date
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true, length = 19)
    public Date getModifiedDate() {
        return this.modifiedDate;
    }

    /**
     * <h1>setModifiedDate</h1>
     * <p>
     * Sets the modified date
     * </p>
     * <h3>input</h3>
     * <table style="border: 1px solid black;">
     * <tr>
     * <th style="border: 1px solid black;">param</th>
     * <th style="border: 1px solid black;">type</th>
     * <th style="border: 1px solid black;">descripton</th>
     * </tr>
     * <tr>
     * <td style="border: 1px solid black;">modifiedDate</td>
     * <td style="border: 1px solid black;">Date</td>
     * <td style="border: 1px solid black;">modifiedDate the new modified
     * date</td>
     * </tr>
     * </table>
     */
    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    /**
     * <h1>getValid</h1>
     * <p>
     * Gets the valid
     * </p>
     * 
     * @return Byte the valid
     */
    @Column(name = "valid")
    public Byte getValid() {
        return this.valid;
    }

    /**
     * <h1>setValid</h1>
     * <p>
     * Sets the valid
     * </p>
     * <h3>input</h3>
     * <table style="border: 1px solid black;">
     * <tr>
     * <th style="border: 1px solid black;">param</th>
     * <th style="border: 1px solid black;">type</th>
     * <th style="border: 1px solid black;">descripton</th>
     * </tr>
     * <tr>
     * <td style="border: 1px solid black;">valid</td>
     * <td style="border: 1px solid black;">Byte</td>
     * <td style="border: 1px solid black;">valid the new valid</td>
     * </tr>
     * </table>
     */
    public void setValid(Byte valid) {
        this.valid = valid;
    }
}
