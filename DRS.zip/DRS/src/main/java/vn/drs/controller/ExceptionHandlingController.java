package vn.drs.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import vn.drs.dto.ValidationErrorDTO;
import vn.drs.util.MessageUtil;

/**
 * @author duy
 */
@ControllerAdvice
public class ExceptionHandlingController {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ExceptionHandlingController.class);

	private ValidationErrorDTO processFieldErrors(List<FieldError> fieldErrors) {
		ValidationErrorDTO dto = new ValidationErrorDTO();

		for (FieldError fieldError : fieldErrors) {
			String localizedErrorMessage = resolveLocalizedErrorMessage(fieldError);
			dto.addFieldError(fieldError.getField(), localizedErrorMessage);
		}

		return dto;
	}

	private String resolveLocalizedErrorMessage(FieldError fieldError) {
		String message = MessageUtil.getMessage(fieldError);

		if (message.equals(fieldError.getCodes())) {
			message = fieldError.getCodes()[0];
		}

		return message;
	}

	@ExceptionHandler(BindException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public @ResponseBody
	ValidationErrorDTO handleException(BindException ex,
			HttpServletRequest request, HttpServletResponse response) {
		BindingResult result = ex.getBindingResult();
		List<FieldError> fieldErrors = result.getFieldErrors();

		LOGGER.warn(ex.getMessage());

		return processFieldErrors(fieldErrors);
	}
}
