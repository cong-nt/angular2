package vn.drs.controller.api;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import vn.drs.entity.BTask;

@RestController
@RequestMapping(value = "api")
public class MyTaskAPI {

    @PostMapping(value = "tsk", produces = "application/json")
    public @ResponseBody String getTsk(@RequestBody BTask btsk) {
        return "success!!!";
    }
}
