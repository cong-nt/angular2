package vn.drs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import vn.drs.entity.BAuthorization;
import vn.drs.entity.BResource;
import vn.drs.entity.MProject;
import vn.drs.service.BAuthorizationService;
import vn.drs.service.BResourceService;
import vn.drs.service.MProjectService;
import vn.drs.service.MailService;

@Controller
public class AuthorizationController {

    @Autowired
    private BResourceService resourceService;

    @Autowired
    private MProjectService projectService;

    @Autowired
    private BAuthorizationService authorizationService;

    @RequestMapping(value = "/authorize_project", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<MProject> getProjectListPMTL(@RequestParam("user_id") int userId) {
        List<MProject> projectList = projectService.getProjectByPMTL(userId);
        return projectList;
    }

    @RequestMapping(value = "/authorized_list", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<BAuthorization> getAuthorizedListPMTL(@RequestParam("user_id") int resourceId) {
        List<BAuthorization> authorizedList = authorizationService.getAuthorizationByCreator(resourceId);
        return authorizedList;
    }

    @RequestMapping(value = "authorize/role_resource", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<BResource> getRoleResourceInPj(@RequestParam("user_id") int userId,
            @RequestParam("project_id") int projectId) {
        List<BResource> resourceList = resourceService.getResourceByUserAndPj(userId, projectId);
        return resourceList;
    }

    @RequestMapping(value = "/authorize/to_resource", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<BResource> getToAuthorizationResourceList(@RequestParam("project_id") int projectId,
            @RequestParam("role_name") String resourceRole) {
        List<BResource> toAuthorizeList = resourceService.getToResourceAuthorization(projectId, resourceRole);
        return toAuthorizeList;
    }

    @RequestMapping(value = "/authorize/from_resource", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<BResource> getFromAuthorizationResourceList(@RequestParam("project_id") int projectId,
            @RequestParam("role_name") String resourceRole) {
        List<BResource> toAuthorizeList = resourceService.getFromResourceAuthorization(projectId, resourceRole);
        return toAuthorizeList;
    }

    @RequestMapping(value = "/authorize/add", method = RequestMethod.POST, headers = "Accept=application/json")
    public ResponseEntity addAuthorization(@RequestBody Object authorizationJsonObject) {
        try {
            authorizationService.addNewAuthorization(authorizationJsonObject);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(value = "/authorize/delete", method = RequestMethod.DELETE)
    public ResponseEntity deleteAuthorization(
            @RequestParam("id") int authorizationId) {
        try {
            authorizationService.deleteAuthorization(authorizationId);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity(HttpStatus.OK);
    }

}
