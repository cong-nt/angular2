package vn.drs.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vn.drs.entity.MProject;
import vn.drs.service.ExportService;
import vn.drs.service.MProjectService;

/**
 * 
 * @author hoang.vm
 *
 */
@Controller
@RequestMapping("/export/*")
@RestController
public class ExportController {

    @Autowired(required = false)
    private String mppFolder;

    @Autowired
    private ExportService exportService;

    @Autowired
    private MProjectService mProjectService;

    @Autowired
    private Semaphore semaphone;

    /**
     * download file export.
     * 
     * @param filename
     * @param response
     */

    @RequestMapping(value = "/file_export/{projectId}", method = RequestMethod.GET)
    public void downloadExportFile(@PathVariable("projectId") Integer projectId,
            HttpServletResponse response) {
        try {
            MProject project = mProjectService.getProjectById(projectId);
            String filename = project.getPrjMppFilename();
            if (!StringUtils.isEmpty(filename)) {
                File file = new File(mppFolder, filename);
                if (file.exists()) {
                    InputStream is = new FileInputStream(file);
                    response.setContentType("application/msproject");
                    response.setHeader("Content-disposition",
                            "attachment; filename= " + filename);
                    IOUtils.copy(is, response.getOutputStream());
                    response.flushBuffer();
                } else {
                    // TODO error ?
                }
            }
        } catch (IOException ex) {
        }
    }

    /**
     * export file by project id.
     * 
     * @param projectId
     * @return file name
     * @throws InterruptedException
     */
    @RequestMapping(value = "/project_export/{projectId}", method = RequestMethod.POST)
    public String exportFileProject(
            @PathVariable("projectId") Integer projectId)
            throws InterruptedException {
        String status = "fail";
        semaphone.acquire();
        try {
            String fileName = exportService.exportProject(projectId,
                    new Date());
            if (!StringUtils.isEmpty(fileName)) {
                status = "ok";
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            semaphone.release();
        }
        return status;
    }

    /**
     * lay thong tin project by user
     * 
     * @param projectId
     * @return danh sach cac du an
     * @throws JsonProcessingException
     */
    @RequestMapping(value = "/user/{userId}", method = RequestMethod.POST)
    public String getProjectByUser(@PathVariable("userId") Integer userId)
            throws JsonProcessingException {
        List<MProject> mProjects = mProjectService.getProjectByPMTL(userId);
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(mProjects);
    }

    @RequestMapping(value = "/test/semaphone", method = RequestMethod.POST)
    public String testSemaphone() throws InterruptedException {
        semaphone.acquire();
        TimeUnit.SECONDS.sleep(2);
        semaphone.release();
        return mppFolder;
    }
}
