package vn.drs.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import vn.drs.entity.BResource;
import vn.drs.service.BResourceService;

@Controller
@RequestMapping("/group*")
public class GroupController {

    @Autowired
    private BResourceService bResourceService;

    @RequestMapping(value = "/project_devs", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<BResource> getProjectDev(
            @RequestParam("project_id") int projectId) {
        List<BResource> projectDevs = new ArrayList<BResource>();
        try {
            projectDevs = bResourceService.getProjectDevs(projectId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return projectDevs;
    }

    @RequestMapping(value = "/project_teamleads", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<BResource> getProjectTeamleads(
            @RequestParam("project_id") int projectId) {
        List<BResource> projectTeamleads = new ArrayList<BResource>();
        try {
            projectTeamleads = bResourceService.getProjectTeamLeads(projectId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return projectTeamleads;
    }

    @RequestMapping(value = "", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<BResource> getProjectGroups(
            @RequestParam("project_id") int projectId) {
        List<BResource> projectGroups = new ArrayList<BResource>();
        try {
            projectGroups = bResourceService.getProjectGroups(projectId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return projectGroups;
    }

    @RequestMapping(value = "/members", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<BResource> getProjectGroupMembers(
            @RequestParam("project_id") int projectId) {
        List<BResource> projectGroupMembers = new ArrayList<BResource>();
        try {
            projectGroupMembers = bResourceService
                    .getProjectGroupMembers(projectId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return projectGroupMembers;
    }

    @RequestMapping(value = "/post", method = RequestMethod.POST)
    public ResponseEntity saveGroup(@RequestParam("group_id") int groupId,
            @RequestParam("group_members") Integer[] groupMembers) {
        try {
            bResourceService.saveOrUpdateGroup(groupId, groupMembers);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public ResponseEntity deleteGroup(@RequestParam("group_id") int groupId) {
        try {
            bResourceService.deleteGroup(groupId);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity(HttpStatus.OK);
    }
}
