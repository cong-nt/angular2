package vn.drs.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.datatype.hibernate4.Hibernate4Module;

import vn.drs.constant.Constant;
import vn.drs.entity.MTaskInfo;
import vn.drs.service.BTaskService;
import vn.drs.service.MTaskInfoService;
import vn.drs.util.DateUtils;

/**
 * <h5>Controller su dung cho man hinh view task</h5>
 * </p>
 * Cac ham API xu ly dieu khien trong man hinh view task
 * </p>
 */
@Controller
@RequestMapping(value = "/viewtask/")
public class ViewTaskController {
    private static final Logger LOGGER = LoggerFactory
            .getLogger(ViewTaskController.class);

    @Autowired
    private MTaskInfoService mTaskInfoService;

    @Autowired
    private BTaskService bTaskService;

    /**
     * <p>
     * Tim kiem don gian
     * </p>
     * 
     * @param keyword
     *            Tu khoa tim kiem
     * @return Danh sach task
     * @throws IOException
     * @throws ParseException
     */
    @RequestMapping(value = "default_search", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody String getViewTaskDefaultSearch(
            @RequestParam("keyword") String keyword)
            throws IOException, ParseException {
        Map<String, Object> listTask = bTaskService.search(keyword, null, null,
                null, null, null, null, null, null);
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new Hibernate4Module());
        String json = mapper.writeValueAsString(listTask);
        return json;
    }

    /**
     * <p>
     * Tim kiem nang cao</p
     * 
     * @param search
     *            Cac dieu kien search duoc nhap vao
     * @return Danh sach task
     * @throws IOException
     * @throws ParseException
     */
    @RequestMapping(value = "advance_search/", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody Map<String, Object> getViewTaskAdvanceSearch(
            @RequestParam("search") Object search)
            throws IOException, ParseException {
        @SuppressWarnings("deprecation")
        ObjectReader reader = new ObjectMapper().reader(Map.class);
        Map<String, Object> map = new HashMap<String, Object>();
        if (StringUtils.isNotBlank(String.valueOf(search))) {
            map = reader.readValue(search.toString());
        }
        Date dStartdate = null;
        if (DateUtils.isDate((String) map.get("startDate"),
                Constant.FORMAT_MMDDYYYY)) {
            dStartdate = DateUtils.stringToDate((String) map.get("startDate"),
                    Constant.FORMAT_MMDDYYYY);
        }
        Date dEnddate = null;
        if (DateUtils.isDate((String) map.get("endDate"),
                Constant.FORMAT_MMDDYYYY)) {
            dEnddate = DateUtils.stringToDate((String) map.get("endDate"),
                    Constant.FORMAT_MMDDYYYY);
        }
        Map<String, Object> listTask = bTaskService.search(
                (String) map.get("keyword"), null, (Integer) map.get("work"),
                (Integer) map.get("business"), (Integer) map.get("phase"),
                (Integer) map.get("status"), (String) map.get("name"),
                dStartdate, dEnddate);
        return listTask;
    }

    @RequestMapping(value = "getTaskInfo", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<MTaskInfo> getTaskInfo() {
        return mTaskInfoService.getAllTaskInfo();
    }

}
