package vn.drs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vn.drs.entity.BAssignment;
import vn.drs.entity.BResource;
import vn.drs.service.BAssignmentService;
import vn.drs.service.BResourceService;

@RestController
public class ApproveController {

    @Autowired
    private BResourceService bResourceService;

    @Autowired
    private BAssignmentService bAssignmentService;

    @Autowired
    ObjectMapper mapper;

    /**
     * mapping request lay danh sach cac resource co the duoc approve boi user
     * 
     * @param userId
     * @param projectId
     * @return
     * @throws JsonProcessingException
     */
    @RequestMapping(value = "/resource/canApprove", method = RequestMethod.POST, produces = "application/json")
    public String getUsersCanApprove(
            @RequestParam("suppervisiorId") Integer userId,
            @RequestParam("projectId") Integer projectId)
            throws JsonProcessingException {
        List<BResource> resourceCanApprove = bResourceService
                .getResourceCanApprove(userId, projectId);
        // TODO chua co phan ghi chu cac user chua send approve chua co phan
        // quyen
        String json = mapper.writeValueAsString(resourceCanApprove);
        return json;
    }

    @RequestMapping(value = "/assignment/canApprove", method = RequestMethod.POST, produces = "application/json")
    public String getAssignmentApprove(
            @RequestParam("resourceId") Integer resourceId)
            throws JsonProcessingException {
        List<BAssignment> assignmentByResource = bAssignmentService
                .getListAssignmentByResourceId(resourceId);
        // TODO chua co phan phan quyen
        String json = mapper.writeValueAsString(assignmentByResource);
        return json;
    }
}
