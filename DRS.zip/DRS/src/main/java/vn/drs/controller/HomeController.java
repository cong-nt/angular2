package vn.drs.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.datatype.hibernate4.Hibernate4Module;

import vn.drs.constant.Constant;
import vn.drs.dto.ViewTaskDTO;
import vn.drs.entity.BTask;
import vn.drs.entity.MProject;
import vn.drs.entity.MTaskInfo;
import vn.drs.service.BTaskService;
import vn.drs.service.MProjectService;
import vn.drs.service.MTaskInfoService;
import vn.drs.synchronize.service.SynchronizeService;
import vn.drs.util.DateUtils;
import vn.drs.util.Utils;

/**
 * <h5>Controller chinh cua he thong</h5>
 * </p>
 * Cac ham API xu ly dieu khien he thong
 * </p>
 */
@Controller
public class HomeController {
    private static final Logger LOGGER = LoggerFactory.getLogger(HomeController.class);

    @Autowired
    private MTaskInfoService mTaskInfoService;

    @Autowired
    private BTaskService bTaskService;

    @Autowired
    private SynchronizeService synchronizeService;

    @Autowired
    private MProjectService mProjectService;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String home() {
        return "index";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET, produces = "application/json")
    public String logout(HttpSession session, HttpServletResponse response) {
        session.invalidate();
        return "index";
    }

    @RequestMapping(value = "/mytask/getTaskInfoName", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<MTaskInfo> getWork(@RequestParam("taskId") int id) {
        return mTaskInfoService.getTaskInfoNameByType(id);
    }

    @RequestMapping(value = "/import", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<BTask> getImportPage() {
        // List<BTask> task = bTaskService.getAllTask();
        // for (BTask bTask : task) {
        // bTask.setMProject(null);
        // bTask.setBAssignments(null);
        // bTask.setMTaskInfoByTasBusiness(null);
        // bTask.setMTaskInfoByTasModule(null);
        // bTask.setMTaskInfoByTasPhase(null);
        // bTask.setMTaskInfoByTasWork(null);
        // }
        return null;
    }

    @RequestMapping(value = "/mytask/getwork", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<MTaskInfo> getWork() {
        return mTaskInfoService.getTaskInfoNameByType(4);
    }

    @RequestMapping(value = "/mytask/getmodule", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<MTaskInfo> getModule() {
        return mTaskInfoService.getTaskInfoNameByType(5);
    }

    @RequestMapping(value = "/mytask/all", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody String getMyTask() throws IOException, ParseException {
        Map<String, Object> listTask = bTaskService.getAllTask(1, DateUtils.getStartDateOfWeek(),
                DateUtils.getEndDateOfWeek());
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new Hibernate4Module());
        String json = mapper.writeValueAsString(listTask);
        return json;
    }

    @RequestMapping(value = "/mytask/next", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody String nextMyTask(@RequestParam("date") String date) throws IOException, ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Map<String, Object> listTask = bTaskService.getAllTask(1, DateUtils.getStartDateOfWeek(sdf.parse(date)),
                DateUtils.getEndDateOfWeek(sdf.parse(date)));
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new Hibernate4Module());
        String json = mapper.writeValueAsString(listTask);
        return json;
    }

    @RequestMapping(value = "/mytask/back", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody String backMyTask(@RequestParam("date") String date) throws IOException, ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Map<String, Object> listTask = bTaskService.getAllTask(1, DateUtils.getStartDateOfWeek(sdf.parse(date)),
                DateUtils.getEndDateOfWeek(sdf.parse(date)));
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new Hibernate4Module());
        String json = mapper.writeValueAsString(listTask);
        return json;
    }

    @RequestMapping(value = "/mytask/save", method = RequestMethod.POST, produces = "application/json")
    public @ResponseBody void saveMyTask(@RequestParam("form") Object jsonObject) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.setDateFormat(new SimpleDateFormat(Constant.FORMAT_YYYYMMDD));
        int resourceId = 1;

        List<ViewTaskDTO> lst = null;
        try {
            lst = mapper.readValue((String) jsonObject, new TypeReference<List<ViewTaskDTO>>() {
            });
            bTaskService.saveMyTask(lst, resourceId);
        } catch (JsonParseException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @RequestMapping(value = "/mytask/send", method = RequestMethod.POST, produces = "application/json")
    public @ResponseBody void sendMyTask(@RequestParam("form") String jsonObject) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.setDateFormat(new SimpleDateFormat(Constant.FORMAT_YYYYMMDD));
        int resourceId = 1;

        List<ViewTaskDTO> lst = null;
        try {
            lst = mapper.readValue(jsonObject, new TypeReference<List<ViewTaskDTO>>() {
            });
            bTaskService.sendMyTask(lst, resourceId);
        } catch (JsonParseException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @RequestMapping(value = "/mytask/delete", method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity deleteMyTask(@RequestParam("id") int id) throws Exception {
        try {
            bTaskService.deleteTask(id);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(value = "/sync", method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity synchronize() throws Exception {
        try {
            synchronizeService.synchronoze();
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(value = "/mytask/search", method = RequestMethod.POST, produces = "application/json")
    public @ResponseBody String searchMyTask(@RequestParam("keyword") String keyword)
            throws IOException, ParseException {
        Map<String, Object> listTask = bTaskService.searchMyTask(1, keyword, null, null, null, null, null,
                DateUtils.getStartDateOfWeek(), DateUtils.getEndDateOfWeek());
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new Hibernate4Module());
        String json = mapper.writeValueAsString(listTask);
        return json;
    }

    @RequestMapping(value = "/mytask/searchAdvance", method = RequestMethod.POST, produces = "application/json")
    public @ResponseBody String searchMyTask(@RequestParam("search") Object search) throws IOException, ParseException {
        // Initial value of advanced search form
        ObjectReader reader = new ObjectMapper().reader(Map.class);
        Map<String, Object> map = new HashMap<String, Object>();
        if (StringUtils.isNotBlank(String.valueOf(search))) {
            map = reader.readValue(search.toString());
        }
        Integer projectId = Utils.convertObjectToInt(map.get("projectId"));
        Integer workId = Utils.convertObjectToInt(map.get("workId"));
        Integer businessId = Utils.convertObjectToInt(map.get("businessId"));
        Integer phaseId = Utils.convertObjectToInt(map.get("phaseId"));
        Integer statusId = Utils.convertObjectToInt(map.get("statusId"));
        // find task base on searching condition
        Map<String, Object> listTask = bTaskService.searchMyTask(1, null, projectId, workId, businessId, phaseId,
                statusId, DateUtils.getStartDateOfWeek(), DateUtils.getEndDateOfWeek());
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new Hibernate4Module());
        String json = mapper.writeValueAsString(listTask);
        return json;
    }

    @RequestMapping(value = "/mytask/getProjectByUserId", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<MProject> getProjectByUserId() {
        return mProjectService.getProjectByUserId(1);
    }

    @RequestMapping(value = "/api/UserPermission", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody List<String> getUserPermission() {
        List<String> permissions = new ArrayList<>();
        permissions.add("TL");
        return permissions;
    }

}
