package vn.drs.controller.api;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import net.sf.mpxj.MPXJException;
import net.sf.mpxj.ProjectFile;
import net.sf.mpxj.Resource;
import net.sf.mpxj.ResourceAssignment;
import net.sf.mpxj.Task;
import net.sf.mpxj.TimephasedWork;
import net.sf.mpxj.mpp.MPPReader;
import vn.drs.constant.Constant;
import vn.drs.entity.AbstractEntity;
import vn.drs.entity.BAssignment;
import vn.drs.entity.BResource;
import vn.drs.entity.BTask;
import vn.drs.entity.BWork;
import vn.drs.entity.MProject;
import vn.drs.entity.MUsers;
import vn.drs.service.BResourceService;
import vn.drs.service.BTaskService;
import vn.drs.service.MProjectService;
import vn.drs.service.UserService;
import vn.drs.util.DateUtils;
import vn.drs.util.SavedMppUtils;

@RestController
@RequestMapping(value = "api")
public class UploadAPI {

    private static final Logger LOGGER = LoggerFactory
            .getLogger(UploadAPI.class);

    @Autowired
    private BTaskService taskService;

    @Autowired
    private MProjectService projectService;

    @Autowired
    private BResourceService resourceService;

    @Autowired
    private UserService userService;

    @PostMapping(value = "/upload", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<Map<String, Object>> upload(
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam(value = "projectId", required = false) Integer projectId)
            throws IOException, MPXJException {
        boolean hasError = false;
        InputStream in = file.getInputStream();
        String name = file.getOriginalFilename();
        MPPReader r = new MPPReader();
        ProjectFile project = r.read(in);
        MProject mProject = projectService.getProjectById(projectId);

        // Lay danh sach BTask cu
        List<BTask> lstOldBTask = new ArrayList<>();
        Map<Integer, BTask> mapOldTask = new HashMap<>();
        lstOldBTask = taskService.getAllTaskByProject(mProject);
        for (Iterator<BTask> iterator = lstOldBTask.iterator(); iterator
                .hasNext();) {
            BTask bTask = iterator.next();
            mapOldTask.put(bTask.getTasUniqueId(), bTask);
        }

        // Lay danh sach user
        List<MUsers> lstUser = userService.getAllUser();
        Map<String, MUsers> mapUserId = new HashMap<>();
        for (Iterator<MUsers> iterator = lstUser.iterator(); iterator
                .hasNext();) {
            MUsers user = iterator.next();
            mapUserId.put(user.getUsrShortName(), user);
        }

        List<BTask> lstBTask = new ArrayList<>();
        lstBTask = getTaskListFromMpp(project, mProject, mapUserId);

        // Tra ve du lieu hien thi tren luoi
        StringBuffer stbRes = new StringBuffer();
        List<Map<String, Object>> lstReturnData = new ArrayList<>();
        Map<String, Object> map = null;
        for (BTask task : lstBTask) {
            map = new HashMap<>();
            map.put(Constant.UID, task.getTasUniqueId());
            boolean resourceNotMap = false;
            Set<BAssignment> resAss = task.getBAssignments();
            for (BAssignment bAss : resAss) {
                if (bAss.getBResource() != null) {
                    if (bAss.getBResource().getMUsers() == null) {
                        resourceNotMap = true;
                    }
                    stbRes.append(bAss.getBResource().getResShortName());
                    stbRes.append(",");
                }
            }
            map.put(Constant.RESOURCE, stbRes.toString());
            stbRes.setLength(0);
            map.put(Constant.NAME, task.getTasName());
            map.put(Constant.DESCRIPTION, task.getTasDescription());
            map.put(Constant.START, task.getTasActualStartTime());
            map.put(Constant.END, task.getTasActualEndTime());
            if (resourceNotMap) {
                map.put(Constant.ERROR, "Resource not mapped");
                hasError = true;
            }
            lstReturnData.add(map);
        }

        // Luu danh sach BTask
        if (!hasError) {
            for (Iterator<BTask> iterator = lstBTask.iterator(); iterator
                    .hasNext();) {
                BTask bTaskNew = iterator.next();
                BTask oldBTask = mapOldTask.get(bTaskNew.getTasUniqueId());
                // them mot task moi
                if (oldBTask == null) {
                    taskService.saveTask(bTaskNew);
                }
                // update task moi
                if (oldBTask != null) {
                    oldBTask = updateTask(bTaskNew, oldBTask);
                    taskService.saveTask(oldBTask);
                    // loai bo nhung task da duoc update
                    mapOldTask.remove(oldBTask.getTasUniqueId());
                }

            }
            // Xoa nhung task theo Mpp
            for (Iterator<BTask> iterator = mapOldTask.values()
                    .iterator(); iterator.hasNext();) {
                BTask bTaskDel = iterator.next();
                bTaskDel.setValid(AbstractEntity.INVALID);
                taskService.saveTask(bTaskDel);
            }
            SavedMppUtils mppUtil = new SavedMppUtils();
            mppUtil.transformToServer(file, name);
            mProject.setPrjMppFilename(name);
            projectService.saveProject(mProject);
        }

        return lstReturnData;

    }

    /**
     * <p>
     * Lay danh sach task tu Mpp
     * </p>
     * 
     * @param project
     *            Doi tuong ProjectFile doc tu Mpp
     * @param mProject
     *            Doi tuong MProject cua he thong
     * @param mapUserId
     *            Map user Id
     * @return Danh sach BTask
     */
    private List<BTask> getTaskListFromMpp(ProjectFile project,
            MProject mProject, Map<String, MUsers> mapUserId) {

        // Lay resource cua du an
        Map<String, BResource> mapResourceMpp = new HashMap<>();
        Map<Integer, BResource> mapResourceDBUpdate = new HashMap<>();
        List<BResource> lstResourceDB = resourceService
                .getProjectResource(mProject.getId());
        for (Resource resource : project.getAllResources()) {
            BResource bResource = new BResource();
            bResource.setResShortName(resource.getName());
            bResource.setResUid(resource.getUniqueID());
            bResource.setMProject(mProject);
            bResource.setMUsers(mapUserId.get(resource.getName()));
            if (bResource.getResShortName() != null) {
                mapResourceMpp.put(bResource.getResShortName(), bResource);
            }
        }
        for (Iterator<BResource> iterator = lstResourceDB.iterator(); iterator
                .hasNext();) {
            BResource bResource = (BResource) iterator.next();
            BResource bResourceMpp = mapResourceMpp
                    .get(bResource.getResShortName());
            // cap nhat resource UID neu co ton tai trong DB
            if (bResourceMpp != null) {
                bResource.setResUid(bResourceMpp.getResUid());
                // them vao mapResourceDBUpdate
                mapResourceDBUpdate.put(bResourceMpp.getResUid(), bResource);
            }
        }

        // Lay danh sach BTask tu file Mpp
        List<BTask> lstBTask = new ArrayList<>();
        for (Task task : project.getAllTasks()) {
            try {
                BTask bTask = new BTask();
                bTask.setTasUniqueId(task.getUniqueID());
                bTask.setTasName(task.getName());
                if (task.getParentTask() != null) {
                    bTask.setTasDescription(task.getParentTask().getName());
                }
                bTask.setMProject(mProject);
                bTask.setBAssignments(new HashSet<BAssignment>());
                bTask.setTasPlanStartTime(task.getBaselineStart());
                bTask.setTasPlanEndTime(task.getBaselineFinish());
                bTask.setTasActualStartTime(task.getStart());
                bTask.setTasActualEndTime(task.getActualFinish());

                List<ResourceAssignment> assignmentResources = task
                        .getResourceAssignments();
                for (Iterator<ResourceAssignment> iterator = assignmentResources
                        .iterator(); iterator.hasNext();) {
                    try {
                        ResourceAssignment resourceAssignment = iterator.next();
                        BAssignment bAssigment = new BAssignment();
                        bAssigment.setAssUid(resourceAssignment.getUniqueID());
                        bAssigment.setBTask(bTask);
                        if (resourceAssignment.getResource() != null) {
                            BResource resource = mapResourceDBUpdate
                                    .get(resourceAssignment.getResource()
                                            .getUniqueID());
                            bAssigment.setBResource(resource);
                        }
                        bAssigment.setBWorks(new HashSet<BWork>());
                        bAssigment.setAssPlanHours(resourceAssignment
                                .getBaselineWork().getDuration());
                        bAssigment.setAssWorkHours(resourceAssignment
                                .getActualWork().getDuration());
                        // them work
                        List<TimephasedWork> lstWork = resourceAssignment
                                .getTimephasedActualWork();
                        for (Iterator<TimephasedWork> iterator2 = lstWork
                                .iterator(); iterator2.hasNext();) {
                            try {
                                TimephasedWork timephasedWork = iterator2
                                        .next();
                                BWork bwork = new BWork();
                                bwork.setBAssignment(bAssigment);
                                bwork.setWorPlanDate(DateUtils
                                        .removeTime(timephasedWork.getStart()));
                                bwork.setWorWorkDate(DateUtils
                                        .removeTime(timephasedWork.getStart()));
                                bwork.setWorPlanHours(timephasedWork
                                        .getAmountPerDay().getDuration());
                                bwork.setWorWorkHours(timephasedWork
                                        .getAmountPerDay().getDuration());
                                bAssigment.getBWorks().add(bwork);
                            } catch (Exception e) {
                                LOGGER.error("Read task work error", e);
                            }
                        }
                        // them bAssignment
                        bTask.getBAssignments().add(bAssigment);
                    } catch (Exception e) {
                        LOGGER.error("Read task assigment error", e);
                    }
                }
                lstBTask.add(bTask);
            } catch (Exception e) {
                LOGGER.error("Read task error", e);
            }
        }
        return lstBTask;
    }

    /**
     * <p>
     * Update thong tin task
     * </p>
     * 
     * @param newBTask
     *            Doi tuong BTask moi
     * @param oldBTask
     *            Doi tuong BTask cu
     * @return Doi tuong BTask
     */
    private BTask updateTask(BTask newBTask, BTask oldBTask) {
        // Cap nhat cac thuoc tinh cua task cu
        oldBTask.setTasName(newBTask.getTasName());
        oldBTask.setTasDescription(newBTask.getTasDescription());
        oldBTask.setTasPlanStartTime(newBTask.getTasPlanStartTime());
        oldBTask.setTasPlanEndTime(newBTask.getTasPlanEndTime());
        oldBTask.setTasActualStartTime(newBTask.getTasActualStartTime());
        oldBTask.setTasActualEndTime(newBTask.getTasActualEndTime());
        // cap nhat danh sach work
        Set<BAssignment> newAssignments = newBTask.getBAssignments();
        Set<BAssignment> oldAssignments = oldBTask.getBAssignments();
        Map<Integer, BAssignment> mapNewAssignment = new HashMap<>();
        Map<Integer, BAssignment> mapOldAssignment = new HashMap<>();
        Set<BAssignment> setDeletedAssignment = new HashSet<>();
        Set<BAssignment> setAddedAssignment = new HashSet<>();
        for (Iterator<BAssignment> iterator = newAssignments
                .iterator(); iterator.hasNext();) {
            BAssignment bNewAssignment = iterator.next();
            mapNewAssignment.put(bNewAssignment.getAssUid(), bNewAssignment);
            if (!oldAssignments.contains(bNewAssignment)) {
                setAddedAssignment.add(bNewAssignment);
            }
        }
        for (Iterator<BAssignment> iterator = oldAssignments
                .iterator(); iterator.hasNext();) {
            BAssignment bOldAssignment = iterator.next();
            mapOldAssignment.put(bOldAssignment.getAssUid(), bOldAssignment);
            BAssignment bNewAssignment = mapNewAssignment
                    .get(bOldAssignment.getAssUid());

            Set<BWork> oldWorks = bOldAssignment.getBWorks();
            Date lastWorkDateApproved = null;
            boolean hasApproval = false;
            Set<BWork> removeBWorks = new HashSet<>();
            // xoa nhung wokr chua duoc approve
            for (Iterator<BWork> iterator2 = oldWorks.iterator(); iterator2
                    .hasNext();) {
                BWork oldBWork = iterator2.next();
                if (lastWorkDateApproved == null) {
                    lastWorkDateApproved = oldBWork.getWorWorkDate();
                }
                if (oldBWork.getWorStatus() != Constant.WORK_STATUS_APPROVED) {
                    removeBWorks.add(oldBWork);
                } else {
                    hasApproval = true;
                }
                if (oldBWork.getWorWorkDate().getTime() > lastWorkDateApproved
                        .getTime()) {
                    lastWorkDateApproved = oldBWork.getWorWorkDate();
                }
            }
            bOldAssignment.getBWorks().removeAll(removeBWorks);
            if (bNewAssignment != null) {
                // Them work moi
                Set<BWork> newWorks = bNewAssignment.getBWorks();
                for (Iterator<BWork> iterator2 = newWorks.iterator(); iterator2
                        .hasNext();) {
                    BWork newBWork = iterator2.next();
                    if (newBWork.getWorWorkDate()
                            .getTime() > lastWorkDateApproved.getTime()) {
                        oldWorks.add(newBWork);
                    }
                }
            } else {
                if (!hasApproval) {
                    setDeletedAssignment.add(bOldAssignment);
                }
            }
        }
        oldBTask.getBAssignments().removeAll(setDeletedAssignment);
        oldBTask.getBAssignments().addAll(setAddedAssignment);
        return oldBTask;
    }

}
