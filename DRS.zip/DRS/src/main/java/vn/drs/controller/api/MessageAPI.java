package vn.drs.controller.api;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MessageAPI {

    @PostMapping(value = "/api/message", produces = "application/json")
    public String getMessage(@RequestParam("code") String code) throws IOException {
        Properties prop = new Properties();
        InputStream in = MessageAPI.class.getClassLoader().getResourceAsStream("messages.properties");
        prop.load(in);

        return prop.getProperty(code);
    }

}
